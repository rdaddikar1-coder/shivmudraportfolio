import { useMemo, useState } from "react";
import {
  ArrowUpRight,
  Layers,
  FolderKanban,
  X,
  ExternalLink,
  Code2,
  Smartphone,
  Apple,
  MonitorPlay,
} from "lucide-react";
import Reveal from "./Reveal";
import SectionHead from "./SectionHead";
import { useSettings } from "../lib/settings";
import { playUISound } from "../lib/uiSound";
import type { PortfolioItem } from "../data/content";

/* ------------------------------------------------------------------ */
/*  Project detail modal — full image in its ORIGINAL ratio           */
/* ------------------------------------------------------------------ */

function ProjectModal({ project, categoryName, subName, onClose }: {
  project: PortfolioItem;
  categoryName: string;
  subName: string;
  onClose: () => void;
}) {
  const links = [
    { label: "Live Preview", url: project.liveUrl, icon: ExternalLink },
    { label: "Demo", url: project.demoUrl, icon: MonitorPlay },
    { label: "GitHub", url: project.githubUrl, icon: Code2 },
    { label: "Play Store", url: project.playStoreUrl, icon: Smartphone },
    { label: "App Store", url: project.appStoreUrl, icon: Apple },
  ].filter((l) => l.url);

  return (
    <div
      className="fixed inset-0 z-[90] flex items-center justify-center p-4 sm:p-8"
      style={{ background: "rgba(15,23,42,0.4)", backdropFilter: "blur(8px)" }}
      onClick={onClose}
      role="dialog"
      aria-modal
      aria-label={project.title}
    >
      <div
        className="glass-strong relative max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-3xl p-4 sm:p-6"
        style={{ boxShadow: "0 40px 90px -20px var(--sd-glow-medium)" }}
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={() => {
            playUISound("ui_close", { category: "button" });
            onClose();
          }}
          data-sound="none"
          className="glass sticky top-2 z-10 float-right flex h-10 w-10 items-center justify-center rounded-full transition-transform hover:scale-110"
          style={{ color: "var(--sd-heading)" }}
          aria-label="Close project"
        >
          <X size={18} />
        </button>

        {/* ALL project images — original ratio, never cropped */}
        <div className="space-y-4">
          {[project.image, ...(project.gallery ?? [])]
            .filter((img, idx, arr) => img?.url && arr.findIndex((x) => x?.url === img.url) === idx)
            .map((img) => (
              <img
                key={img.url}
                src={img.url}
                alt={img.alt || project.title}
                className="w-full rounded-2xl"
                style={{ height: "auto", display: "block" }}
              />
            ))}
        </div>

        <div className="mt-5 flex flex-wrap items-start justify-between gap-4 pr-12">
          <div>
            <p className="text-xs font-bold uppercase tracking-widest" style={{ color: "var(--sd-primary)" }}>
              {categoryName}
              {subName && ` › ${subName}`}
            </p>
            <h3 className="heading-text mt-1 text-2xl font-bold">{project.title}</h3>
            <p className="mt-1 text-xs font-semibold" style={{ color: "var(--sd-muted)" }}>
              {[project.client, project.date].filter(Boolean).join(" · ")}
            </p>
          </div>
        </div>

        {project.description && (
          <p className="mt-4 text-sm leading-relaxed sm:text-base" style={{ color: "var(--sd-body)" }}>
            {project.description}
          </p>
        )}

        {(project.tech.length > 0 || project.tags.length > 0) && (
          <div className="mt-4 flex flex-wrap gap-2">
            {[...project.tech, ...project.tags].map((t) => (
              <span
                key={t}
                className="rounded-full px-3 py-1 text-[11px] font-semibold"
                style={{ color: "var(--sd-primary)", background: "rgba(37,99,235,0.07)", border: "1px solid rgba(147,197,253,0.4)" }}
              >
                {t}
              </span>
            ))}
          </div>
        )}

        {links.length > 0 && (
          <div className="mt-6 flex flex-wrap gap-3">
            {links.map((l) => (
              <a
                key={l.label}
                href={l.url}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-primary px-5! py-2.5! text-xs!"
              >
                <l.icon size={14} />
                {l.label}
                <ArrowUpRight size={14} />
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Portfolio section                                                 */
/* ------------------------------------------------------------------ */

export default function Portfolio() {
  const { settings, updateContent } = useSettings();
  const { categories, subcategories, portfolio } = settings.content;

  const [activeCategory, setActiveCategory] = useState<string>("");
  const [activeSub, setActiveSub] = useState<string>("");
  const [openProject, setOpenProject] = useState<PortfolioItem | null>(null);

  const sortedCategories = useMemo(
    () => categories.filter((c) => c.active).sort((a, b) => a.order - b.order),
    [categories]
  );

  const subsOfCategory = useMemo(
    () =>
      activeCategory
        ? subcategories.filter((s) => s.parentId === activeCategory && s.active).sort((a, b) => a.order - b.order)
        : [],
    [subcategories, activeCategory]
  );

  const published = useMemo(
    () => portfolio.filter((p) => p.published).sort((a, b) => a.order - b.order),
    [portfolio]
  );

  const visible = useMemo(() => {
    let list = published;
    if (activeCategory) list = list.filter((p) => p.categoryId === activeCategory);
    if (activeSub) list = list.filter((p) => p.subcategoryId === activeSub);
    return list;
  }, [published, activeCategory, activeSub]);

  /** All images of a project (cover + gallery), deduplicated by URL. */
  const imagesOf = (p: PortfolioItem) => {
    const seen = new Set<string>();
    const out: { img: PortfolioItem["image"]; project: PortfolioItem; isCover: boolean }[] = [];
    for (const img of [p.image, ...(p.gallery ?? [])]) {
      if (!img?.url || seen.has(img.url)) continue;
      seen.add(img.url);
      out.push({ img, project: p, isCover: img === p.image });
    }
    return out;
  };

  /** Every matching project image — no arbitrary limit. */
  const visibleCards = useMemo(() => visible.flatMap((p) => imagesOf(p)), [visible]);

  /**
   * Self-healing metadata: for legacy images without stored dimensions,
   * detect the natural size on load and persist it so the ratio is known.
   */
  const onImageLoad = (e: React.SyntheticEvent<HTMLImageElement>, project: PortfolioItem, imgIndex: number) => {
    const el = e.currentTarget;
    if (!el.naturalWidth) return;
    const all = imagesOf(project);
    const meta = all[imgIndex]?.img;
    if (!meta || meta.width !== 0) return;
    const patched = { ...meta, width: el.naturalWidth, height: el.naturalHeight, aspectRatio: el.naturalWidth / el.naturalHeight };
    const next = portfolio.map((p) => {
      if (p.id !== project.id) return p;
      const newImages = imagesOf(p).map((entry, i) => (i === imgIndex ? patched : entry.img));
      return { ...p, image: newImages[0] ?? p.image, gallery: newImages.slice(1) };
    });
    updateContent("portfolio", next);
  };

  const activeCat = categories.find((c) => c.id === activeCategory);
  const catName = (id: string) => categories.find((c) => c.id === id)?.name ?? "Uncategorised";
  const subNameOf = (id: string) => (id ? subcategories.find((s) => s.id === id)?.name ?? "" : "");

  const selectCategory = (id: string) => {
    setActiveCategory(id);
    setActiveSub("");
    playUISound("ui_filter", { category: "button" });
  };

  return (
    <section id="portfolio" className="relative scroll-mt-24 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHead
          badge="Portfolio"
          title={
            <>
              A Galaxy of <span className="text-gradient">Creative Projects</span>
            </>
          }
          description="Browse by category and subcategory — every artwork displayed in its original uploaded ratio."
        />

        {/* dynamic category filters (from Admin Panel) */}
        <Reveal>
          <div className="mb-8 flex flex-wrap items-center justify-center gap-2.5">
            <button
              key="all"
              data-sound="none"
              onClick={() => selectCategory("")}
              className={`rounded-full px-4 py-2 text-xs font-semibold transition-all duration-300 sm:text-[13px] ${
                activeCategory === "" ? "shadow-lg" : "hover:-translate-y-0.5"
              }`}
              style={
                activeCategory === ""
                  ? { background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))", color: "#fff", boxShadow: "0 8px 22px -6px var(--sd-glow-medium)" }
                  : { background: "rgba(255,255,255,0.65)", color: "var(--sd-body)", border: "1px solid rgba(191,219,254,0.7)", backdropFilter: "blur(10px)" }
              }
            >
              All
            </button>
            {sortedCategories.map((c) => {
              const active = activeCategory === c.id;
              return (
                <button
                  key={c.id}
                  data-sound="none"
                  onClick={() => selectCategory(c.id)}
                  className={`rounded-full px-4 py-2 text-xs font-semibold transition-all duration-300 sm:text-[13px] ${
                    active ? "shadow-lg" : "hover:-translate-y-0.5"
                  }`}
                  style={
                    active
                      ? { background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))", color: "#fff", boxShadow: "0 8px 22px -6px var(--sd-glow-medium)" }
                      : { background: "rgba(255,255,255,0.65)", color: "var(--sd-body)", border: "1px solid rgba(191,219,254,0.7)", backdropFilter: "blur(10px)" }
                  }
                >
                  {c.name}
                </button>
              );
            })}
          </div>
        </Reveal>

        {/* category view — image (original ratio), name, description, subcategory chips */}
        {activeCat && (
          <Reveal variant="scale">
            <div className="glass mb-8 overflow-hidden rounded-3xl">
              {activeCat.image && (
                <div className="relative">
                  <img
                    src={activeCat.image.url}
                    alt={activeCat.image.alt || activeCat.name}
                    className="max-h-72 w-full object-contain"
                    style={{ background: "rgba(248,250,252,0.8)", height: "auto" }}
                  />
                </div>
              )}
              <div className="p-6 sm:p-8">
                <p className="text-[11px] font-bold uppercase tracking-[0.25em]" style={{ color: "var(--sd-primary)" }}>
                  Category
                </p>
                <h3 className="heading-text mt-1 text-2xl font-bold">{activeCat.name}</h3>
                {activeCat.description && (
                  <p className="mt-2 max-w-2xl text-sm leading-relaxed" style={{ color: "var(--sd-body)" }}>
                    {activeCat.description}
                  </p>
                )}
                {subsOfCategory.length > 0 && (
                  <div className="mt-5">
                    <p className="mb-2.5 text-[11px] font-bold uppercase tracking-widest" style={{ color: "var(--sd-muted)" }}>
                      Subcategories
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <button
                        data-sound="none"
                        onClick={() => {
                          setActiveSub("");
                          playUISound("ui_filter", { category: "button" });
                        }}
                        className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition-all duration-300 ${activeSub === "" ? "" : "hover:-translate-y-0.5"}`}
                        style={
                          activeSub === ""
                            ? { background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))", color: "#fff" }
                            : { background: "rgba(255,255,255,0.65)", color: "var(--sd-body)", border: "1px solid rgba(191,219,254,0.7)" }
                        }
                      >
                        All Work
                      </button>
                      {subsOfCategory.map((s) => {
                        const active = activeSub === s.id;
                        return (
                          <button
                            key={s.id}
                            data-sound="none"
                            onClick={() => {
                              setActiveSub(active ? "" : s.id);
                              playUISound("ui_filter", { category: "button" });
                            }}
                            className={`rounded-full px-3.5 py-1.5 text-xs font-semibold transition-all duration-300 ${active ? "" : "hover:-translate-y-0.5"}`}
                            style={
                              active
                                ? { background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))", color: "#fff" }
                                : { background: "rgba(255,255,255,0.65)", color: "var(--sd-body)", border: "1px solid rgba(191,219,254,0.7)" }
                            }
                          >
                            {s.name}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </Reveal>
        )}

        {/* project grid — masonry with ORIGINAL image ratios (no cropping) */}
        {published.length === 0 ? (
          <div className="glass mx-auto max-w-md rounded-3xl px-8 py-12 text-center">
            <FolderKanban size={28} className="mx-auto" style={{ color: "var(--sd-primary)" }} />
            <p className="heading-text mt-3 text-lg font-bold">No projects yet</p>
            <p className="mt-2 text-sm" style={{ color: "var(--sd-muted)" }}>
              New work is on the way — check back soon.
            </p>
          </div>
        ) : visible.length === 0 ? (
          <div className="glass mx-auto max-w-md rounded-3xl px-8 py-12 text-center">
            <p className="heading-text text-lg font-bold">Nothing here yet</p>
            <p className="mt-2 text-sm" style={{ color: "var(--sd-muted)" }}>
              Try another category or subcategory to explore more projects.
            </p>
          </div>
        ) : (
          <div className="columns-1 gap-7 sm:columns-2 lg:columns-3">
            {visibleCards.map(({ img, project }, i) => (
              <Reveal key={`${project.id}-${img.url}`} delay={(i % 3) * 100} variant="scale" className="mb-7 break-inside-avoid">
                <article
                  className="portfolio-card glass group relative cursor-pointer overflow-hidden rounded-3xl transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_30px_70px_-18px_var(--sd-glow-medium)]"
                  data-sound="ui_scan"
                  onClick={() => setOpenProject(project)}
                >
                  {/* image — natural aspect ratio, no forced crop */}
                  <div className="relative overflow-hidden" style={{ background: "rgba(248,250,252,0.7)" }}>
                    <img
                      src={img.url}
                      alt={img.alt || project.title}
                      className="w-full transition-transform duration-700"
                      style={{ height: "auto", display: "block" }}
                      loading="lazy"
                      onLoad={(e) => onImageLoad(e, project, imagesOf(project).findIndex((x) => x.img.url === img.url))}
                    />
                    <div
                      className="portfolio-overlay absolute inset-0 flex items-end justify-between p-5"
                      style={{ background: "linear-gradient(180deg, rgba(15,23,42,0) 20%, rgba(37,99,235,0.55) 100%)" }}
                    >
                      <span className="translate-y-3 rounded-full bg-white/90 px-4 py-1.5 text-xs font-bold text-slate-900 backdrop-blur transition-transform duration-500 group-hover:translate-y-0">
                        View Project
                      </span>
                      <span
                        className="portfolio-arrow flex h-11 w-11 items-center justify-center rounded-full text-white"
                        style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" }}
                      >
                        <ArrowUpRight size={19} />
                      </span>
                    </div>
                    {/* category chip */}
                    <span
                      className="absolute left-4 top-4 rounded-full px-3.5 py-1.5 text-[11px] font-bold tracking-wide text-white"
                      style={{
                        background: "rgba(255,255,255,0.22)",
                        backdropFilter: "blur(10px)",
                        WebkitBackdropFilter: "blur(10px)",
                        border: "1px solid rgba(255,255,255,0.35)",
                      }}
                    >
                      {catName(project.categoryId)}
                      {subNameOf(project.subcategoryId) && ` › ${subNameOf(project.subcategoryId)}`}
                    </span>
                    {project.featured && (
                      <span
                        className="absolute right-4 top-4 rounded-full px-3 py-1.5 text-[10px] font-bold tracking-widest text-white"
                        style={{ background: "linear-gradient(120deg, #f59e0b, #f97316)", boxShadow: "0 6px 18px -4px rgba(245,158,11,0.5)" }}
                      >
                        ★ FEATURED
                      </span>
                    )}
                  </div>

                  {/* meta */}
                  <div className="flex items-center justify-between gap-3 p-5">
                    <div>
                      <h3 className="heading-text text-lg font-bold">{project.title}</h3>
                      <p className="mt-1.5 truncate text-[11px] font-semibold" style={{ color: "var(--sd-muted)" }}>
                        {[project.client, project.date].filter(Boolean).join(" · ") || catName(project.categoryId)}
                      </p>
                    </div>
                    <span
                      className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl transition-transform duration-500 group-hover:rotate-12"
                      style={{ background: "rgba(37,99,235,0.08)", color: "var(--sd-primary)" }}
                    >
                      <Layers size={17} />
                    </span>
                  </div>

                  <span
                    className="absolute bottom-0 left-1/2 h-[3px] w-0 -translate-x-1/2 rounded-full transition-all duration-500 group-hover:w-2/3"
                    style={{ background: "linear-gradient(90deg, var(--sd-primary), var(--sd-secondary))" }}
                  />
                </article>
              </Reveal>
            ))}
          </div>
        )}
      </div>

      {/* project detail modal */}
      {openProject && (
        <ProjectModal
          project={openProject}
          categoryName={catName(openProject.categoryId)}
          subName={subNameOf(openProject.subcategoryId)}
          onClose={() => setOpenProject(null)}
        />
      )}
    </section>
  );
}
