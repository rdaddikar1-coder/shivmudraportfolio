/**
 * Tiny pub-sub toast bus — callable from anywhere (settings layer, CRUD
 * tabs, forms) and rendered by the <ToastHost /> component in the admin.
 */

export type ToastKind = "success" | "error";

export interface ToastItem {
  id: number;
  kind: ToastKind;
  message: string;
}

type ToastListener = (t: ToastItem) => void;

const listeners = new Set<ToastListener>();
let toastId = 0;

function emit(kind: ToastKind, message: string) {
  const toast: ToastItem = { id: ++toastId, kind, message };
  listeners.forEach((l) => l(toast));
}

export const toast = {
  success: (message: string) => emit("success", message),
  error: (message: string) => emit("error", message),
};

export function subscribeToasts(cb: ToastListener): () => void {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
}
