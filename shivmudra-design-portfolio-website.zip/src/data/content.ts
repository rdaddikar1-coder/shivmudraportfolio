import {
  Palette,
  Globe,
  Smartphone,
  Megaphone,
  Target,
  Users,
  Camera,
  Video,
  Code2,
  Wand2,
  type LucideIcon,
} from "lucide-react";

export const NAV_LINKS = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Services", href: "#services" },
  { label: "Portfolio", href: "#portfolio" },
  { label: "Experience", href: "#experience" },
  { label: "Contact", href: "#contact" },
];

/* ------------------------------------------------------------------ */
/*  Image metadata — preserves the ORIGINAL uploaded aspect ratio     */
/* ------------------------------------------------------------------ */

export interface ImageMeta {
  url: string;
  width: number; // 0 = unknown (legacy) → render naturally
  height: number;
  aspectRatio: number; // width / height; 0 = unknown → render naturally
  fileType: string;
  fileSize: number; // bytes
  alt: string;
  createdAt: string;
}

/* ------------------------------------------------------------------ */
/*  Category / Subcategory system                                     */
/* ------------------------------------------------------------------ */

export interface CategoryItem {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: ImageMeta | null;
  order: number;
  active: boolean;
}

export interface SubcategoryItem {
  id: string;
  parentId: string; // owning category id
  name: string;
  slug: string;
  description: string;
  image: ImageMeta | null;
  order: number;
  active: boolean;
}

/* ------------------------------------------------------------------ */
/*  Content types (public site + admin CRUD)                          */
/* ------------------------------------------------------------------ */

export interface ServiceItem {
  icon: string; // key in SERVICE_ICONS
  title: string;
  description: string;
  tags: string[];
  order: number;
  active: boolean;
}

export interface PortfolioItem {
  id: string;
  title: string;
  categoryId: string;
  subcategoryId: string; // "" = none
  description: string;
  client: string;
  date: string;
  tech: string[];
  tags: string[];
  image: ImageMeta;
  gallery?: ImageMeta[]; // additional project images (cover is `image`)
  liveUrl: string;
  demoUrl: string;
  githubUrl: string;
  playStoreUrl: string;
  appStoreUrl: string;
  featured: boolean;
  published: boolean;
  order: number;
}

export interface ExperienceItem {
  period: string;
  role: string;
  company: string;
  location: string;
  description: string;
  highlights: string[];
  current: boolean;
  order: number;
  active: boolean;
}

export interface SkillItem {
  name: string;
  level: number;
  note: string;
  order: number;
  active: boolean;
}

export interface TestimonialItem {
  name: string;
  company: string;
  photo: string;
  quote: string;
  rating: number;
  order: number;
  active: boolean;
}

export interface Enquiry {
  id: string;
  name: string;
  email: string;
  projectType: string;
  message: string;
  date: string;
}

export interface MediaItem {
  id: string;
  name: string;
  url: string;
  date: string;
}

export interface WebsiteInfo {
  name: string;
  owner: string;
  copyright: string;
}

export interface SeoInfo {
  title: string;
  description: string;
  keywords: string;
  ogTitle: string;
  ogDescription: string;
  ogImage: string;
  canonical: string;
  robots: string;
}

export interface SocialLinks {
  instagram: string;
  facebook: string;
  youtube: string;
  linkedin: string;
  behance: string;
  dribbble: string;
  whatsapp: string;
}

export interface SectionVisibility {
  hero: boolean;
  about: boolean;
  services: boolean;
  portfolio: boolean;
  experience: boolean;
  skills: boolean;
  testimonials: boolean;
  stats: boolean;
  contact: boolean;
}

/** Icon keys available to services (admin icon picker + public rendering). */
export const SERVICE_ICONS: Record<string, LucideIcon> = {
  palette: Palette,
  globe: Globe,
  smartphone: Smartphone,
  megaphone: Megaphone,
  target: Target,
  users: Users,
  camera: Camera,
  video: Video,
  code: Code2,
  wand: Wand2,
};

/* ------------------------------------------------------------------ */
/*  Default categories + subcategories (fully editable in admin)      */
/* ------------------------------------------------------------------ */

const cat = (id: string, name: string, description: string, order: number): CategoryItem => ({
  id,
  name,
  slug: id,
  description,
  image: null,
  order,
  active: true,
});

export const CATEGORIES: CategoryItem[] = [
  cat("graphic-design", "Graphic Design", "Brand identities, posters, brochures and campaign creatives.", 0),
  cat("website-development", "Website Development", "Conversion-first websites built with modern stacks.", 1),
  cat("app-development", "App Development", "Sleek mobile and web app interfaces with fluid UX.", 2),
  cat("social-media-management", "Social Media Management", "Complete social presence systems that grow audiences.", 3),
  cat("meta-ads", "Meta Ads", "Data-driven Facebook & Instagram ad campaigns.", 4),
  cat("branding", "Branding", "Logos, visual identities and brand guidelines.", 5),
  cat("print-design", "Print Design", "Business cards, flyers and premium print collateral.", 6),
  cat("motion-graphics", "Motion Graphics", "Logo animations, intros and social video edits.", 7),
];

const sub = (id: string, parentId: string, name: string, order: number): SubcategoryItem => ({
  id,
  parentId,
  name,
  slug: id,
  description: "",
  image: null,
  order,
  active: true,
});

export const SUBCATEGORIES: SubcategoryItem[] = [
  sub("social-media-design", "graphic-design", "Social Media Design", 0),
  sub("poster-design", "graphic-design", "Poster Design", 1),
  sub("brochure-design", "graphic-design", "Brochure Design", 2),
  sub("advertisement-design", "graphic-design", "Advertisement", 3),
  sub("portfolio-website", "website-development", "Portfolio Website", 0),
  sub("business-website", "website-development", "Business Website", 1),
  sub("ecommerce-website", "website-development", "E-commerce", 2),
  sub("landing-page", "website-development", "Landing Page", 3),
  sub("saas-website", "website-development", "SaaS", 4),
  sub("android-app", "app-development", "Android App", 0),
  sub("flutter-app", "app-development", "Flutter App", 1),
  sub("ios-app", "app-development", "iOS App", 2),
  sub("web-app", "app-development", "Web App", 3),
  sub("content-creation", "social-media-management", "Content Creation", 0),
  sub("reels-shorts", "social-media-management", "Reels & Shorts", 1),
  sub("community-management", "social-media-management", "Community Management", 2),
  sub("lead-generation", "meta-ads", "Lead Generation", 0),
  sub("ecommerce-ads", "meta-ads", "E-commerce Ads", 1),
  sub("retargeting", "meta-ads", "Retargeting", 2),
  sub("logo-design", "branding", "Logo Design", 0),
  sub("visual-identity", "branding", "Visual Identity", 1),
  sub("brand-guidelines", "branding", "Brand Guidelines", 2),
  sub("business-cards", "print-design", "Business Cards", 0),
  sub("flyers", "print-design", "Flyers", 1),
  sub("posters-print", "print-design", "Posters", 2),
  sub("logo-animation", "motion-graphics", "Logo Animation", 0),
  sub("intro-videos", "motion-graphics", "Intro Videos", 1),
  sub("social-video", "motion-graphics", "Social Video", 2),
];

/* ------------------------------------------------------------------ */
/*  Initial (default) content — editable from the Admin Dashboard     */
/* ------------------------------------------------------------------ */

export const SERVICES: ServiceItem[] = [
  {
    icon: "palette",
    title: "Graphic Design",
    description:
      "Logos, brand identities, posters and marketing collateral engineered with precision and creative depth.",
    tags: ["Branding", "Logo", "Print"],
    order: 0,
    active: true,
  },
  {
    icon: "globe",
    title: "Website Development",
    description:
      "Blazing-fast, elegant websites and landing pages built with modern stacks and conversion-first design.",
    tags: ["React", "Landing Pages", "SEO"],
    order: 1,
    active: true,
  },
  {
    icon: "smartphone",
    title: "App Development",
    description:
      "Sleek mobile app interfaces and cross-platform products with fluid, futuristic user experiences.",
    tags: ["UI/UX", "Android", "iOS"],
    order: 2,
    active: true,
  },
  {
    icon: "megaphone",
    title: "Social Media Management",
    description:
      "Complete social presence systems — content calendars, creatives and growth strategies that engage.",
    tags: ["Content", "Strategy", "Growth"],
    order: 3,
    active: true,
  },
  {
    icon: "target",
    title: "Meta Ads",
    description:
      "Data-driven Facebook & Instagram ad campaigns with sharp targeting, creatives and funnel optimization.",
    tags: ["Facebook", "Instagram", "Funnels"],
    order: 4,
    active: true,
  },
  {
    icon: "users",
    title: "Team Leadership",
    description:
      "Leading creative teams with clear vision, structured workflows and mentorship that ships exceptional work.",
    tags: ["Mentorship", "Workflow", "Vision"],
    order: 5,
    active: true,
  },
];

const legacyImage = (url: string, alt: string): ImageMeta => ({
  url,
  width: 0,
  height: 0,
  aspectRatio: 0,
  fileType: "image/jpeg",
  fileSize: 0,
  alt,
  createdAt: "",
});

export const PORTFOLIO: PortfolioItem[] = [
  {
    id: "lumina-brand-identity",
    title: "Lumina Brand Identity",
    categoryId: "graphic-design",
    subcategoryId: "visual-identity",
    description: "A complete visual identity system for a luxury lighting brand — logo, stationery and print collateral.",
    client: "Lumina Studio",
    date: "2024",
    tech: ["Photoshop", "CorelDRAW"],
    tags: ["Branding", "Print Design"],
    image: legacyImage("/images/portfolio-1.jpg", "Lumina Brand Identity"),
    liveUrl: "",
    demoUrl: "",
    githubUrl: "",
    playStoreUrl: "",
    appStoreUrl: "",
    featured: true,
    published: true,
    order: 0,
  },
  {
    id: "nexaweb-platform",
    title: "NexaWeb Platform",
    categoryId: "website-development",
    subcategoryId: "business-website",
    description: "A conversion-first marketing website with glassmorphism UI and a custom CMS-driven blog.",
    client: "NexaWeb",
    date: "2024",
    tech: ["React", "Tailwind"],
    tags: ["Web Design", "UI/UX"],
    image: legacyImage("/images/portfolio-2.jpg", "NexaWeb Platform"),
    liveUrl: "",
    demoUrl: "",
    githubUrl: "",
    playStoreUrl: "",
    appStoreUrl: "",
    featured: false,
    published: true,
    order: 1,
  },
  {
    id: "payflow-fintech-app",
    title: "PayFlow Fintech App",
    categoryId: "app-development",
    subcategoryId: "flutter-app",
    description: "A clean fintech app interface with dashboards, charts and seamless onboarding flows.",
    client: "PayFlow",
    date: "2023",
    tech: ["UI/UX", "Figma"],
    tags: ["Mobile", "Fintech"],
    image: legacyImage("/images/portfolio-3.jpg", "PayFlow Fintech App"),
    liveUrl: "",
    demoUrl: "",
    githubUrl: "",
    playStoreUrl: "",
    appStoreUrl: "",
    featured: false,
    published: true,
    order: 2,
  },
  {
    id: "aurora-social-kit",
    title: "Aurora Social Kit",
    categoryId: "social-media-management",
    subcategoryId: "content-creation",
    description: "A 30-day social content system — templates, reels covers and a growth content calendar.",
    client: "Aurora Cafe",
    date: "2023",
    tech: ["Photoshop", "CapCut"],
    tags: ["Content", "Instagram"],
    image: legacyImage("/images/portfolio-4.jpg", "Aurora Social Kit"),
    liveUrl: "",
    demoUrl: "",
    githubUrl: "",
    playStoreUrl: "",
    appStoreUrl: "",
    featured: false,
    published: true,
    order: 3,
  },
  {
    id: "boostiq-ad-campaigns",
    title: "BoostIQ Ad Campaigns",
    categoryId: "meta-ads",
    subcategoryId: "lead-generation",
    description: "Performance Meta ad campaigns with creative testing funnels that lifted ROAS to 3.2x.",
    client: "BoostIQ",
    date: "2023",
    tech: ["Meta Ads", "Analytics"],
    tags: ["Advertising", "Analytics"],
    image: legacyImage("/images/portfolio-5.jpg", "BoostIQ Ad Campaigns"),
    liveUrl: "",
    demoUrl: "",
    githubUrl: "",
    playStoreUrl: "",
    appStoreUrl: "",
    featured: false,
    published: true,
    order: 4,
  },
  {
    id: "motionreel-editing",
    title: "MotionReel Editing",
    categoryId: "motion-graphics",
    subcategoryId: "social-video",
    description: "A cinematic showreel of product edits, logo animations and social video cuts.",
    client: "MotionReel",
    date: "2024",
    tech: ["Filmora", "CapCut"],
    tags: ["Video Editing", "Filmora"],
    image: legacyImage("/images/portfolio-6.jpg", "MotionReel Editing"),
    liveUrl: "",
    demoUrl: "",
    githubUrl: "",
    playStoreUrl: "",
    appStoreUrl: "",
    featured: false,
    published: true,
    order: 5,
  },
];

export const EXPERIENCE: ExperienceItem[] = [
  {
    period: "2023 — Present",
    role: "Founder & Creative Director",
    company: "Shivmudra Design",
    location: "Mumbai, India",
    description:
      "Leading a creative studio delivering brand identities, websites and ad campaigns for clients across industries.",
    highlights: ["150+ projects shipped", "Built a 6-member creative team", "98% client retention"],
    current: true,
    order: 0,
    active: true,
  },
  {
    period: "2021 — 2023",
    role: "Senior Graphic Designer",
    company: "PixelForge Studio",
    location: "Mumbai, India",
    description:
      "Directed visual identity systems and campaign creatives for D2C and e-commerce brands at scale.",
    highlights: ["30+ brand identities", "Ad creatives with 4x CTR lift"],
    current: false,
    order: 1,
    active: true,
  },
  {
    period: "2020 — 2021",
    role: "Web & App Developer",
    company: "CloudNine Tech",
    location: "Pune, India",
    description:
      "Designed and developed responsive websites and mobile app interfaces with modern JavaScript stacks.",
    highlights: ["20+ websites launched", "2 apps on Play Store"],
    current: false,
    order: 2,
    active: true,
  },
  {
    period: "2019 — 2020",
    role: "Meta Ads Specialist",
    company: "Freelance",
    location: "Remote",
    description:
      "Ran performance ad campaigns for small businesses, mastering audience targeting and creative testing.",
    highlights: ["₹40L+ ad spend managed", "3.2x average ROAS"],
    current: false,
    order: 3,
    active: true,
  },
];

export const SKILLS: SkillItem[] = [
  { name: "Photoshop", level: 95, note: "Retouching & composites", order: 0, active: true },
  { name: "CorelDRAW", level: 90, note: "Vector & print design", order: 1, active: true },
  { name: "ChatGPT", level: 92, note: "AI-assisted creativity", order: 2, active: true },
  { name: "Gemini", level: 85, note: "AI research & writing", order: 3, active: true },
  { name: "Filmora", level: 88, note: "Cinematic video edits", order: 4, active: true },
  { name: "CapCut", level: 90, note: "Social video & reels", order: 5, active: true },
];

/* No fake testimonials — admins add real ones from the dashboard. */
export const TESTIMONIALS: TestimonialItem[] = [];

export const WEBSITE_INFO: WebsiteInfo = {
  name: "Shivmudra Design",
  owner: "Shivmudra",
  copyright: "Shivmudra Design",
};

export const SEO_INFO: SeoInfo = {
  title: "Shivmudra Design — Premium Creative Studio",
  description:
    "Shivmudra Design is a premium creative studio crafting brand identities, websites, apps and ad campaigns inside a futuristic white galaxy.",
  keywords:
    "graphic design, website development, app development, social media management, meta ads, branding, motion graphics, shivmudra design",
  ogTitle: "Shivmudra Design — Premium Creative Studio",
  ogDescription:
    "Brand identities, websites, apps and ad campaigns crafted inside a futuristic white galaxy.",
  ogImage: "/images/hero.jpg",
  canonical: "https://shivmudra.design/",
  robots: "index, follow",
};

export const SOCIAL_LINKS: SocialLinks = {
  instagram: "https://instagram.com/shivmudra.design",
  facebook: "",
  youtube: "",
  linkedin: "",
  behance: "",
  dribbble: "",
  whatsapp: "https://wa.me/919876543210",
};

export const SECTION_VISIBILITY: SectionVisibility = {
  hero: true,
  about: true,
  services: true,
  portfolio: true,
  experience: true,
  skills: true,
  testimonials: true,
  stats: true,
  contact: true,
};

export const ABOUT_CONTENT = {
  aboutTitle: "The Creative Mind Behind Shivmudra Design",
  aboutText1:
    "I'm a multidisciplinary designer and developer who blends art with technology. From pixel-perfect brand identities to high-converting websites, apps and ad campaigns — I build complete digital experiences that help brands stand out in a crowded universe.",
  aboutText2:
    "What started as a passion for design has grown into a full creative studio — leading a talented team, serving 80+ clients and shipping 300+ creative projects across the globe.",
};

export const STATS_META = [
  { key: "projects", label: "Projects Completed", suffix: "+" },
  { key: "years", label: "Years Experience", suffix: "+" },
  { key: "creative", label: "Creative Projects", suffix: "+" },
  { key: "clients", label: "Happy Clients", suffix: "+" },
] as const;
