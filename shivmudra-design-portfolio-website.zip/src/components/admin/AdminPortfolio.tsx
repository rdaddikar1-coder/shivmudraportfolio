import { useState } from "react";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { useSettings } from "../../lib/settings";
import { playUISound } from "../../lib/uiSound";
import { toast } from "../../lib/toast";
import { readImageMeta, ratioLabel, formatFileSize } from "../../lib/imageUtils";
import type { CategoryItem, SubcategoryItem, PortfolioItem, ImageMeta } from "../../data/content";
import { SaveBar, useSaveState, ConfirmDeleteButton, DuplicateButton } from "./ui";

/* ------------------------------------------------------------------ */
/*  Shared primitives (local copies for this module)                  */
/* ------------------------------------------------------------------ */

const labelCls = "mb-1.5 text-[11px] font-bold uppercase tracking-widest";
const inputCls =
  "glass w-full rounded-xl px-4 py-2.5 text-sm font-medium outline-none transition-shadow focus:shadow-[0_0_0_3px_var(--sd-glow-soft)]";

function CrudField({ label, value, onChange, placeholder, type = "text" }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <p className={labelCls} style={{ color: "var(--sd-muted)" }}>{label}</p>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className={inputCls} style={{ color: "var(--sd-heading)" }} />
    </div>
  );
}

function CrudTextarea({ label, value, onChange, rows = 3, placeholder }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  rows?: number;
  placeholder?: string;
}) {
  return (
    <div>
      <p className={labelCls} style={{ color: "var(--sd-muted)" }}>{label}</p>
      <textarea value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} rows={rows} className={`${inputCls} resize-none`} style={{ color: "var(--sd-heading)" }} />
    </div>
  );
}

function CrudSelect({ label, value, onChange, options }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <div>
      <p className={labelCls} style={{ color: "var(--sd-muted)" }}>{label}</p>
      <select value={value} onChange={(e) => onChange(e.target.value)} className={inputCls} style={{ color: "var(--sd-heading)" }}>
        {options.map((opt) => (
          <option key={opt.value} value={opt.value} className="bg-white text-slate-900">{opt.label}</option>
        ))}
      </select>
    </div>
  );
}

function CrudCheckbox({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label className="glass flex cursor-pointer items-center justify-between gap-3 rounded-xl px-4 py-3" style={{ color: "var(--sd-heading)" }}>
      <span className="text-sm font-semibold">{label}</span>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="cursor-pointer" style={{ accentColor: "var(--sd-primary)", width: 18, height: 18 }} />
    </label>
  );
}

function EditPanel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-3xl p-5 sm:p-6" style={{ background: "rgba(255,255,255,0.75)", border: "1.5px dashed rgba(37,99,235,0.45)" }}>
      <p className="mb-4 text-sm font-bold" style={{ color: "var(--sd-heading)" }}>{title}</p>
      <div className="grid gap-4 sm:grid-cols-2">{children}</div>
    </div>
  );
}

function AddButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      data-sound="none"
      className="flex items-center gap-2 rounded-full px-5 py-2.5 text-xs font-bold text-white transition-transform hover:-translate-y-0.5"
      style={{ background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))", boxShadow: "0 8px 20px -6px var(--sd-glow-medium)" }}
    >
      <Plus size={15} />
      {label}
    </button>
  );
}

function TabHeader({ title, subtitle, action }: { title: string; subtitle: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div>
        <h2 className="heading-text text-xl font-bold">{title}</h2>
        <p className="mt-0.5 text-xs" style={{ color: "var(--sd-muted)" }}>{subtitle}</p>
      </div>
      {action}
    </div>
  );
}

function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

function uniqueSlug(base: string, existing: string[]): string {
  let slug = base || "item";
  let i = 2;
  while (existing.includes(slug)) {
    slug = `${base}-${i}`;
    i += 1;
  }
  return slug;
}

/* ------------------------------------------------------------------ */
/*  Image uploader — upload → preview → replace/delete                */
/*  Automatic dimension + aspect-ratio detection, alt text            */
/* ------------------------------------------------------------------ */

export function ImageUploader({ image, altFallback, onChange, label = "Image" }: {
  image: ImageMeta | null;
  altFallback: string;
  onChange: (img: ImageMeta | null) => void;
  label?: string;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFile = async (file: File) => {
    setError(null);
    setBusy(true);
    const result = await readImageMeta(file, altFallback);
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      playUISound("ui_error", { category: "admin", soft: true });
      return;
    }
    onChange(result.meta);
    playUISound("ui_upload", { category: "admin", soft: true });
  };

  return (
    <div className="sm:col-span-2">
      <p className={labelCls} style={{ color: "var(--sd-muted)" }}>{label}</p>

      {image ? (
        <div className="glass rounded-2xl p-4">
          <div className="flex flex-col gap-4 sm:flex-row">
            <img
              src={image.url}
              alt={image.alt || altFallback}
              className="w-auto max-h-44 rounded-xl object-contain"
              style={{ background: "rgba(248,250,252,0.8)" }}
            />
            <div className="min-w-0 flex-1">
              <p className="text-sm font-bold" style={{ color: "var(--sd-heading)" }}>
                {image.width || "?"} × {image.height || "?"}
              </p>
              <p className="mt-1 text-xs font-semibold" style={{ color: "var(--sd-primary)" }}>
                Aspect Ratio: {ratioLabel(image.width, image.height)}
              </p>
              <p className="mt-1 text-xs" style={{ color: "var(--sd-muted)" }}>
                {formatFileSize(image.fileSize)} · {image.fileType.replace("image/", "").toUpperCase()}
              </p>
              <p className="mt-1 text-[10px] font-semibold" style={{ color: "var(--sd-muted)" }}>
                Original ratio preserved — no cropping, no stretching
              </p>
              <div className="mt-3 flex gap-2">
                <label
                  className="glass flex cursor-pointer items-center gap-1.5 rounded-full px-4 py-2 text-[11px] font-bold transition-transform hover:-translate-y-0.5"
                  style={{ color: "var(--sd-heading)" }}
                >
                  Replace Image
                  <input
                    type="file"
                    accept="image/jpeg,image/png,image/webp"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) void handleFile(file);
                      e.target.value = "";
                    }}
                  />
                </label>
                <button
                  type="button"
                  data-sound="none"
                  onClick={() => {
                    onChange(null);
                    playUISound("ui_delete", { category: "admin", soft: true });
                  }}
                  className="flex items-center gap-1.5 rounded-full px-4 py-2 text-[11px] font-bold text-white"
                  style={{ background: "#ef4444" }}
                >
                  <Trash2 size={12} />
                  Delete Image
                </button>
              </div>
            </div>
          </div>

          <div className="mt-4">
            <p className={`${labelCls} !mb-1`} style={{ color: "var(--sd-muted)" }}>Alt Text</p>
            <input
              type="text"
              value={image.alt}
              onChange={(e) => onChange({ ...image, alt: e.target.value })}
              placeholder={altFallback}
              className={inputCls}
              style={{ color: "var(--sd-heading)" }}
            />
            <p className="mt-1 text-[10px]" style={{ color: "var(--sd-muted)" }}>
              Falls back to “{altFallback || "item name"}” automatically when empty.
            </p>
          </div>
        </div>
      ) : (
        <label
          className="flex cursor-pointer flex-col items-center justify-center rounded-2xl border-2 border-dashed px-6 py-8 transition-colors"
          style={{ borderColor: "rgba(37,99,235,0.4)", background: "rgba(255,255,255,0.6)" }}
        >
          {busy ? (
            <p className="text-sm font-bold" style={{ color: "var(--sd-primary)" }}>Detecting dimensions…</p>
          ) : (
            <>
              <p className="text-sm font-bold" style={{ color: "var(--sd-heading)" }}>Upload Image</p>
              <p className="mt-1 text-xs" style={{ color: "var(--sd-muted)" }}>JPG · JPEG · PNG · WEBP — max 2 MB</p>
            </>
          )}
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) void handleFile(file);
              e.target.value = "";
            }}
          />
        </label>
      )}

      {error && <p className="mt-2 text-xs font-bold" style={{ color: "#ef4444" }}>{error}</p>}
    </div>
  );
}

/* ================================================================== */
/*  Categories + Subcategories management                              */
/* ================================================================== */

interface CategoryDraft {
  name: string;
  slug: string;
  description: string;
  order: string;
  active: boolean;
  image: ImageMeta | null;
}

interface SubDraft {
  parentId: string;
  name: string;
  slug: string;
  description: string;
  order: string;
  active: boolean;
  image: ImageMeta | null;
}

export function CategoriesTab() {
  const { settings, saveSection } = useSettings();
  const { categories, subcategories, portfolio } = settings.content;
  const { status: catStatus, run: runCat } = useSaveState();
  const { status: subStatus, run: runSub } = useSaveState();

  const [catEditing, setCatEditing] = useState<number | "new" | null>(null);
  const [catDraft, setCatDraft] = useState<CategoryDraft>({ name: "", slug: "", description: "", order: "0", active: true, image: null });
  const [catError, setCatError] = useState<string | null>(null);

  const [subEditing, setSubEditing] = useState<{ mode: "new" | "edit"; index: number; parentId: string } | null>(null);
  const [subDraft, setSubDraft] = useState<SubDraft>({ parentId: "", name: "", slug: "", description: "", order: "0", active: true, image: null });
  const [subError, setSubError] = useState<string | null>(null);

  const [expanded, setExpanded] = useState<string | null>(null);

  const subsOf = (catId: string) => subcategories.filter((s) => s.parentId === catId).sort((a, b) => a.order - b.order);
  const projectCountOf = (catId: string) => portfolio.filter((p) => p.categoryId === catId).length;
  const projectCountOfSub = (subId: string) => portfolio.filter((p) => p.subcategoryId === subId).length;

  /* ---------------- category CRUD ---------------- */

  const startCatNew = () => {
    setCatDraft({ name: "", slug: "", description: "", order: String(categories.length), active: true, image: null });
    setCatError(null);
    setCatEditing("new");
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const startCatEdit = (i: number) => {
    const c = categories[i];
    setCatDraft({ name: c.name, slug: c.slug, description: c.description, order: String(c.order), active: c.active, image: c.image });
    setCatError(null);
    setCatEditing(i);
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const cancelCat = () => { setCatEditing(null); setCatError(null); };

  const saveCategory = () => runCat(async () => {
    if (catEditing === null) return false;
    if (!catDraft.name.trim()) return failCat("Category name is required.");
    const slug = slugify(catDraft.slug || catDraft.name);
    const others = categories.filter((_, i) => i !== catEditing).map((c) => c.slug);
    if (others.includes(slug)) return failCat("That slug is already in use — choose another.");
    const item: CategoryItem = {
      id: catEditing === "new" ? uniqueSlug(slug, categories.map((c) => c.id)) : categories[catEditing].id,
      name: catDraft.name.trim(),
      slug,
      description: catDraft.description.trim(),
      image: catDraft.image,
      order: Number(catDraft.order) || 0,
      active: catDraft.active,
    };
    const next = catEditing === "new" ? [...categories, item] : categories.map((c, i) => (i === catEditing ? item : c));
    const ok = await saveSection("content", { ...settings.content, categories: next });
    if (ok) {
      toast.success(`Category ${catEditing === "new" ? "created" : "updated"} successfully`);
      cancelCat();
    }
    return ok;
  });
  const failCat = (msg: string) => { setCatError(msg); playUISound("ui_error", { category: "admin", soft: true }); return false; };

  const deleteCategory = async (i: number) => {
    const c = categories[i];
    if (subsOf(c.id).length > 0 || projectCountOf(c.id) > 0) {
      toast.error("This category contains subcategories/projects. Please reassign or remove them before deleting the category.");
      playUISound("ui_error", { category: "admin", soft: true });
      return;
    }
    const ok = await saveSection("content", { ...settings.content, categories: categories.filter((_, idx) => idx !== i) });
    if (ok) { toast.success("Category deleted"); playUISound("ui_delete", { category: "admin", soft: true }); }
  };

  /* ---------------- subcategory CRUD ---------------- */

  const startSubNew = (parentId: string) => {
    setSubDraft({ parentId, name: "", slug: "", description: "", order: String(subsOf(parentId).length), active: true, image: null });
    setSubError(null);
    setSubEditing({ mode: "new", index: -1, parentId });
    setExpanded(parentId);
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const startSubEdit = (index: number) => {
    const s = subcategories[index];
    setSubDraft({ parentId: s.parentId, name: s.name, slug: s.slug, description: s.description, order: String(s.order), active: s.active, image: s.image });
    setSubError(null);
    setSubEditing({ mode: "edit", index, parentId: s.parentId });
    setExpanded(s.parentId);
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const cancelSub = () => { setSubEditing(null); setSubError(null); };

  const saveSubcategory = () => runSub(async () => {
    if (subEditing === null) return false;
    if (!subDraft.parentId) return failSub("Parent category is required.");
    if (!subDraft.name.trim()) return failSub("Subcategory name is required.");
    const slug = slugify(subDraft.slug || subDraft.name);
    const others = subcategories.filter((_, i) => i !== subEditing.index).map((s) => s.slug);
    if (others.includes(slug)) return failSub("That slug is already in use — choose another.");
    const item: SubcategoryItem = {
      id: subEditing.mode === "new" ? uniqueSlug(slug, subcategories.map((s) => s.id)) : subcategories[subEditing.index].id,
      parentId: subDraft.parentId,
      name: subDraft.name.trim(),
      slug,
      description: subDraft.description.trim(),
      image: subDraft.image,
      order: Number(subDraft.order) || 0,
      active: subDraft.active,
    };
    const next =
      subEditing?.mode === "new"
        ? [...subcategories, item]
        : subcategories.map((s, i) => (i === subEditing?.index ? item : s));
    const ok = await saveSection("content", { ...settings.content, subcategories: next });
    if (ok) {
      toast.success(`Subcategory ${subEditing?.mode === "new" ? "created" : "updated"} successfully`);
      cancelSub();
    }
    return ok;
  });
  const failSub = (msg: string) => { setSubError(msg); playUISound("ui_error", { category: "admin", soft: true }); return false; };

  const deleteSubcategory = async (index: number) => {
    const s = subcategories[index];
    if (projectCountOfSub(s.id) > 0) {
      toast.error("This subcategory contains projects. Please reassign or remove them before deleting the subcategory.");
      playUISound("ui_error", { category: "admin", soft: true });
      return;
    }
    const ok = await saveSection("content", { ...settings.content, subcategories: subcategories.filter((_, i) => i !== index) });
    if (ok) { toast.success("Subcategory deleted"); playUISound("ui_delete", { category: "admin", soft: true }); }
  };

  /* ---------------- render ---------------- */

  return (
    <div className="space-y-4">
      <TabHeader
        title="Portfolio Categories"
        subtitle={`${categories.length} categories · ${subcategories.length} subcategories · fully dynamic`}
        action={catEditing === null ? <AddButton label="Add Category" onClick={startCatNew} /> : undefined}
      />

      {/* category edit form */}
      {catEditing !== null && (
        <EditPanel title={catEditing === "new" ? "New Category" : "Edit Category"}>
          <CrudField label="Category Name" value={catDraft.name} onChange={(v) => setCatDraft({ ...catDraft, name: v })} placeholder="Graphic Design" />
          <CrudField label="Slug" value={catDraft.slug} onChange={(v) => setCatDraft({ ...catDraft, slug: v })} placeholder="auto-generated from name" />
          <CrudTextarea label="Description" value={catDraft.description} onChange={(v) => setCatDraft({ ...catDraft, description: v })} rows={2} />
          <ImageUploader
            label="Category Image"
            image={catDraft.image}
            altFallback={catDraft.name}
            onChange={(img) => setCatDraft({ ...catDraft, image: img })}
          />
          <CrudField label="Display Order" type="number" value={catDraft.order} onChange={(v) => setCatDraft({ ...catDraft, order: v })} placeholder="0" />
          <CrudCheckbox label="Active (visible on website)" checked={catDraft.active} onChange={(v) => setCatDraft({ ...catDraft, active: v })} />
          <div className="sm:col-span-2">
            <SaveBar
              status={catStatus}
              dirty
              onSave={saveCategory}
              onCancel={cancelCat}
              label="Save Category"
              extra={catError ? <span className="text-xs font-bold" style={{ color: "#ef4444" }}>{catError}</span> : undefined}
            />
          </div>
        </EditPanel>
      )}

      {/* subcategory edit form */}
      {subEditing !== null && (
        <EditPanel title={subEditing.mode === "new" ? "New Subcategory" : "Edit Subcategory"}>
          <CrudSelect
            label="Parent Category"
            value={subDraft.parentId}
            onChange={(v) => setSubDraft({ ...subDraft, parentId: v })}
            options={categories.map((c) => ({ value: c.id, label: c.name }))}
          />
          <CrudField label="Subcategory Name" value={subDraft.name} onChange={(v) => setSubDraft({ ...subDraft, name: v })} placeholder="Business Website" />
          <CrudField label="Slug" value={subDraft.slug} onChange={(v) => setSubDraft({ ...subDraft, slug: v })} placeholder="auto-generated from name" />
          <CrudTextarea label="Description" value={subDraft.description} onChange={(v) => setSubDraft({ ...subDraft, description: v })} rows={2} />
          <ImageUploader
            label="Subcategory Image"
            image={subDraft.image}
            altFallback={subDraft.name}
            onChange={(img) => setSubDraft({ ...subDraft, image: img })}
          />
          <CrudField label="Display Order" type="number" value={subDraft.order} onChange={(v) => setSubDraft({ ...subDraft, order: v })} placeholder="0" />
          <CrudCheckbox label="Active" checked={subDraft.active} onChange={(v) => setSubDraft({ ...subDraft, active: v })} />
          <div className="sm:col-span-2">
            <SaveBar
              status={subStatus}
              dirty
              onSave={saveSubcategory}
              onCancel={cancelSub}
              label="Save Subcategory"
              extra={subError ? <span className="text-xs font-bold" style={{ color: "#ef4444" }}>{subError}</span> : undefined}
            />
          </div>
        </EditPanel>
      )}

      {/* category list */}
      {categories.length === 0 && catEditing === null ? (
        <div className="glass flex flex-col items-center rounded-2xl px-6 py-10 text-center">
          <p className="text-sm font-bold" style={{ color: "var(--sd-heading)" }}>No categories yet</p>
          <p className="mt-1 text-xs" style={{ color: "var(--sd-muted)" }}>Add your first category to organise your portfolio.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {categories.map((c, i) => {
            const subs = subsOf(c.id);
            const isOpen = expanded === c.id;
            return (
              <div key={c.id} className="glass overflow-hidden rounded-2xl">
                <div className="flex items-center gap-4 p-3">
                  {c.image ? (
                    <img src={c.image.url} alt={c.image.alt || c.name} className="h-14 w-20 shrink-0 rounded-xl object-contain" style={{ background: "rgba(248,250,252,0.8)" }} />
                  ) : (
                    <span className="flex h-14 w-20 shrink-0 items-center justify-center rounded-xl text-[10px] font-bold" style={{ background: "rgba(37,99,235,0.08)", color: "var(--sd-primary)" }}>
                      NO IMAGE
                    </span>
                  )}
                  <div className="min-w-0 flex-1">
                    <p className="flex items-center gap-2 text-sm font-bold" style={{ color: "var(--sd-heading)" }}>
                      {c.name}
                      {!c.active && <span className="rounded-full px-2 py-0.5 text-[9px] font-bold" style={{ background: "rgba(148,163,184,0.2)", color: "var(--sd-muted)" }}>INACTIVE</span>}
                    </p>
                    <p className="truncate text-xs" style={{ color: "var(--sd-muted)" }}>
                      {subs.length} subcategor{subs.length === 1 ? "y" : "ies"} · {projectCountOf(c.id)} project{projectCountOf(c.id) === 1 ? "" : "s"}
                      {c.description && ` · ${c.description}`}
                    </p>
                  </div>
                  <button
                    type="button"
                    data-sound="none"
                    onClick={() => {
                      setExpanded(isOpen ? null : c.id);
                      playUISound("ui_click", { category: "admin", soft: true });
                    }}
                    className="glass flex h-9 items-center gap-1.5 rounded-xl px-3 text-[11px] font-bold transition-transform hover:scale-105"
                    style={{ color: "var(--sd-primary)" }}
                    aria-expanded={isOpen}
                  >
                    Subcategories
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" style={{ transform: isOpen ? "rotate(180deg)" : "none", transition: "transform 0.3s" }}>
                      <path d="m6 9 6 6 6-6" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </button>
                  <button onClick={() => startCatEdit(i)} data-sound="none" className="glass flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-transform hover:scale-110" style={{ color: "var(--sd-primary)" }} aria-label="Edit category">
                    <Pencil size={14} />
                  </button>
                  <ConfirmDeleteButton onConfirm={() => deleteCategory(i)} label="Delete category" />
                </div>

                {/* subcategories */}
                {isOpen && (
                  <div className="border-t px-4 pb-4 pt-3" style={{ borderColor: "rgba(191,219,254,0.6)", background: "rgba(248,250,252,0.4)" }}>
                    {subs.length === 0 ? (
                      <p className="mb-3 text-xs" style={{ color: "var(--sd-muted)" }}>No subcategories in this category yet.</p>
                    ) : (
                      <div className="mb-3 space-y-2">
                        {subs.map((s) => {
                          const globalIndex = subcategories.findIndex((x) => x.id === s.id);
                          return (
                            <div key={s.id} className="glass flex items-center gap-3 rounded-xl px-3 py-2.5">
                              {s.image ? (
                                <img src={s.image.url} alt={s.image.alt || s.name} className="h-9 w-12 shrink-0 rounded-lg object-contain" style={{ background: "rgba(248,250,252,0.8)" }} />
                              ) : (
                                <span className="flex h-9 w-12 shrink-0 items-center justify-center rounded-lg text-[9px] font-bold" style={{ background: "rgba(37,99,235,0.08)", color: "var(--sd-primary)" }}>
                                  IMG
                                </span>
                              )}
                              <div className="min-w-0 flex-1">
                                <p className="flex items-center gap-2 truncate text-xs font-bold" style={{ color: "var(--sd-heading)" }}>
                                  {s.name}
                                  {!s.active && <span className="rounded-full px-1.5 py-0.5 text-[8px] font-bold" style={{ background: "rgba(148,163,184,0.2)", color: "var(--sd-muted)" }}>OFF</span>}
                                </p>
                                <p className="truncate text-[11px]" style={{ color: "var(--sd-muted)" }}>
                                  {projectCountOfSub(s.id)} project{projectCountOfSub(s.id) === 1 ? "" : "s"}
                                </p>
                              </div>
                              <button onClick={() => startSubEdit(globalIndex)} data-sound="none" className="glass flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-transform hover:scale-110" style={{ color: "var(--sd-primary)" }} aria-label="Edit subcategory">
                                <Pencil size={13} />
                              </button>
                              <ConfirmDeleteButton onConfirm={() => deleteSubcategory(globalIndex)} label="Delete subcategory" />
                            </div>
                          );
                        })}
                      </div>
                    )}
                    <button
                      type="button"
                      data-sound="none"
                      onClick={() => startSubNew(c.id)}
                      className="flex items-center gap-1.5 rounded-full px-4 py-2 text-[11px] font-bold text-white transition-transform hover:-translate-y-0.5"
                      style={{ background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))" }}
                    >
                      <Plus size={13} />
                      Add Subcategory
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  Portfolio projects — Category → Subcategory → Image → Links       */
/* ================================================================== */

interface ProjectDraft {
  title: string;
  categoryId: string;
  subcategoryId: string;
  description: string;
  client: string;
  date: string;
  tech: string;
  tags: string;
  image: ImageMeta | null;
  gallery: ImageMeta[];
  liveUrl: string;
  demoUrl: string;
  githubUrl: string;
  playStoreUrl: string;
  appStoreUrl: string;
  featured: boolean;
  published: boolean;
  order: string;
}

const emptyProjectDraft = (): ProjectDraft => ({
  title: "",
  categoryId: "",
  subcategoryId: "",
  description: "",
  client: "",
  date: "",
  tech: "",
  tags: "",
  image: null,
  gallery: [],
  liveUrl: "",
  demoUrl: "",
  githubUrl: "",
  playStoreUrl: "",
  appStoreUrl: "",
  featured: false,
  published: true,
  order: "0",
});

export function PortfolioTab() {
  const { settings, saveSection } = useSettings();
  const { categories, subcategories, portfolio } = settings.content;
  const [editing, setEditing] = useState<number | "new" | null>(null);
  const [draft, setDraft] = useState<ProjectDraft>(emptyProjectDraft);
  const [error, setError] = useState<string | null>(null);
  const { status, run } = useSaveState();

  const sortedCategories = [...categories].sort((a, b) => a.order - b.order);
  const subsOfCategory = (catId: string) => subcategories.filter((s) => s.parentId === catId).sort((a, b) => a.order - b.order);
  const categoryName = (id: string) => categories.find((c) => c.id === id)?.name ?? "Uncategorised";
  const subName = (id: string) => (id ? subcategories.find((s) => s.id === id)?.name ?? "" : "");

  const startNew = () => {
    setDraft({ ...emptyProjectDraft(), order: String(portfolio.length), categoryId: sortedCategories[0]?.id ?? "" });
    setError(null);
    setEditing("new");
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const startEdit = (i: number) => {
    const it = portfolio[i];
    setDraft({
      title: it.title,
      categoryId: it.categoryId,
      subcategoryId: it.subcategoryId,
      description: it.description,
      client: it.client,
      date: it.date,
      tech: it.tech.join(", "),
      tags: it.tags.join(", "),
      image: it.image,
      gallery: it.gallery ?? [],
      liveUrl: it.liveUrl,
      demoUrl: it.demoUrl,
      githubUrl: it.githubUrl,
      playStoreUrl: it.playStoreUrl,
      appStoreUrl: it.appStoreUrl,
      featured: it.featured,
      published: it.published,
      order: String(it.order),
    });
    setError(null);
    setEditing(i);
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const cancel = () => { setEditing(null); setError(null); };
  const fail = (msg: string) => { setError(msg); playUISound("ui_error", { category: "admin", soft: true }); return false; };

  const save = () => run(async () => {
    if (editing === null) return false;
    if (!draft.title.trim()) return fail("Project name is required.");
    if (!draft.categoryId) return fail("Please select a category.");
    if (!draft.image) return fail("A project image is required.");
    const alt = draft.image.alt?.trim() || draft.title.trim();
    const item: PortfolioItem = {
      id: editing === "new" ? uniqueSlug(slugify(draft.title) || "project", portfolio.map((p) => p.id)) : portfolio[editing].id,
      title: draft.title.trim(),
      categoryId: draft.categoryId,
      subcategoryId: draft.subcategoryId,
      description: draft.description.trim(),
      client: draft.client.trim(),
      date: draft.date.trim(),
      tech: draft.tech.split(",").map((t) => t.trim()).filter(Boolean),
      tags: draft.tags.split(",").map((t) => t.trim()).filter(Boolean),
      image: { ...draft.image, alt },
      gallery: draft.gallery.map((g) => ({ ...g, alt: g.alt?.trim() || alt })),
      liveUrl: draft.liveUrl.trim(),
      demoUrl: draft.demoUrl.trim(),
      githubUrl: draft.githubUrl.trim(),
      playStoreUrl: draft.playStoreUrl.trim(),
      appStoreUrl: draft.appStoreUrl.trim(),
      featured: draft.featured,
      published: draft.published,
      order: Number(draft.order) || 0,
    };
    const next = editing === "new" ? [...portfolio, item] : portfolio.map((p, i) => (i === editing ? item : p));
    const ok = await saveSection("content", { ...settings.content, portfolio: next });
    if (ok) {
      toast.success(`Portfolio project ${editing === "new" ? "created" : "updated"} successfully`);
      cancel();
    }
    return ok;
  });

  const remove = async (i: number) => {
    const ok = await saveSection("content", { ...settings.content, portfolio: portfolio.filter((_, idx) => idx !== i) });
    if (ok) { toast.success("Portfolio project deleted"); playUISound("ui_delete", { category: "admin", soft: true }); }
  };

  const duplicate = (i: number) => {
    const copy: PortfolioItem = { ...portfolio[i], id: uniqueSlug(`${portfolio[i].id}-copy`, portfolio.map((p) => p.id)), title: `${portfolio[i].title} (Copy)`, order: portfolio.length, featured: false };
    saveSection("content", { ...settings.content, portfolio: [...portfolio, copy] }).then((ok) => {
      if (ok) toast.success("Project duplicated — edit and save it");
    });
  };

  return (
    <div className="space-y-4">
      <TabHeader
        title="All Projects"
        subtitle={`${portfolio.length} project${portfolio.length === 1 ? "" : "s"} · category → subcategory → image`}
        action={editing === null ? <AddButton label="Add Project" onClick={startNew} /> : undefined}
      />

      {editing !== null && (
        <EditPanel title={editing === "new" ? "New Project" : "Edit Project"}>
          <CrudField label="Project Name" value={draft.title} onChange={(v) => setDraft({ ...draft, title: v })} placeholder="DKTE Admission Campaign" />
          <CrudSelect
            label="Category"
            value={draft.categoryId}
            onChange={(v) => setDraft({ ...draft, categoryId: v, subcategoryId: "" })}
            options={sortedCategories.map((c) => ({ value: c.id, label: c.name }))}
          />
          <CrudSelect
            label="Subcategory"
            value={draft.subcategoryId}
            onChange={(v) => setDraft({ ...draft, subcategoryId: v })}
            options={[
              { value: "", label: "— None —" },
              ...subsOfCategory(draft.categoryId).map((s) => ({ value: s.id, label: s.name })),
            ]}
          />
          <CrudField label="Client" value={draft.client} onChange={(v) => setDraft({ ...draft, client: v })} placeholder="Client name" />
          <div className="sm:col-span-2">
            <CrudTextarea label="Description" value={draft.description} onChange={(v) => setDraft({ ...draft, description: v })} placeholder="Short project description..." />
          </div>
          <ImageUploader
            label="Project Image (Cover)"
            image={draft.image}
            altFallback={draft.title}
            onChange={(img) => setDraft({ ...draft, image: img })}
          />

          {/* Gallery images — all shown on the public category view */}
          <div className="sm:col-span-2">
            <p className={labelCls} style={{ color: "var(--sd-muted)" }}>
              Gallery Images ({draft.gallery.length}) — every image is shown when visitors open this category
            </p>
            <div className="space-y-2.5">
              {draft.gallery.map((g, gi) => (
                <div key={gi} className="glass flex flex-wrap items-center gap-3 rounded-xl p-3">
                  <div className="flex shrink-0 flex-col gap-1">
                    <button
                      type="button"
                      data-sound="none"
                      disabled={gi === 0}
                      onClick={() => {
                        const next = [...draft.gallery];
                        [next[gi - 1], next[gi]] = [next[gi], next[gi - 1]];
                        setDraft({ ...draft, gallery: next });
                        playUISound("ui_click", { category: "admin", soft: true });
                      }}
                      className="glass flex h-5 w-7 items-center justify-center rounded-md text-[9px] disabled:opacity-30"
                      style={{ color: "var(--sd-primary)" }}
                      aria-label="Move image up"
                    >
                      ▲
                    </button>
                    <button
                      type="button"
                      data-sound="none"
                      disabled={gi === draft.gallery.length - 1}
                      onClick={() => {
                        const next = [...draft.gallery];
                        [next[gi + 1], next[gi]] = [next[gi], next[gi + 1]];
                        setDraft({ ...draft, gallery: next });
                        playUISound("ui_click", { category: "admin", soft: true });
                      }}
                      className="glass flex h-5 w-7 items-center justify-center rounded-md text-[9px] disabled:opacity-30"
                      style={{ color: "var(--sd-primary)" }}
                      aria-label="Move image down"
                    >
                      ▼
                    </button>
                  </div>
                  <img src={g.url} alt={g.alt || draft.title} className="h-14 w-20 shrink-0 rounded-lg object-contain" style={{ background: "rgba(248,250,252,0.8)" }} />
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-bold" style={{ color: "var(--sd-heading)" }}>
                      {g.width} × {g.height} · {ratioLabel(g.width, g.height)} · {formatFileSize(g.fileSize)}
                    </p>
                    <input
                      type="text"
                      value={g.alt}
                      onChange={(e) => {
                        const next = draft.gallery.map((x, xi) => (xi === gi ? { ...x, alt: e.target.value } : x));
                        setDraft({ ...draft, gallery: next });
                      }}
                      placeholder={`Alt text (falls back to “${draft.title || "project"}”)`}
                      className="glass mt-1.5 w-full rounded-lg px-3 py-1.5 text-xs font-medium outline-none"
                      style={{ color: "var(--sd-heading)" }}
                    />
                  </div>
                  <label
                    className="glass flex shrink-0 cursor-pointer items-center gap-1.5 rounded-full px-3.5 py-2 text-[10px] font-bold transition-transform hover:-translate-y-0.5"
                    style={{ color: "var(--sd-heading)" }}
                  >
                    Replace
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      className="hidden"
                      onChange={async (e) => {
                        const file = e.target.files?.[0];
                        e.target.value = "";
                        if (!file) return;
                        const result = await readImageMeta(file, draft.title || "Project image");
                        if (!result.ok) {
                          toast.error(result.error);
                          return;
                        }
                        const next = draft.gallery.map((x, xi) => (xi === gi ? result.meta : x));
                        setDraft({ ...draft, gallery: next });
                        playUISound("ui_upload", { category: "admin", soft: true });
                      }}
                    />
                  </label>
                  <button
                    type="button"
                    data-sound="none"
                    onClick={() => {
                      setDraft({ ...draft, gallery: draft.gallery.filter((_, xi) => xi !== gi) });
                      playUISound("ui_delete", { category: "admin", soft: true });
                    }}
                    className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-transform hover:scale-110"
                    style={{ background: "rgba(239,68,68,0.1)", color: "#ef4444" }}
                    aria-label="Remove gallery image"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              ))}
              <label
                className="flex cursor-pointer items-center justify-center gap-2 rounded-xl border-2 border-dashed px-4 py-3 text-xs font-bold transition-colors"
                style={{ borderColor: "rgba(37,99,235,0.4)", color: "var(--sd-heading)", background: "rgba(255,255,255,0.6)" }}
              >
                <Plus size={14} style={{ color: "var(--sd-primary)" }} />
                Add Gallery Image{draft.gallery.length === 0 ? "s" : ""} (JPG · PNG · WEBP — max 2 MB each)
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  multiple
                  className="hidden"
                  onChange={async (e) => {
                    const files = Array.from(e.target.files ?? []);
                    e.target.value = "";
                    const added: ImageMeta[] = [];
                    for (const file of files) {
                      const result = await readImageMeta(file, draft.title || "Project image");
                      if (result.ok) added.push(result.meta);
                      else toast.error(result.error);
                    }
                    if (added.length > 0) {
                      setDraft({ ...draft, gallery: [...draft.gallery, ...added] });
                      playUISound("ui_upload", { category: "admin", soft: true });
                    }
                  }}
                />
              </label>
            </div>
          </div>

          <CrudField label="Technology (comma separated)" value={draft.tech} onChange={(v) => setDraft({ ...draft, tech: v })} placeholder="Photoshop, React" />
          <CrudField label="Tags (comma separated)" value={draft.tags} onChange={(v) => setDraft({ ...draft, tags: v })} placeholder="Branding, Print" />
          <CrudField label="Date / Year" value={draft.date} onChange={(v) => setDraft({ ...draft, date: v })} placeholder="2024" />
          <CrudField label="Live Preview URL" value={draft.liveUrl} onChange={(v) => setDraft({ ...draft, liveUrl: v })} placeholder="https://..." />
          <CrudField label="Demo URL" value={draft.demoUrl} onChange={(v) => setDraft({ ...draft, demoUrl: v })} placeholder="https://..." />
          <CrudField label="GitHub URL" value={draft.githubUrl} onChange={(v) => setDraft({ ...draft, githubUrl: v })} placeholder="https://github.com/..." />
          <CrudField label="Play Store URL" value={draft.playStoreUrl} onChange={(v) => setDraft({ ...draft, playStoreUrl: v })} placeholder="https://play.google.com/..." />
          <CrudField label="App Store URL" value={draft.appStoreUrl} onChange={(v) => setDraft({ ...draft, appStoreUrl: v })} placeholder="https://apps.apple.com/..." />
          <CrudField label="Sort Order" type="number" value={draft.order} onChange={(v) => setDraft({ ...draft, order: v })} placeholder="0" />
          <CrudCheckbox label="Featured" checked={draft.featured} onChange={(v) => setDraft({ ...draft, featured: v })} />
          <CrudCheckbox label="Published" checked={draft.published} onChange={(v) => setDraft({ ...draft, published: v })} />
          <div className="sm:col-span-2">
            <SaveBar
              status={status}
              dirty
              onSave={save}
              onCancel={cancel}
              label={editing === "new" ? "Save & Publish" : "Save Changes"}
              extra={error ? <span className="text-xs font-bold" style={{ color: "#ef4444" }}>{error}</span> : undefined}
            />
          </div>
        </EditPanel>
      )}

      {portfolio.length === 0 && editing === null ? (
        <div className="glass flex flex-col items-center rounded-2xl px-6 py-10 text-center">
          <p className="text-sm font-bold" style={{ color: "var(--sd-heading)" }}>No projects yet</p>
          <p className="mt-1 text-xs" style={{ color: "var(--sd-muted)" }}>Add your first portfolio project.</p>
        </div>
      ) : (
        <div className="space-y-2.5">
          {portfolio.map((item, i) => (
            <div key={item.id} className="glass flex items-center gap-4 rounded-2xl p-3">
              <img src={item.image.url} alt={item.image.alt || item.title} className="h-14 w-20 shrink-0 rounded-xl object-contain" style={{ background: "rgba(248,250,252,0.8)" }} />
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-2 truncate text-sm font-bold" style={{ color: "var(--sd-heading)" }}>
                  {item.title}
                  {item.featured && <span className="rounded-full px-2 py-0.5 text-[9px] font-bold" style={{ background: "rgba(245,158,11,0.15)", color: "#b45309" }}>FEATURED</span>}
                  {!item.published && <span className="rounded-full px-2 py-0.5 text-[9px] font-bold" style={{ background: "rgba(148,163,184,0.2)", color: "var(--sd-muted)" }}>DRAFT</span>}
                </p>
                <p className="truncate text-xs" style={{ color: "var(--sd-muted)" }}>
                  {categoryName(item.categoryId)}
                  {subName(item.subcategoryId) && ` › ${subName(item.subcategoryId)}`}
                  {item.client && ` · ${item.client}`}
                  {` · ${1 + (item.gallery?.length ?? 0)} image${1 + (item.gallery?.length ?? 0) === 1 ? "" : "s"}`}
                </p>
              </div>
              <DuplicateButton onDuplicate={() => duplicate(i)} />
              <button onClick={() => startEdit(i)} data-sound="none" className="glass flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-transform hover:scale-110" style={{ color: "var(--sd-primary)" }} aria-label="Edit project">
                <Pencil size={14} />
              </button>
              <ConfirmDeleteButton onConfirm={() => remove(i)} label="Delete project" />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
