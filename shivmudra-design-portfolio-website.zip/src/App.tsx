import { useEffect, useState } from "react";
import { SettingsProvider, useSettings } from "./lib/settings";
import { AuthProvider, useAuth } from "./lib/auth";
import { useHashRoute } from "./lib/router";
import GalaxyBackground from "./components/GalaxyBackground";
import SoundController from "./components/SoundController";
import Intro from "./components/Intro";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Services from "./components/Services";
import Portfolio from "./components/Portfolio";
import Experience from "./components/Experience";
import Skills from "./components/Skills";
import Testimonials from "./components/Testimonials";
import Stats from "./components/Stats";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import SectionFlow from "./components/SectionFlow";
import AdminLoginPage from "./components/admin/AdminLoginPage";
import AdminDashboard from "./components/admin/AdminDashboard";

/* ---------------- public website ---------------- */

function PublicSite({ introDone, onCompleteIntro }: { introDone: boolean; onCompleteIntro: () => void }) {
  const { settings } = useSettings();
  const s = settings.content.sections;

  /* Lock body scroll while the intro plays */
  useEffect(() => {
    document.body.style.overflow = introDone ? "" : "hidden";
    return () => {
      document.body.style.overflow = "";
    };
  }, [introDone]);

  return (
    <>
      {!introDone && <Intro onDone={onCompleteIntro} />}
      <div className="relative z-10">
        <Navbar />
        <main>
          {s.hero && <Hero active={introDone} />}
          <SectionFlow />
          {s.about && <About />}
          <SectionFlow />
          {s.services && <Services />}
          <SectionFlow />
          {s.portfolio && <Portfolio />}
          <SectionFlow />
          {s.experience && <Experience />}
          <SectionFlow />
          {s.skills && <Skills />}
          {s.testimonials && <Testimonials />}
          {s.stats && <Stats />}
          <SectionFlow />
          {s.contact && <Contact />}
        </main>
        <Footer />
      </div>
    </>
  );
}

/* ---------------- protected admin area ---------------- */

function AdminShell({ route }: { route: string }) {
  const { isAdmin } = useAuth();
  const isLoginPage = route === "/admin/login";

  /* Route guards:
     - unauthenticated + any /admin route  → redirect to /admin/login
     - authenticated  + /admin/login        → redirect to /admin dashboard */
  useEffect(() => {
    if (!isAdmin && !isLoginPage) {
      window.location.replace("#/admin/login");
    } else if (isAdmin && isLoginPage) {
      window.location.replace("#/admin");
    }
  }, [isAdmin, isLoginPage]);

  if (!isAdmin) {
    return isLoginPage ? <AdminLoginPage /> : null; // redirecting…
  }
  return isLoginPage ? null : <AdminDashboard />;
}

/* ---------------- app shell ---------------- */

function Shell() {
  const route = useHashRoute();
  const isAdminRoute = route.startsWith("/admin");
  const [introDone, setIntroDone] = useState(() => window.location.hash.startsWith("#/admin"));

  /* Never play the boot intro inside the admin area */
  useEffect(() => {
    if (isAdminRoute) setIntroDone(true);
  }, [isAdminRoute]);

  return (
    <>
      <GalaxyBackground />
      {isAdminRoute ? (
        <AdminShell route={route} />
      ) : (
        <PublicSite introDone={introDone} onCompleteIntro={() => setIntroDone(true)} />
      )}
      <SoundController />
    </>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <AuthProvider>
        <Shell />
      </AuthProvider>
    </SettingsProvider>
  );
}
