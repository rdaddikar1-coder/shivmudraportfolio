/**
 * Shivmudra Design — global UI interaction sound system.
 *
 * Every sound is procedurally synthesized with the Web Audio API
 * (oscillators + filtered noise) — no copyrighted samples are used.
 * Admins can optionally override any UI sound with a custom MP3/WAV/OGG file.
 *
 * Loudness design (clean, premium, no clipping):
 *  - Synth gains are tuned to full scale (~0.2–0.8 peak amplitude)
 *  - Every sound has its own relative level (SOUND_LEVELS, 0–1)
 *  - Master volume (default 65%) scales everything
 *  - A DynamicsCompressor guards the output so nothing ever distorts
 *
 * Features:
 *  - Named UI sound library (clicks, cards, filters, toggles, scans, scrolls…)
 *  - Category gates (navigation / button / success / error / admin / hover /
 *    scroll / section)
 *  - Master volume (0–100%) + master enable
 *  - Per-sound throttling (no overlapping spam)
 *  - Velocity-aware gain (scroll whooshes scale with speed)
 *  - Custom sound uploads with validation + localStorage persistence
 *  - Soft playback mode for the Admin Panel
 */

export type UISoundName =
  | "ui_click"
  | "ui_hover"
  | "ui_card"
  | "ui_filter"
  | "ui_select"
  | "ui_open"
  | "ui_close"
  | "ui_success"
  | "ui_error"
  | "ui_toggle"
  | "ui_toggle_on"
  | "ui_toggle_off"
  | "ui_upload"
  | "ui_delete"
  | "ui_scan"
  | "ui_power"
  | "ui_scroll_down"
  | "ui_scroll_up"
  | "ui_section"
  // Boot-sequence sounds used by the mechanical intro
  | "servo"
  | "servoDown"
  | "lock"
  | "activate"
  | "beep"
  | "impact"
  | "whoosh"
  | "chime";

export type SoundCategory =
  | "navigation"
  | "button"
  | "success"
  | "error"
  | "admin"
  | "hover"
  | "scroll"
  | "section";

export interface SoundConfig {
  enabled: boolean;
  volume: number;
  navigation: boolean;
  button: boolean;
  success: boolean;
  error: boolean;
  admin: boolean;
  hover: boolean;
  scroll: boolean;
  section: boolean;
}

export interface CustomSound {
  data: string; // data URL
  type: string;
  enabled: boolean;
}

export interface CustomSoundResult {
  ok: boolean;
  error?: string;
}

const CUSTOM_STORAGE_KEY = "shivmudra-custom-sounds-v1";
const MAX_CUSTOM_SIZE = 512 * 1024; // 512 KB
const THROTTLE_MS = 90;

const DEFAULT_CONFIG: SoundConfig = {
  enabled: true,
  volume: 0.65,
  navigation: true,
  button: true,
  success: true,
  error: true,
  admin: true,
  hover: false,
  scroll: true,
  section: true,
};

/**
 * Relative level of every sound in the library (0–1).
 * Keeps the mix balanced:
 *  - primary CTAs / navigation  ≈ 65%
 *  - cards & filters softer      ≈ 45–55%
 *  - hover / scroll / sections  ≈ 10–32% (ambient layer)
 */
const SOUND_LEVELS: Record<UISoundName, number> = {
  ui_click: 0.65, // navigation + button clicks
  ui_hover: 0.15, // deliberately barely audible
  ui_card: 0.5, // card selection — softer than a primary CTA
  ui_filter: 0.5, // category filter chips
  ui_select: 0.5, // dropdown / select fields
  ui_open: 0.65, // menu / modal open
  ui_close: 0.55, // menu close — gentler
  ui_success: 0.65,
  ui_error: 0.6,
  ui_toggle: 0.6,
  ui_toggle_on: 0.65, // tick + power-up
  ui_toggle_off: 0.55, // tick + power-down
  ui_upload: 0.65,
  ui_delete: 0.6,
  ui_scan: 0.7, // portfolio open — deeper cinematic scan
  ui_power: 0.7,
  ui_scroll_down: 0.16, // ambient scroll whoosh (velocity-scaled)
  ui_scroll_up: 0.16,
  ui_section: 0.32, // ambient section-entry tick
  // Mechanical intro suite
  servo: 0.7,
  servoDown: 0.7,
  lock: 0.7,
  activate: 0.7,
  beep: 0.65,
  impact: 0.75,
  whoosh: 0.65,
  chime: 0.7,
};

/** Which category gate (if any) a sound belongs to. */
function inferCategory(name: UISoundName): SoundCategory | null {
  switch (name) {
    case "ui_click":
    case "ui_card":
    case "ui_filter":
    case "ui_select":
    case "ui_open":
    case "ui_close":
    case "ui_toggle":
    case "ui_toggle_on":
    case "ui_toggle_off":
    case "ui_delete":
    case "ui_scan":
    case "ui_power":
      return "button";
    case "ui_hover":
      return "hover";
    case "ui_success":
    case "ui_upload":
      return "success";
    case "ui_error":
      return "error";
    case "ui_scroll_down":
    case "ui_scroll_up":
      return "scroll";
    case "ui_section":
      return "section";
    default:
      return null; // boot-sequence sounds are never gated
  }
}

class SoundEngine {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private config: SoundConfig = { ...DEFAULT_CONFIG };
  private custom: Record<string, CustomSound> = {};
  private customBuffers = new Map<string, AudioBuffer>();
  private lastPlayed: Record<string, number> = {};
  private customListeners = new Set<() => void>();
  private softMul = 1;
  private levelMul = 1;

  constructor() {
    try {
      const raw = localStorage.getItem(CUSTOM_STORAGE_KEY);
      if (raw) this.custom = JSON.parse(raw);
    } catch {
      this.custom = {};
    }
  }

  /* ------------------------------------------------------------ */
  /*  Configuration                                                */
  /* ------------------------------------------------------------ */

  syncConfig(cfg: SoundConfig) {
    this.config = { ...cfg };
    this.applyMasterGain();
  }

  setEnabled(enabled: boolean) {
    this.config.enabled = enabled;
    this.applyMasterGain();
  }

  setVolume(volume: number) {
    this.config.volume = Math.min(1, Math.max(0, volume));
    this.applyMasterGain();
  }

  private applyMasterGain() {
    if (this.master && this.ctx) {
      const target = this.config.enabled ? this.config.volume : 0;
      this.master.gain.setTargetAtTime(target, this.ctx.currentTime, 0.04);
    }
  }

  /** Must be called from a user gesture to unlock audio playback. */
  unlock() {
    this.ensureContext();
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => undefined);
    }
  }

  /* ------------------------------------------------------------ */
  /*  Playback                                                     */
  /* ------------------------------------------------------------ */

  play(
    name: UISoundName,
    opts?: {
      category?: SoundCategory | null;
      soft?: boolean;
      force?: boolean;
      /** Extra gain multiplier (e.g. scroll velocity). */
      gainMul?: number;
    }
  ): boolean {
    if (!this.config.enabled) return false;

    const category = opts?.category === undefined ? inferCategory(name) : opts.category;
    if (category && !(this.config as unknown as Record<string, unknown>)[category]) return false;

    const now = performance.now();
    if (!opts?.force && now - (this.lastPlayed[name] ?? 0) < THROTTLE_MS) return false;
    this.lastPlayed[name] = now;

    if (!this.ensureContext()) return false;
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => undefined);
    }

    const soft = opts?.soft ? 0.7 : 1; // Admin Panel: slightly softer
    const level = SOUND_LEVELS[name] ?? 0.65;
    const mul = soft * level * (opts?.gainMul ?? 1);

    const custom = this.custom[name];
    if (custom && custom.enabled && custom.data) {
      void this.playCustom(custom.data, mul);
      return true;
    }

    this.softMul = soft;
    this.levelMul = level * (opts?.gainMul ?? 1);
    this.synth(name);
    return true;
  }

  /** Preview ignores category gates + throttle (admin "Preview" buttons). */
  preview(name: UISoundName): boolean {
    return this.play(name, { force: true, category: null });
  }

  private async playCustom(data: string, gain: number) {
    if (!this.ctx || !this.master) return;
    try {
      let buffer = this.customBuffers.get(data);
      if (!buffer) {
        const res = await fetch(data);
        const arr = await res.arrayBuffer();
        buffer = await this.ctx.decodeAudioData(arr);
        this.customBuffers.set(data, buffer);
      }
      const src = this.ctx.createBufferSource();
      src.buffer = buffer;
      const g = this.ctx.createGain();
      g.gain.value = Math.min(1, gain);
      src.connect(g).connect(this.master);
      src.start();
    } catch {
      /* invalid custom file — silently ignored */
    }
  }

  /* ------------------------------------------------------------ */
  /*  Custom sound management (Admin Panel)                        */
  /* ------------------------------------------------------------ */

  getCustomSounds(): Record<string, CustomSound> {
    return { ...this.custom };
  }

  subscribeCustom(cb: () => void): () => void {
    this.customListeners.add(cb);
    return () => {
      this.customListeners.delete(cb);
    };
  }

  private saveCustom() {
    try {
      localStorage.setItem(CUSTOM_STORAGE_KEY, JSON.stringify(this.custom));
    } catch {
      /* storage quota exceeded — keep in-memory only */
    }
    this.customListeners.forEach((l) => l());
  }

  async setCustomSound(name: UISoundName, file: File): Promise<CustomSoundResult> {
    const ext = file.name.split(".").pop()?.toLowerCase() ?? "";
    const typeOk = ["audio/mpeg", "audio/wav", "audio/x-wav", "audio/wave", "audio/ogg", "audio/vorbis"].includes(file.type);
    const extOk = ["mp3", "wav", "ogg"].includes(ext);
    if (!typeOk && !extOk) {
      return { ok: false, error: "Unsupported file type. Use MP3, WAV or OGG." };
    }
    if (file.size > MAX_CUSTOM_SIZE) {
      return { ok: false, error: "File too large — maximum 512 KB." };
    }
    try {
      const data = await this.readFileAsDataURL(file);
      this.custom[name] = { data, type: file.type || ext, enabled: true };
      this.saveCustom();
      return { ok: true };
    } catch {
      return { ok: false, error: "Could not read the file. Try again." };
    }
  }

  removeCustomSound(name: UISoundName) {
    if (this.custom[name]) {
      delete this.custom[name];
      this.saveCustom();
    }
  }

  setCustomEnabled(name: UISoundName, enabled: boolean) {
    if (this.custom[name]) {
      this.custom[name].enabled = enabled;
      this.saveCustom();
    }
  }

  clearAllCustomSounds() {
    this.custom = {};
    this.saveCustom();
  }

  private readFileAsDataURL(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = () => reject(reader.error);
      reader.readAsDataURL(file);
    });
  }

  /* ------------------------------------------------------------ */
  /*  Audio graph + synthesis primitives                           */
  /* ------------------------------------------------------------ */

  private ensureContext(): boolean {
    if (typeof window === "undefined") return false;
    if (!this.ctx) {
      const AC =
        window.AudioContext ??
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AC) return false;
      this.ctx = new AC();
      // master → compressor → destination (guarantees no clipping/distortion)
      this.master = this.ctx.createGain();
      this.master.gain.value = this.config.enabled ? this.config.volume : 0;
      this.compressor = this.ctx.createDynamicsCompressor();
      this.compressor.threshold.value = -6;
      this.compressor.knee.value = 12;
      this.compressor.ratio.value = 8;
      this.compressor.attack.value = 0.001;
      this.compressor.release.value = 0.12;
      this.master.connect(this.compressor).connect(this.ctx.destination);
      // Pre-render 1s of white noise for mechanical textures
      const len = this.ctx.sampleRate;
      this.noiseBuffer = this.ctx.createBuffer(1, len, this.ctx.sampleRate);
      const data = this.noiseBuffer.getChannelData(0);
      for (let i = 0; i < len; i++) data[i] = Math.random() * 2 - 1;
    }
    return true;
  }

  private noise(
    duration: number,
    filterType: BiquadFilterType,
    freq: number,
    gain: number,
    when = 0,
    q = 1,
    freqEnd?: number
  ) {
    if (!this.ctx || !this.master || !this.noiseBuffer) return;
    const t = this.ctx.currentTime + when;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = true;
    const filter = this.ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.setValueAtTime(freq, t);
    if (freqEnd !== undefined) {
      filter.frequency.exponentialRampToValueAtTime(Math.max(1, freqEnd), t + duration);
    }
    filter.Q.value = q;
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(0.0001, gain * this.softMul * this.levelMul), t + duration * 0.15);
    g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    src.connect(filter).connect(g).connect(this.master);
    src.start(t);
    src.stop(t + duration + 0.05);
  }

  private tone(
    freqStart: number,
    freqEnd: number,
    duration: number,
    gain: number,
    type: OscillatorType = "sine",
    when = 0
  ) {
    if (!this.ctx || !this.master) return;
    const t = this.ctx.currentTime + when;
    const osc = this.ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(freqStart, t);
    osc.frequency.exponentialRampToValueAtTime(Math.max(1, freqEnd), t + duration);
    const g = this.ctx.createGain();
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(
      Math.max(0.0001, gain * this.softMul * this.levelMul),
      t + Math.min(0.04, duration * 0.2)
    );
    g.gain.exponentialRampToValueAtTime(0.0001, t + duration);
    osc.connect(g).connect(this.master);
    osc.start(t);
    osc.stop(t + duration + 0.05);
  }

  /* ------------------------------------------------------------ */
  /*  The sound library (gains tuned to full scale — the master    */
  /*  volume + per-sound level scale them to the final loudness)   */
  /* ------------------------------------------------------------ */

  private synth(name: UISoundName) {
    switch (name) {
      /* ---------- UI interaction sounds ---------- */
      case "ui_click":
        // Soft metallic tick + tiny electronic pulse
        this.noise(0.035, "highpass", 3400, 0.48);
        this.tone(2100, 1500, 0.055, 0.18, "square");
        this.tone(1040, 1040, 0.08, 0.14, "sine", 0.015);
        break;
      case "ui_hover":
        // Extremely soft digital tick (desktop, optional)
        this.tone(1900, 2200, 0.045, 0.06, "sine");
        break;
      case "ui_card":
        // Card selection — softer than a primary CTA
        this.noise(0.03, "highpass", 2800, 0.32);
        this.tone(1500, 1250, 0.05, 0.11, "square");
        break;
      case "ui_filter":
        // Soft digital scan/click for filter chips
        this.tone(700, 1500, 0.12, 0.13);
        this.noise(0.09, "bandpass", 2300, 0.1, 0, 5);
        break;
      case "ui_select":
        // Dropdown / select confirmation (double soft tick)
        this.tone(520, 520, 0.05, 0.14);
        this.tone(780, 780, 0.07, 0.1, "sine", 0.055);
        break;
      case "ui_open":
        // Rising electronic activation
        this.tone(320, 780, 0.16, 0.24);
        this.tone(640, 1560, 0.16, 0.08, "triangle");
        this.noise(0.14, "bandpass", 1600, 0.06, 0, 4);
        break;
      case "ui_close":
        // Short falling confirmation
        this.tone(760, 300, 0.13, 0.2);
        this.noise(0.05, "highpass", 2600, 0.32, 0.1);
        break;
      case "ui_success":
        // Soft futuristic success chime
        this.tone(659, 659, 0.09, 0.22);
        this.tone(988, 988, 0.14, 0.2, "sine", 0.09);
        this.tone(1319, 1319, 0.18, 0.12, "sine", 0.16);
        break;
      case "ui_error":
        // Subtle low digital error
        this.tone(330, 262, 0.1, 0.22, "square");
        this.tone(262, 208, 0.12, 0.16, "square", 0.11);
        break;
      case "ui_toggle":
        // Generic toggle (kept for compatibility)
        this.noise(0.03, "highpass", 3000, 0.36);
        this.tone(1250, 1250, 0.06, 0.18, "square");
        this.tone(1650, 1650, 0.05, 0.12, "sine", 0.05);
        break;
      case "ui_toggle_on":
        // Tick + power-up
        this.noise(0.025, "highpass", 2900, 0.34);
        this.tone(620, 1240, 0.13, 0.15);
        break;
      case "ui_toggle_off":
        // Tick + power-down
        this.noise(0.025, "highpass", 2900, 0.34);
        this.tone(1000, 460, 0.13, 0.13);
        break;
      case "ui_upload":
        // Quick ascending data-transfer arpeggio
        this.tone(523, 523, 0.07, 0.16);
        this.tone(784, 784, 0.07, 0.16, "sine", 0.07);
        this.tone(1047, 1047, 0.12, 0.16, "sine", 0.14);
        break;
      case "ui_delete":
        // Descending sweep + tick
        this.tone(700, 260, 0.16, 0.2, "sawtooth");
        this.noise(0.07, "highpass", 2400, 0.26, 0.02);
        break;
      case "ui_scan":
        // Deeper cinematic digital scan + click (portfolio opening)
        this.tone(480, 1500, 0.22, 0.16, "sine");
        this.noise(0.18, "bandpass", 2600, 0.12, 0, 6);
        this.noise(0.04, "highpass", 3200, 0.42, 0.2);
        this.tone(980, 980, 0.09, 0.14, "sine", 0.22);
        break;
      case "ui_power":
        // Special futuristic activation
        this.tone(180, 720, 0.3, 0.28);
        this.tone(360, 1440, 0.3, 0.1, "triangle");
        this.noise(0.22, "bandpass", 2000, 0.06, 0.02, 5);
        this.tone(1440, 1440, 0.1, 0.1, "sine", 0.3);
        break;
      case "ui_scroll_down":
        // Soft descending air sweep (velocity-scaled)
        this.noise(0.26, "bandpass", 950, 0.34, 0, 0.9, 320);
        break;
      case "ui_scroll_up":
        // Soft ascending air sweep (velocity-scaled)
        this.noise(0.26, "bandpass", 320, 0.34, 0, 0.9, 950);
        break;
      case "ui_section":
        // Ambient digital tick when entering a major section
        this.tone(880, 880, 0.1, 0.1);
        this.tone(1320, 1320, 0.12, 0.06, "sine", 0.055);
        break;

      /* ---------- Mechanical boot-sequence sounds (intro) ---------- */
      case "servo":
        this.tone(140, 320, 0.28, 0.48, "sawtooth");
        this.tone(280, 640, 0.28, 0.16, "triangle");
        this.noise(0.22, "bandpass", 1800, 0.15, 0, 3);
        break;
      case "servoDown":
        this.tone(320, 120, 0.3, 0.42, "sawtooth");
        this.noise(0.24, "bandpass", 1200, 0.12, 0, 3);
        break;
      case "lock":
        this.noise(0.05, "highpass", 2800, 0.6);
        this.tone(2400, 1700, 0.05, 0.21, "square", 0.02);
        this.tone(150, 55, 0.32, 0.8, "sine", 0.05);
        this.noise(0.16, "lowpass", 400, 0.36, 0.05);
        break;
      case "activate":
        this.tone(220, 880, 0.5, 0.3, "sine");
        this.tone(440, 1760, 0.5, 0.1, "triangle");
        this.noise(0.45, "bandpass", 2400, 0.09, 0, 6);
        break;
      case "beep":
        this.tone(1180, 1180, 0.07, 0.27, "sine");
        this.tone(1560, 1560, 0.09, 0.24, "sine", 0.11);
        break;
      case "impact":
        this.tone(88, 34, 0.85, 0.8, "sine");
        this.tone(132, 48, 0.6, 0.48, "triangle");
        this.noise(0.5, "lowpass", 320, 0.42);
        break;
      case "whoosh":
        this.noise(0.4, "bandpass", 900, 0.18, 0, 0.8);
        break;
      case "chime":
        this.tone(523.25, 523.25, 0.5, 0.24, "sine");
        this.tone(783.99, 783.99, 0.55, 0.18, "sine", 0.06);
        this.tone(1046.5, 1046.5, 0.7, 0.14, "sine", 0.12);
        break;
    }
  }
}

export const soundEngine = new SoundEngine();
