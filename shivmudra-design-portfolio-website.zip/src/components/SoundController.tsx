import { useEffect, useState } from "react";
import { useSettings } from "../lib/settings";
import { soundEngine, type UISoundName } from "../lib/sound";
import { playUISound } from "../lib/uiSound";
import { usePrefersReducedMotion } from "../lib/hooks";
import { spawnRipple, subscribeRipples, pulseGalaxy, type Ripple } from "../lib/clickFx";

/**
 * GlobalSoundManager — the centralized interaction sound layer.
 *
 * ONE delegated system powers the entire site via event delegation, so every
 * current and future interactive element receives sound automatically:
 *
 *  click (capture)   → a, button, [role=button], [data-sound], summary
 *                        · #anchors            → navigation click
 *                        · admin panel subtree → softer admin click
 *                        · [data-sound="x"]    → explicit sound override
 *                        · [data-sound="none"] → opted out
 *  change            → select → ui_select · checkbox → toggle on/off ·
 *                       radio → ui_click  (color/text inputs excluded)
 *  mouseover         → optional ultra-soft hover tick (desktop only,
 *                       admin toggle, off by default)
 *  scroll            → throttled velocity-aware whoosh (down = descending,
 *                       up = ascending), max one per 400–700ms
 *  section entry     → subtle ambient tick, once per section, 2.5s cooldown
 *
 * Every played click sound is synchronized with a visual response:
 * a blue energy ripple at the pointer, a glow flash on the element,
 * and a subtle galaxy background pulse. Keyboard activation is covered
 * natively (Enter/Space fire click events on buttons/links).
 */
export default function SoundController() {
  const { settings } = useSettings();
  const reduced = usePrefersReducedMotion();
  const [ripples, setRipples] = useState<Ripple[]>([]);

  /* Keep the engine in sync with admin sound settings */
  useEffect(() => {
    soundEngine.syncConfig(settings.sound);
  }, [settings.sound]);

  /* ---------------------------------------------------------- */
  /*  Global delegated interaction sounds                        */
  /* ---------------------------------------------------------- */
  useEffect(() => {
    const unlock = () => soundEngine.unlock();
    window.addEventListener("pointerdown", unlock, { once: true });
    window.addEventListener("keydown", unlock, { once: true });

    const MAJOR_SOUNDS: UISoundName[] = ["ui_success", "ui_power", "ui_upload", "ui_delete", "ui_scan"];

    const CLICK_SELECTOR = 'a, button, [role="button"], summary, [data-sound]';
    const HOVER_SELECTOR = 'a, button, [role="button"], [data-sound]';

    /* ----- clicks (mouse, touch, keyboard) ----- */
    const onClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target || typeof target.closest !== "function") return;
      const el = target.closest(CLICK_SELECTOR) as HTMLElement | null;
      if (!el) return;

      const explicit = el.getAttribute("data-sound");
      if (explicit === "none") return;

      const inAdmin = !!el.closest("[data-admin-root]");
      const isNavAnchor = el.tagName === "A" && (el.getAttribute("href") ?? "").startsWith("#");

      let name: UISoundName = "ui_click";
      let category: "navigation" | "button" | "admin" = inAdmin
        ? "admin"
        : isNavAnchor
          ? "navigation"
          : "button";

      if (explicit) {
        name = explicit as UISoundName;
        if (!inAdmin) category = isNavAnchor ? "navigation" : "button";
      }

      const played = playUISound(name, { category, soft: inAdmin });
      if (played) {
        spawnRipple(e.clientX, e.clientY, MAJOR_SOUNDS.includes(name));
        pulseGalaxy();
        el.classList.add("sd-flash");
        window.setTimeout(() => el.classList.remove("sd-flash"), 520);
      }
    };

    /* ----- form controls: selects, checkboxes, radios ----- */
    const onChange = (e: Event) => {
      const target = e.target;
      if (!(target instanceof HTMLInputElement || target instanceof HTMLSelectElement)) return;
      if (target instanceof HTMLInputElement && target.type === "color") return; // avoid picker spam

      if (target instanceof HTMLSelectElement) {
        playUISound("ui_select", { category: "button", soft: true });
        return;
      }
      if (target.type === "checkbox") {
        playUISound(target.checked ? "ui_toggle_on" : "ui_toggle_off", { category: "button", soft: true });
      } else if (target.type === "radio") {
        playUISound("ui_click", { category: "button", soft: true });
      }
    };

    /* ----- optional ultra-soft hover ticks (desktop only) ----- */
    let lastHovered: Element | null = null;
    const canHover =
      typeof window.matchMedia === "function" &&
      window.matchMedia("(hover: hover) and (pointer: fine)").matches;

    const onOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      if (!target || typeof target.closest !== "function") return;
      const el = target.closest(HOVER_SELECTOR) as HTMLElement | null;
      if (!el) {
        lastHovered = null;
        return;
      }
      if (el === lastHovered) return;
      lastHovered = el;
      if (el.getAttribute("data-sound") === "none") return;
      playUISound("ui_hover", { category: "hover" });
    };

    document.addEventListener("click", onClick, true);
    document.addEventListener("change", onChange, true);
    if (canHover) document.addEventListener("mouseover", onOver, { passive: true });

    return () => {
      document.removeEventListener("click", onClick, true);
      document.removeEventListener("change", onChange, true);
      document.removeEventListener("mouseover", onOver);
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
    };
  }, []);

  /* ---------------------------------------------------------- */
  /*  Scroll whoosh + section-entry ambient ticks                */
  /* ---------------------------------------------------------- */
  useEffect(() => {
    if (reduced) return; // respect prefers-reduced-motion

    let sections: HTMLElement[] = [];
    const cacheSections = () => {
      sections = Array.from(document.querySelectorAll("section[id]"));
    };
    const onResize = () => cacheSections();
    cacheSections();
    window.addEventListener("resize", onResize, { passive: true });

    let lastY = window.scrollY;
    let lastTime = performance.now();
    let lastWhoosh = 0;
    let currentSection = "";
    let lastSectionTick = 0;

    const onScroll = () => {
      const now = performance.now();
      const y = window.scrollY;
      const dy = y - lastY;
      const dt = Math.max(1, now - lastTime);
      const velocity = Math.abs(dy) / dt; // px per ms
      lastY = y;
      lastTime = now;

      /* --- section-entry ambient tick (once per section, cooldown) --- */
      let found = "";
      for (const sec of sections) {
        if (sec.getBoundingClientRect().top <= window.innerHeight * 0.45) found = sec.id;
      }
      if (found && found !== currentSection) {
        currentSection = found;
        if (now - lastSectionTick > 2500) {
          lastSectionTick = now;
          playUISound("ui_section", { category: "section" });
        }
      }

      /* --- throttled, velocity-aware directional whoosh --- */
      if (Math.abs(dy) < 6) return; // barely moving
      if (velocity < 0.02) return; // essentially stopped
      const interval = velocity > 1.2 ? 400 : velocity > 0.5 ? 550 : 700;
      if (now - lastWhoosh < interval) return;
      lastWhoosh = now;

      const gainMul = Math.min(1.5, 0.6 + velocity * 0.5); // slow = subtle, fast = stronger
      playUISound(dy > 0 ? "ui_scroll_down" : "ui_scroll_up", { category: "scroll", gainMul });
    };

    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onResize);
    };
  }, [reduced]);

  /* Click ripple layer */
  useEffect(
    () =>
      subscribeRipples((r) => {
        setRipples((prev) => [...prev.slice(-5), r]);
        window.setTimeout(() => {
          setRipples((prev) => prev.filter((x) => x.id !== r.id));
        }, 750);
      }),
    []
  );

  return (
    <div className="pointer-events-none fixed inset-0 z-[200]" aria-hidden>
      {ripples.map((r) => (
        <span
          key={r.id}
          className={`sd-ripple ${r.big ? "sd-ripple-big" : ""}`}
          style={{ left: r.x, top: r.y }}
        />
      ))}
    </div>
  );
}
