import { useRef, useState } from "react";
import { Phone, Rocket, Mail, MapPin, Send, CheckCircle2, Loader2, AlertTriangle, ChevronDown } from "lucide-react";
import { InstagramIcon, WhatsAppIcon } from "./icons";
import Reveal from "./Reveal";
import SectionHead from "./SectionHead";
import { useSettings } from "../lib/settings";
import { useUISound } from "../lib/uiSound";
import { spawnRipple } from "../lib/clickFx";
import type { Enquiry } from "../data/content";

type FormErrors = { name?: string; email?: string; message?: string };

const FAQS = [
  {
    q: "What services does Shivmudra Design offer?",
    a: "Complete creative technology: brand identity and graphic design, website and app development, social media management, Meta ad campaigns and cinematic video editing — all crafted in one studio.",
  },
  {
    q: "How long does a typical project take?",
    a: "A brand identity usually takes 1–2 weeks, a full website 2–4 weeks, and ad campaigns go live within days. Every project ships with a clear timeline before we start.",
  },
  {
    q: "What is the pricing structure?",
    a: "Transparent project-based pricing with fixed quotes — no hidden hourly billing. Scope, deliverables and milestones are agreed upfront, with flexible instalments for larger builds.",
  },
  {
    q: "Do you work with international clients?",
    a: "Absolutely. The studio runs on a fully digital workflow with clients across time zones — async updates, scheduled calls and a shared project space keep everything on track.",
  },
];

export default function Contact() {
  const { settings, updateContent } = useSettings();
  const sound = useUISound();
  const c = settings.content;

  const [form, setForm] = useState({ name: "", email: "", projectType: "Branding & Design", message: "" });
  const [errors, setErrors] = useState<FormErrors>({});
  const [status, setStatus] = useState<"idle" | "sending" | "sent">("idle");
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const formRef = useRef<HTMLDivElement>(null);

  const actions = [
    { label: "Call Now", icon: Phone, href: `tel:${c.phone.replace(/\s/g, "")}`, external: false },
    { label: "WhatsApp", icon: WhatsAppIcon, href: `https://wa.me/${c.whatsapp}`, external: true },
    { label: "Instagram", icon: InstagramIcon, href: `https://instagram.com/${c.instagram.replace("@", "")}`, external: true },
    { label: "Start a Project", icon: Rocket, href: `mailto:${c.email}`, external: false, featured: true },
  ];

  const update =
    (key: keyof typeof form) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      setForm((f) => ({ ...f, [key]: e.target.value }));
      setErrors((err) => ({ ...err, [key]: undefined }));
    };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const next: FormErrors = {};
    if (form.name.trim().length < 2) next.name = "Please enter your name.";
    if (!/^\S+@\S+\.\S+$/.test(form.email.trim())) next.email = "Please enter a valid email address.";
    if (form.message.trim().length < 10) next.message = "Tell me a little more (at least 10 characters).";
    setErrors(next);

    if (Object.keys(next).length > 0) {
      sound.error();
      return;
    }

    setStatus("sending");
    window.setTimeout(() => {
      setStatus("sent");
      sound.success();
      const rect = formRef.current?.getBoundingClientRect();
      if (rect) {
        spawnRipple(rect.left + rect.width / 2, rect.top + rect.height / 2, true);
      }
      // Store the enquiry so it appears in the Admin Dashboard inbox
      const enquiry: Enquiry = {
        id: `${Date.now()}`,
        name: form.name.trim(),
        email: form.email.trim(),
        projectType: form.projectType,
        message: form.message.trim(),
        date: new Date().toISOString(),
      };
      updateContent("enquiries", [enquiry, ...settings.content.enquiries].slice(0, 50));
      setForm({ name: "", email: "", projectType: "Branding & Design", message: "" });
    }, 900);
  };

  const inputClass = (hasError?: string) =>
    `glass w-full rounded-2xl px-5 py-3.5 text-sm font-medium outline-none transition-all duration-300 placeholder:text-slate-400 focus:shadow-[0_0_0_3px_var(--sd-glow-soft)] ${
      hasError ? "border-red-300! shadow-[0_0_0_3px_rgba(248,113,113,0.2)]!" : ""
    }`;

  return (
    <section id="contact" className="relative scroll-mt-24 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHead
          badge="Get In Touch"
          title={
            <>
              Let's Create Something <span className="text-gradient">Great Together</span>
            </>
          }
          description="Have a project in mind? Reach out through any channel — the creative system is standing by."
        />

        {/* Action buttons */}
        <div className="mx-auto grid max-w-4xl gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {actions.map((a, i) => (
            <Reveal key={a.label} delay={i * 100} variant="scale">
              <a
                href={a.href}
                target={a.external ? "_blank" : undefined}
                rel={a.external ? "noopener noreferrer" : undefined}
                className="btn-primary group w-full flex-col gap-2! rounded-3xl! px-6! py-7!"
                style={
                  a.featured
                    ? { background: "linear-gradient(135deg, var(--sd-primary), var(--sd-accent))" }
                    : undefined
                }
              >
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-white/20 backdrop-blur transition-transform duration-500 group-hover:scale-110 group-hover:-rotate-6">
                  <a.icon size={20} />
                </span>
                <span className="text-sm font-bold tracking-wide">{a.label}</span>
              </a>
            </Reveal>
          ))}
        </div>

        {/* Info chips */}
        <div className="mx-auto mt-12 grid max-w-4xl gap-5 sm:grid-cols-3">
          {[
            { icon: Mail, label: "Email", value: c.email, href: `mailto:${c.email}` },
            { icon: Phone, label: "Phone", value: c.phone, href: `tel:${c.phone.replace(/\s/g, "")}` },
            { icon: MapPin, label: "Studio", value: c.location, href: undefined },
          ].map((info, i) => (
            <Reveal key={info.label} delay={200 + i * 110}>
              <div className="glass group flex items-center gap-4 rounded-2xl px-5 py-4 transition-all duration-500 hover:-translate-y-1 hover:shadow-[0_18px_40px_-14px_var(--sd-glow-medium)]">
                <span
                  className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-white"
                  style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" }}
                >
                  <info.icon size={18} />
                </span>
                <div className="min-w-0">
                  <p className="text-[11px] font-bold uppercase tracking-widest" style={{ color: "var(--sd-muted)" }}>
                    {info.label}
                  </p>
                  {info.href ? (
                    <a href={info.href} className="block truncate text-sm font-semibold transition-colors hover:text-[var(--sd-primary)]" style={{ color: "var(--sd-heading)" }}>
                      {info.value}
                    </a>
                  ) : (
                    <p className="truncate text-sm font-semibold" style={{ color: "var(--sd-heading)" }}>
                      {info.value}
                    </p>
                  )}
                </div>
              </div>
            </Reveal>
          ))}
        </div>

        {/* Enquiry form */}
        <Reveal delay={320}>
          <div
            ref={formRef}
            className="glass-strong relative mx-auto mt-14 max-w-2xl overflow-hidden rounded-[2rem] p-7 sm:p-9"
          >
            <span
              className="pointer-events-none absolute -right-16 -top-16 h-44 w-44 rounded-full opacity-50 blur-3xl"
              style={{ background: "var(--sd-glow-soft)" }}
            />

            {status === "sent" ? (
              <div className="relative flex flex-col items-center py-8 text-center">
                <span
                  className="flex h-16 w-16 items-center justify-center rounded-full text-white"
                  style={{
                    background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))",
                    boxShadow: "0 16px 40px -10px var(--sd-glow-medium)",
                  }}
                >
                  <CheckCircle2 size={30} />
                </span>
                <h3 className="heading-text mt-5 text-2xl font-bold">Message Sent Successfully</h3>
                <p className="mt-2 max-w-sm text-sm leading-relaxed" style={{ color: "var(--sd-body)" }}>
                  Thank you for reaching out. Your enquiry has been transmitted — expect a reply within 2 hours.
                </p>
                <button
                  className="btn-glass mt-6! py-2.5! text-sm!"
                  onClick={() => setStatus("idle")}
                >
                  <Send size={15} />
                  Send Another Message
                </button>
              </div>
            ) : (
              <>
                <h3 className="heading-text relative text-xl font-bold">Send an Enquiry</h3>
                <p className="relative mt-1 text-sm" style={{ color: "var(--sd-muted)" }}>
                  Transmit your project details directly through the creative system.
                </p>

                <form onSubmit={onSubmit} noValidate className="relative mt-6 space-y-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    <div>
                      <input
                        type="text"
                        placeholder="Your Name"
                        value={form.name}
                        onChange={update("name")}
                        className={inputClass(errors.name)}
                        style={{ color: "var(--sd-heading)" }}
                      />
                      {errors.name && (
                        <p className="mt-1.5 flex items-center gap-1 text-xs font-semibold text-red-500">
                          <AlertTriangle size={12} /> {errors.name}
                        </p>
                      )}
                    </div>
                    <div>
                      <input
                        type="email"
                        placeholder="Email Address"
                        value={form.email}
                        onChange={update("email")}
                        className={inputClass(errors.email)}
                        style={{ color: "var(--sd-heading)" }}
                      />
                      {errors.email && (
                        <p className="mt-1.5 flex items-center gap-1 text-xs font-semibold text-red-500">
                          <AlertTriangle size={12} /> {errors.email}
                        </p>
                      )}
                    </div>
                  </div>
                  <div>
                    <select
                      value={form.projectType}
                      onChange={(e) => setForm((f) => ({ ...f, projectType: e.target.value }))}
                      className={inputClass()}
                      style={{ color: "var(--sd-heading)" }}
                      aria-label="Project type"
                    >
                      {[
                        "Branding & Design",
                        "Website Development",
                        "App Development",
                        "Social Media Management",
                        "Meta Ads Campaign",
                        "Motion Graphics",
                        "Other",
                      ].map((opt) => (
                        <option key={opt} value={opt} className="bg-white text-slate-900">
                          {opt}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <textarea
                      placeholder="Tell me about your project..."
                      rows={4}
                      value={form.message}
                      onChange={update("message")}
                      className={`${inputClass(errors.message)} resize-none`}
                      style={{ color: "var(--sd-heading)" }}
                    />
                    {errors.message && (
                      <p className="mt-1.5 flex items-center gap-1 text-xs font-semibold text-red-500">
                        <AlertTriangle size={12} /> {errors.message}
                      </p>
                    )}
                  </div>

                  <button type="submit" disabled={status === "sending"} className="btn-primary w-full disabled:opacity-70">
                    {status === "sending" ? (
                      <>
                        <Loader2 size={17} className="animate-spin" />
                        Transmitting...
                      </>
                    ) : (
                      <>
                        <Send size={17} />
                        Send Enquiry
                      </>
                    )}
                  </button>
                </form>
              </>
            )}
          </div>
        </Reveal>

        {/* FAQ accordion */}
        <div className="mx-auto mt-14 max-w-2xl">
          <Reveal>
            <h3 className="heading-text mb-5 text-center text-xl font-bold">
                Frequently Asked <span className="text-gradient">Questions</span>
            </h3>
          </Reveal>
          <div className="space-y-3">
            {FAQS.map((faq, i) => {
              const isOpen = openFaq === i;
              return (
                <Reveal key={faq.q} delay={i * 90}>
                  <div className="glass overflow-hidden rounded-2xl transition-all duration-500">
                    <button
                      data-sound="ui_card"
                      onClick={() => setOpenFaq(isOpen ? null : i)}
                      className="flex w-full items-center justify-between gap-4 px-5 py-4 text-left"
                      aria-expanded={isOpen}
                    >
                      <span className="text-sm font-semibold sm:text-base" style={{ color: "var(--sd-heading)" }}>
                        {faq.q}
                      </span>
                      <span
                        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl transition-all duration-500"
                        style={{
                          background: isOpen ? "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" : "rgba(37,99,235,0.08)",
                          color: isOpen ? "#fff" : "var(--sd-primary)",
                          transform: isOpen ? "rotate(180deg)" : "none",
                        }}
                      >
                        <ChevronDown size={16} />
                      </span>
                    </button>
                    <div
                      className="grid transition-all duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]"
                      style={{ gridTemplateRows: isOpen ? "1fr" : "0fr" }}
                    >
                      <div className="overflow-hidden">
                        <p className="px-5 pb-5 text-sm leading-relaxed" style={{ color: "var(--sd-body)" }}>
                          {faq.a}
                        </p>
                      </div>
                    </div>
                  </div>
                </Reveal>
              );
            })}
          </div>
        </div>

        {/* Response promise */}
        <Reveal delay={380}>
          <div className="glass mx-auto mt-10 flex max-w-2xl items-center justify-center gap-3 rounded-full px-6 py-3.5">
            <Send size={15} style={{ color: "var(--sd-primary)" }} />
            <p className="text-sm font-medium" style={{ color: "var(--sd-body)" }}>
              Average response time — <span className="font-bold" style={{ color: "var(--sd-heading)" }}>under 2 hours</span>
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
