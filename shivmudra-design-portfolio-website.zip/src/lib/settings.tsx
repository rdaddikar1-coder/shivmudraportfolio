import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  PORTFOLIO,
  SERVICES,
  EXPERIENCE,
  SKILLS,
  TESTIMONIALS,
  WEBSITE_INFO,
  SEO_INFO,
  SOCIAL_LINKS,
  SECTION_VISIBILITY,
  ABOUT_CONTENT,
  CATEGORIES,
  SUBCATEGORIES,
  type PortfolioItem,
  type CategoryItem,
  type SubcategoryItem,
  type ImageMeta,
  type ServiceItem,
  type ExperienceItem,
  type SkillItem,
  type TestimonialItem,
  type Enquiry,
  type MediaItem,
  type WebsiteInfo,
  type SeoInfo,
  type SocialLinks,
  type SectionVisibility,
} from "../data/content";
import { persistSettings, SETTINGS_KEY } from "./db";
import { toast } from "./toast";

export type ThemeStyle = "galaxy" | "minimal" | "gradient";
export type Density = "low" | "medium" | "high";
export type Speed = "slow" | "medium" | "fast";
export type GlowLevel = "low" | "medium" | "high";

export interface SiteSettings {
  themeStyle: ThemeStyle;
  galaxy: {
    background: boolean;
    particles: boolean;
    density: Density;
    movement: Speed;
    glow: GlowLevel;
    parallax: boolean;
  };
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    glow: string;
    particle: string;
  };
  content: {
    heroTitle: string;
    heroHighlight: string;
    heroSubtitle: string;
    heroCtaText: string;
    heroCta2Text: string;
    heroImage: ImageMeta | null;
    heroImageMobile: ImageMeta | null;
    heroImageAlt: string;
    aboutImage: ImageMeta | null;
    aboutTitle: string;
    aboutText1: string;
    aboutText2: string;
    stats: { projects: number; years: number; creative: number; clients: number };
    phone: string;
    whatsapp: string;
    instagram: string;
    email: string;
    location: string;
    website: WebsiteInfo;
    seo: SeoInfo;
    social: SocialLinks;
    sections: SectionVisibility;
    categories: CategoryItem[];
    subcategories: SubcategoryItem[];
    portfolio: PortfolioItem[];
    services: ServiceItem[];
    experience: ExperienceItem[];
    skills: SkillItem[];
    testimonials: TestimonialItem[];
    media: MediaItem[];
    enquiries: Enquiry[];
  };
  sound: {
    enabled: boolean;
    volume: number; // 0..1
    navigation: boolean;
    button: boolean;
    success: boolean;
    error: boolean;
    admin: boolean;
    hover: boolean;
    scroll: boolean;
    section: boolean;
  };
}

export const DEFAULT_SETTINGS: SiteSettings = {
  themeStyle: "galaxy",
  galaxy: {
    background: true,
    particles: true,
    density: "medium",
    movement: "slow",
    glow: "medium",
    parallax: true,
  },
  colors: {
    primary: "#2563eb",
    secondary: "#06b6d4",
    accent: "#8b5cf6",
    glow: "#3b82f6",
    particle: "#2563eb",
  },
  content: {
    heroTitle: "Designing the Future of",
    heroHighlight: "Creative Brands",
    heroSubtitle:
      "Shivmudra Design is a premium creative studio crafting bold brand identities, high-performance websites, apps and ad campaigns that make businesses shine in the digital galaxy.",
    heroCtaText: "Start a Project",
    heroCta2Text: "View Portfolio",
    heroImage: null,
    heroImageMobile: null,
    heroImageAlt: "",
    aboutImage: null,
    aboutTitle: ABOUT_CONTENT.aboutTitle,
    aboutText1: ABOUT_CONTENT.aboutText1,
    aboutText2: ABOUT_CONTENT.aboutText2,
    stats: { projects: 150, years: 5, creative: 300, clients: 80 },
    phone: "+91 98765 43210",
    whatsapp: "919876543210",
    instagram: "shivmudra.design",
    email: "hello@shivmudra.design",
    location: "Mumbai, India",
    website: WEBSITE_INFO,
    seo: SEO_INFO,
    social: SOCIAL_LINKS,
    sections: SECTION_VISIBILITY,
    categories: CATEGORIES,
    subcategories: SUBCATEGORIES,
    portfolio: PORTFOLIO,
    services: SERVICES,
    experience: EXPERIENCE,
    skills: SKILLS,
    testimonials: TESTIMONIALS,
    media: [],
    enquiries: [],
  },
  sound: {
    enabled: true,
    volume: 0.65,
    navigation: true,
    button: true,
    success: true,
    error: true,
    admin: true,
    hover: false,
    scroll: true,
    section: true,
  },
};

function hexToRgba(hex: string, alpha: number): string {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((c) => c + c).join("") : h;
  const r = parseInt(full.slice(0, 2), 16);
  const g = parseInt(full.slice(2, 4), 16);
  const b = parseInt(full.slice(4, 6), 16);
  return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

/** Merge saved items over defaults so records written by older versions
 *  gain the new fields without losing user data. */
function migrateCollections(content: SiteSettings["content"]): SiteSettings["content"] {
  return {
    ...content,
    portfolio: content.portfolio.map((p, i) => {
      // legacy items may carry a plain image URL + category NAME
      const legacy = p as Partial<PortfolioItem> & { image?: string | ImageMeta; category?: string };
      const matchedCategory =
        content.categories.find((c) => c.name === legacy.category) ??
        content.categories.find((c) => c.id === legacy.categoryId);
      const legacyImage: ImageMeta | null =
        typeof legacy.image === "string"
          ? { url: legacy.image, width: 0, height: 0, aspectRatio: 0, fileType: "image/jpeg", fileSize: 0, alt: legacy.title ?? "", createdAt: "" }
          : null;
      return {
        subcategoryId: "",
        description: "",
        client: "",
        date: "",
        tech: [],
        tags: [],
        gallery: [],
        liveUrl: "",
        demoUrl: "",
        githubUrl: "",
        playStoreUrl: "",
        appStoreUrl: "",
        featured: false,
        published: true,
        order: i,
        ...legacy,
        id: legacy.id ?? `project-${i}`,
        categoryId: legacy.categoryId ?? matchedCategory?.id ?? content.categories[0]?.id ?? "",
        image: legacyImage ?? legacy.image ?? {
          url: "",
          width: 0,
          height: 0,
          aspectRatio: 0,
          fileType: "image/jpeg",
          fileSize: 0,
          alt: legacy.title ?? "",
          createdAt: "",
        },
      } as PortfolioItem;
    }),
    services: content.services.map(
      (s, i) => ({ order: i, active: true, ...(s as Partial<ServiceItem>) }) as ServiceItem
    ),
    experience: content.experience.map(
      (e, i) =>
        ({
          location: "",
          current: false,
          order: i,
          active: true,
          ...(e as Partial<ExperienceItem>),
        }) as ExperienceItem
    ),
    skills: content.skills.map(
      (sk, i) => ({ order: i, active: true, ...(sk as Partial<SkillItem>) }) as SkillItem
    ),
    testimonials: (content.testimonials ?? []).map(
      (t, i) => ({ order: i, active: true, ...(t as Partial<TestimonialItem>) }) as TestimonialItem
    ),
    media: content.media ?? [],
    enquiries: content.enquiries ?? [],
  };
}

function loadSettings(): SiteSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw);
    const merged: SiteSettings = {
      ...DEFAULT_SETTINGS,
      ...parsed,
      galaxy: { ...DEFAULT_SETTINGS.galaxy, ...(parsed.galaxy ?? {}) },
      colors: { ...DEFAULT_SETTINGS.colors, ...(parsed.colors ?? {}) },
      content: {
        ...DEFAULT_SETTINGS.content,
        ...(parsed.content ?? {}),
        stats: { ...DEFAULT_SETTINGS.content.stats, ...(parsed.content?.stats ?? {}) },
        website: { ...DEFAULT_SETTINGS.content.website, ...(parsed.content?.website ?? {}) },
        seo: { ...DEFAULT_SETTINGS.content.seo, ...(parsed.content?.seo ?? {}) },
        social: { ...DEFAULT_SETTINGS.content.social, ...(parsed.content?.social ?? {}) },
        sections: { ...DEFAULT_SETTINGS.content.sections, ...(parsed.content?.sections ?? {}) },
      },
      sound: {
        ...DEFAULT_SETTINGS.sound,
        ...(parsed.sound ?? {}),
        // migration: previous default volume was 20% — bump to 65%
        ...(parsed.sound && parsed.sound.volume === 0.2 ? { volume: 0.65 } : {}),
      },
    };
    return { ...merged, content: migrateCollections(merged.content) };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

/* ------------------------------------------------------------------ */
/*  Live SEO metadata application                                      */
/* ------------------------------------------------------------------ */

function setMeta(attr: "name" | "property", key: string, value: string) {
  let el = document.head.querySelector<HTMLMetaElement>(`meta[${attr}="${key}"]`);
  if (!el) {
    el = document.createElement("meta");
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute("content", value);
}

function applySeo(seo: SeoInfo) {
  if (seo.title) document.title = seo.title;
  setMeta("name", "description", seo.description);
  if (seo.keywords) setMeta("name", "keywords", seo.keywords);
  if (seo.robots) setMeta("name", "robots", seo.robots);
  setMeta("property", "og:title", seo.ogTitle || seo.title);
  setMeta("property", "og:description", seo.ogDescription || seo.description);
  if (seo.ogImage) setMeta("property", "og:image", seo.ogImage);
  let canonical = document.head.querySelector<HTMLLinkElement>('link[rel="canonical"]');
  if (!canonical) {
    canonical = document.createElement("link");
    canonical.rel = "canonical";
    document.head.appendChild(canonical);
  }
  if (seo.canonical) canonical.href = seo.canonical;
}

/* ------------------------------------------------------------------ */
/*  Context                                                            */
/* ------------------------------------------------------------------ */

interface SettingsContextValue {
  settings: SiteSettings;
  update: <K extends keyof SiteSettings>(key: K, value: SiteSettings[K]) => void;
  updateGalaxy: <K extends keyof SiteSettings["galaxy"]>(key: K, value: SiteSettings["galaxy"][K]) => void;
  updateColors: <K extends keyof SiteSettings["colors"]>(key: K, value: SiteSettings["colors"][K]) => void;
  updateContent: <K extends keyof SiteSettings["content"]>(key: K, value: SiteSettings["content"][K]) => void;
  updateSound: <K extends keyof SiteSettings["sound"]>(key: K, value: SiteSettings["sound"][K]) => void;
  /**
   * Verified async save: validate → persist to storage → commit to live
   * state. Returns false (with an error toast) when the write fails —
   * the caller's form data is left untouched so nothing is lost.
   */
  saveSection: <K extends keyof SiteSettings>(
    key: K,
    value: SiteSettings[K],
    validate?: (v: SiteSettings[K]) => string | null
  ) => Promise<boolean>;
  reset: () => void;
}

const SettingsContext = createContext<SettingsContextValue | null>(null);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<SiteSettings>(() => loadSettings());
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings));
    } catch {
      /* ignore */
    }
    const root = document.documentElement;
    const { colors } = settings;
    root.style.setProperty("--sd-primary", colors.primary);
    root.style.setProperty("--sd-secondary", colors.secondary);
    root.style.setProperty("--sd-accent", colors.accent);
    root.style.setProperty("--sd-glow", colors.glow);
    root.style.setProperty("--sd-particle", colors.particle);
    root.style.setProperty("--sd-glow-soft", hexToRgba(colors.glow, 0.25));
    root.style.setProperty("--sd-glow-medium", hexToRgba(colors.glow, 0.45));
    applySeo(settings.content.seo);
  }, [settings]);

  const update = useCallback(
    <K extends keyof SiteSettings>(key: K, value: SiteSettings[K]) => {
      setSettings((s) => ({ ...s, [key]: value }));
    },
    []
  );

  const updateGalaxy = useCallback(
    <K extends keyof SiteSettings["galaxy"]>(key: K, value: SiteSettings["galaxy"][K]) => {
      setSettings((s) => ({ ...s, galaxy: { ...s.galaxy, [key]: value } }));
    },
    []
  );

  const updateColors = useCallback(
    <K extends keyof SiteSettings["colors"]>(key: K, value: SiteSettings["colors"][K]) => {
      setSettings((s) => ({ ...s, colors: { ...s.colors, [key]: value } }));
    },
    []
  );

  const updateContent = useCallback(
    <K extends keyof SiteSettings["content"]>(key: K, value: SiteSettings["content"][K]) => {
      setSettings((s) => ({ ...s, content: { ...s.content, [key]: value } }));
    },
    []
  );

  const updateSound = useCallback(
    <K extends keyof SiteSettings["sound"]>(key: K, value: SiteSettings["sound"][K]) => {
      setSettings((s) => ({ ...s, sound: { ...s.sound, [key]: value } }));
    },
    []
  );

  const saveSection = useCallback(
    async <K extends keyof SiteSettings>(
      key: K,
      value: SiteSettings[K],
      validate?: (v: SiteSettings[K]) => string | null
    ): Promise<boolean> => {
      // 1. client-side validation — invalid data is never saved
      const err = validate?.(value) ?? null;
      if (err) {
        toast.error(err);
        return false;
      }
      // 2. verified async write to the persistence layer
      const next = { ...settingsRef.current, [key]: value };
      const result = await persistSettings(next);
      if (!result.ok) {
        toast.error(result.error ?? "Unable to save changes. Please try again.");
        return false;
      }
      // 3. commit to live state — the public website updates instantly
      setSettings(next);
      return true;
    },
    []
  );

  const reset = useCallback(() => setSettings(DEFAULT_SETTINGS), []);

  const value = useMemo(
    () => ({ settings, update, updateGalaxy, updateColors, updateContent, updateSound, saveSection, reset }),
    [settings, update, updateGalaxy, updateColors, updateContent, updateSound, saveSection, reset]
  );

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
}

export function useSettings(): SettingsContextValue {
  const ctx = useContext(SettingsContext);
  if (!ctx) throw new Error("useSettings must be used inside SettingsProvider");
  return ctx;
}
