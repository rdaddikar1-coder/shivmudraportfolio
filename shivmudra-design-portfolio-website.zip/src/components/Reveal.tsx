import type { CSSProperties, ReactNode } from "react";
import { useInView } from "../lib/hooks";
import { cn } from "../utils/cn";

interface RevealProps {
  children: ReactNode;
  delay?: number;
  variant?: "up" | "left" | "right" | "scale";
  className?: string;
  style?: CSSProperties;
}

export default function Reveal({ children, delay = 0, variant = "up", className, style }: RevealProps) {
  const { ref, inView } = useInView<HTMLDivElement>();
  return (
    <div
      ref={ref}
      className={cn(
        "reveal",
        variant === "left" && "reveal-left",
        variant === "right" && "reveal-right",
        variant === "scale" && "reveal-scale",
        inView && "revealed",
        className
      )}
      style={{ transitionDelay: `${delay}ms`, ...style }}
    >
      {children}
    </div>
  );
}
