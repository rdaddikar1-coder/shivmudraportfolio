import { useState } from "react";
import { Upload, Trash2, Image as ImageIcon } from "lucide-react";
import { useSettings } from "../../lib/settings";
import { playUISound } from "../../lib/uiSound";
import { toast } from "../../lib/toast";
import { readImageMeta, ratioLabel, formatFileSize } from "../../lib/imageUtils";
import type { ImageMeta } from "../../data/content";
import type { SiteSettings } from "../../lib/settings";
import { SaveBar, useSaveState, useDraft } from "./ui";

/* ------------------------------------------------------------------ */
/*  Compact image slot uploader — preview, replace, remove            */
/* ------------------------------------------------------------------ */

const labelCls = "mb-1.5 text-[11px] font-bold uppercase tracking-widest";

export function CompactImageUploader({ label, image, fallbackUrl, altFallback, onChange, allowRemove = true }: {
  label: string;
  image: ImageMeta | null;
  fallbackUrl?: string;
  altFallback: string;
  onChange: (img: ImageMeta | null) => void;
  allowRemove?: boolean;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFile = async (file: File) => {
    setError(null);
    setBusy(true);
    const result = await readImageMeta(file, altFallback);
    setBusy(false);
    if (!result.ok) {
      setError(result.error);
      playUISound("ui_error", { category: "admin", soft: true });
      return;
    }
    onChange(result.meta);
    playUISound("ui_upload", { category: "admin", soft: true });
  };

  const previewUrl = image?.url ?? fallbackUrl ?? "";

  return (
    <div className="glass rounded-2xl p-3.5">
      <div className="flex flex-wrap items-center gap-3.5">
        {previewUrl ? (
          <img
            src={previewUrl}
            alt={image?.alt || altFallback || label}
            className="h-16 w-24 shrink-0 rounded-xl object-contain"
            style={{ background: "rgba(248,250,252,0.8)" }}
          />
        ) : (
          <span
            className="flex h-16 w-24 shrink-0 items-center justify-center rounded-xl text-[9px] font-bold"
            style={{ background: "rgba(37,99,235,0.08)", color: "var(--sd-primary)" }}
          >
            NO IMAGE
          </span>
        )}
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-bold" style={{ color: "var(--sd-heading)" }}>{label}</p>
          {busy ? (
            <p className="mt-1 text-xs font-bold" style={{ color: "var(--sd-primary)" }}>Uploading & detecting dimensions…</p>
          ) : image ? (
            <p className="mt-0.5 text-xs" style={{ color: "var(--sd-muted)" }}>
              {image.width} × {image.height} · {ratioLabel(image.width, image.height)} · {formatFileSize(image.fileSize)}
            </p>
          ) : (
            <p className="mt-0.5 text-xs" style={{ color: "var(--sd-muted)" }}>
              {fallbackUrl ? "Using default image — upload to replace" : "No image uploaded yet"}
            </p>
          )}
          {error && <p className="mt-1 text-xs font-bold" style={{ color: "#ef4444" }}>{error}</p>}
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <label
            className="glass flex cursor-pointer items-center gap-1.5 rounded-full px-4 py-2 text-[11px] font-bold transition-transform hover:-translate-y-0.5"
            style={{ color: "var(--sd-heading)" }}
          >
            <Upload size={12} style={{ color: "var(--sd-primary)" }} />
            {image ? "Replace" : "Upload"}
            <input
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) void handleFile(file);
                e.target.value = "";
              }}
            />
          </label>
          {allowRemove && image && (
            <button
              type="button"
              data-sound="none"
              onClick={() => {
                onChange(null);
                playUISound("ui_delete", { category: "admin", soft: true });
              }}
              className="flex h-9 w-9 items-center justify-center rounded-xl transition-transform hover:scale-110"
              style={{ background: "rgba(239,68,68,0.1)", color: "#ef4444" }}
              aria-label={`Remove ${label}`}
            >
              <Trash2 size={13} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Image Management tab — every public website image in one place    */
/* ------------------------------------------------------------------ */

export function ImageManagementTab() {
  const { settings, saveSection } = useSettings();
  const { draft, setDraft, revert, markClean, dirty } = useDraft(settings.content);
  const { status, run } = useSaveState();

  const save = () => run(async () => {
    const ok = await saveSection("content", draft);
    if (ok) { markClean(); toast.success("Images saved successfully"); }
    return ok;
  });

  const set = (patch: Partial<SiteSettings["content"]>) => setDraft({ ...draft, ...patch });

  const setCategoryImage = (id: string, img: ImageMeta | null) =>
    set({ categories: draft.categories.map((c) => (c.id === id ? { ...c, image: img } : c)) });

  const setSubcategoryImage = (id: string, img: ImageMeta | null) =>
    set({ subcategories: draft.subcategories.map((s) => (s.id === id ? { ...s, image: img } : s)) });

  const setProjectCover = (id: string, img: ImageMeta | null) =>
    set({
      portfolio: draft.portfolio.map((p) =>
        p.id === id
          ? { ...p, image: img ?? { url: "", width: 0, height: 0, aspectRatio: 0, fileType: "image/jpeg", fileSize: 0, alt: p.title, createdAt: "" } }
          : p
      ),
    });

  const catName = (id: string) => draft.categories.find((c) => c.id === id)?.name ?? "—";

  const subcategoriesWithSlots = draft.subcategories;
  const hasSubcategoryImages = subcategoriesWithSlots.some((s) => s.image);

  return (
    <div className="space-y-5">
      <div>
        <h2 className="heading-text text-xl font-bold">Image Management</h2>
        <p className="mt-0.5 text-xs" style={{ color: "var(--sd-muted)" }}>
          Every image on the public website — upload, replace or remove, then save once. Original ratios are always preserved.
        </p>
      </div>

      {/* Hero images */}
      <div>
        <p className={labelCls} style={{ color: "var(--sd-muted)" }}>Hero Images</p>
        <div className="space-y-2.5">
          <CompactImageUploader
            label="Hero — Desktop"
            image={draft.heroImage}
            fallbackUrl="/images/hero.jpg"
            altFallback={draft.heroTitle || "Hero"}
            onChange={(img) => set({ heroImage: img })}
          />
          <CompactImageUploader
            label="Hero — Mobile"
            image={draft.heroImageMobile}
            fallbackUrl=""
            altFallback={draft.heroTitle || "Hero"}
            onChange={(img) => set({ heroImageMobile: img })}
          />
          <div className="glass rounded-2xl px-4 py-3">
            <p className={`${labelCls} !mb-1`} style={{ color: "var(--sd-muted)" }}>Hero Image Alt Text</p>
            <input
              type="text"
              value={draft.heroImageAlt}
              onChange={(e) => set({ heroImageAlt: e.target.value })}
              placeholder="Shivmudra Design — creative studio"
              className="glass w-full rounded-xl px-4 py-2.5 text-sm font-medium outline-none focus:shadow-[0_0_0_3px_var(--sd-glow-soft)]"
              style={{ color: "var(--sd-heading)" }}
            />
          </div>
        </div>
      </div>

      {/* About image */}
      <div>
        <p className={labelCls} style={{ color: "var(--sd-muted)" }}>About — Profile Image</p>
        <CompactImageUploader
          label="About — Profile"
          image={draft.aboutImage}
          fallbackUrl="/images/about.jpg"
          altFallback="Founder of Shivmudra Design"
          onChange={(img) => set({ aboutImage: img })}
        />
      </div>

      {/* Category images */}
      <div>
        <p className={labelCls} style={{ color: "var(--sd-muted)" }}>
          Category Images ({draft.categories.length})
        </p>
        <div className="space-y-2.5">
          {draft.categories.map((c) => (
            <CompactImageUploader
              key={c.id}
              label={`${c.name} (order ${c.order})`}
              image={c.image}
              fallbackUrl=""
              altFallback={c.name}
              onChange={(img) => setCategoryImage(c.id, img)}
            />
          ))}
        </div>
      </div>

      {/* Subcategory images */}
      <div>
        <p className={labelCls} style={{ color: "var(--sd-muted)" }}>
          Subcategory Images {hasSubcategoryImages ? `(${subcategoriesWithSlots.filter((s) => s.image).length} uploaded)` : ""}
        </p>
        <div className="space-y-2.5">
          {subcategoriesWithSlots.map((s) => (
            <CompactImageUploader
              key={s.id}
              label={`${catName(s.parentId)} › ${s.name}`}
              image={s.image}
              fallbackUrl=""
              altFallback={s.name}
              onChange={(img) => setSubcategoryImage(s.id, img)}
            />
          ))}
        </div>
      </div>

      {/* Portfolio covers */}
      <div>
        <p className={labelCls} style={{ color: "var(--sd-muted)" }}>
          Portfolio Cover Images ({draft.portfolio.length}) — gallery images are managed inside each project
        </p>
        <div className="space-y-2.5">
          {draft.portfolio.map((p) => (
            <CompactImageUploader
              key={p.id}
              label={p.title}
              image={p.image?.url ? p.image : null}
              fallbackUrl={p.image?.url}
              altFallback={p.title}
              onChange={(img) => setProjectCover(p.id, img)}
              allowRemove={false}
            />
          ))}
        </div>
      </div>

      <SaveBar status={status} dirty={dirty} onSave={save} onCancel={revert} label="Save Changes" />

      <div className="glass flex items-start gap-3 rounded-2xl p-4">
        <ImageIcon size={16} className="mt-0.5 shrink-0" style={{ color: "var(--sd-primary)" }} />
        <p className="text-xs leading-relaxed" style={{ color: "var(--sd-muted)" }}>
          Uploaded images are stored in persistent storage with their detected dimensions, aspect ratio,
          file type, size, alt text and creation date. Replacements only take effect after
          <strong> Save Changes</strong> — the previous image stays in place until the new one is saved,
          and cancelled changes never affect the live website.
        </p>
      </div>
    </div>
  );
}
