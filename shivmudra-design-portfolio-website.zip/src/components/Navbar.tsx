import { useEffect, useState } from "react";
import { Menu, X, Volume2, VolumeX, Sparkles, Settings2 } from "lucide-react";
import { NAV_LINKS } from "../data/content";
import { useSettings } from "../lib/settings";
import { useAuth } from "../lib/auth";
import { soundEngine } from "../lib/sound";

export default function Navbar() {
  const { settings, updateSound } = useSettings();
  const { isAdmin } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState("home");

  /* Admin menu item — authenticated admins go straight to the dashboard */
  const adminHref = isAdmin ? "#/admin" : "#/admin/login";

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      const ids = NAV_LINKS.map((l) => l.href.slice(1));
      let current = "home";
      for (const id of ids) {
        const el = document.getElementById(id);
        if (el && el.getBoundingClientRect().top <= 140) current = id;
      }
      setActive(current);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const toggleSound = () => {
    soundEngine.unlock();
    const next = !settings.sound.enabled;
    updateSound("enabled", next);
    soundEngine.setEnabled(next);
    if (next) soundEngine.play("ui_toggle_on", { category: null });
  };

  const toggleMenu = () => {
    soundEngine.unlock();
    const next = !open;
    setOpen(next);
    soundEngine.play(next ? "ui_open" : "ui_close", { category: "button" });
  };

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "shadow-[0_8px_40px_rgba(59,130,246,0.10)]" : ""
      }`}
      style={{
        background: scrolled ? "rgba(255,255,255,0.85)" : "rgba(255,255,255,0.55)",
        backdropFilter: "blur(18px)",
        WebkitBackdropFilter: "blur(18px)",
        borderBottom: "1px solid rgba(191,219,254,0.55)",
      }}
    >
      <nav className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-5 sm:px-8">
        {/* Logo */}
        <a href="#home" className="group flex items-center gap-3">
          <span
            className="relative flex h-10 w-10 items-center justify-center rounded-xl text-white shadow-lg transition-transform duration-500 group-hover:rotate-[30deg]"
            style={{
              background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))",
              boxShadow: "0 8px 24px -6px var(--sd-glow-medium)",
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M12 2 21 7v10l-9 5-9-5V7l9-5Z" stroke="white" strokeWidth="1.8" strokeLinejoin="round" />
              <path d="M9.5 15.5c-1.5-1-1.5-2.7 0-3.4l5-2.2c1.5-.7 1.5-2.4 0-3.4" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </span>
          <span className="heading-text text-lg font-bold tracking-tight sm:text-xl">
            Shivmudra <span className="text-gradient">Design</span>
          </span>
        </a>

        {/* Desktop links */}
        <div className="hidden items-center gap-7 lg:flex">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="nav-link"
              style={{ color: active === link.href.slice(1) ? "var(--sd-primary)" : undefined }}
            >
              {link.label}
            </a>
          ))}
          <span className="hidden h-4 w-px lg:block" style={{ background: "rgba(148,163,184,0.35)" }} />
          <a href={adminHref} className="nav-link admin-nav-link inline-flex items-center gap-1.5" aria-label="Admin panel">
            <Settings2 size={13} className="admin-nav-icon" />
            Admin
          </a>
        </div>

        {/* Right controls */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={toggleSound}
            data-sound="none"
            className="glass flex h-10 w-10 items-center justify-center rounded-full transition-transform hover:scale-110"
            aria-label="Toggle sound"
          >
            {settings.sound.enabled ? (
              <Volume2 size={16} style={{ color: "var(--sd-primary)" }} />
            ) : (
              <VolumeX size={16} style={{ color: "var(--sd-muted)" }} />
            )}
          </button>

          <a
            href="#contact"
            className="btn-primary hidden! px-5! py-2.5! text-sm! sm:inline-flex!"
          >
            <Sparkles size={15} />
            Start a Project
          </a>

          <button
            data-sound="none"
            className="glass flex h-10 w-10 items-center justify-center rounded-full lg:hidden"
            onClick={toggleMenu}
            aria-label="Menu"
          >
            {open ? <X size={18} style={{ color: "var(--sd-heading)" }} /> : <Menu size={18} style={{ color: "var(--sd-heading)" }} />}
          </button>
        </div>
      </nav>

      {/* Mobile menu */}
      <div
        className={`overflow-hidden transition-all duration-500 lg:hidden ${
          open ? "max-h-[420px]" : "max-h-0"
        }`}
        style={{
          background: "rgba(255,255,255,0.92)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)",
          borderBottom: open ? "1px solid rgba(191,219,254,0.55)" : "none",
        }}
      >
        <div className="flex flex-col gap-1 px-6 py-4">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="rounded-xl px-4 py-3 text-sm font-medium transition-colors hover:bg-blue-50"
              style={{ color: "var(--sd-heading)" }}
              onClick={() => setOpen(false)}
            >
              {link.label}
            </a>
          ))}

          <div className="my-2 h-px" style={{ background: "linear-gradient(90deg, transparent, rgba(37,99,235,0.35), transparent)" }} />
          <a
            href={adminHref}
            onClick={() => setOpen(false)}
            className="flex items-center gap-2.5 rounded-xl px-4 py-3 text-sm font-bold transition-colors hover:bg-blue-50"
            style={{ color: "var(--sd-primary)" }}
          >
            <Settings2 size={15} />
            Admin
          </a>
          <div className="my-2 h-px" style={{ background: "linear-gradient(90deg, transparent, rgba(37,99,235,0.35), transparent)" }} />

          <a href="#contact" className="btn-primary mt-1 w-full py-3! text-sm!" onClick={() => setOpen(false)}>
            <Sparkles size={15} />
            Start a Project
          </a>
        </div>
      </div>
    </header>
  );
}
