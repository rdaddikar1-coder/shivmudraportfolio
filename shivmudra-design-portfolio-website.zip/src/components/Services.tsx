import { ArrowUpRight } from "lucide-react";
import Reveal from "./Reveal";
import SectionHead from "./SectionHead";
import { useSettings } from "../lib/settings";
import { SERVICE_ICONS } from "../data/content";
import { Palette } from "lucide-react";

export default function Services() {
  const { settings } = useSettings();
  const services = settings.content.services
    .filter((s) => s.active)
    .sort((a, b) => a.order - b.order);

  return (
    <section id="services" className="relative scroll-mt-24 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHead
          badge="What I Do"
          title={
            <>
              Services Engineered for <span className="text-gradient">Impact</span>
            </>
          }
          description="A complete creative technology stack — from first sketch to final launch, every service is crafted with precision."
        />

        {services.length === 0 ? (
          <div className="glass mx-auto max-w-md rounded-3xl px-8 py-12 text-center">
            <p className="heading-text text-lg font-bold">Services coming soon</p>
            <p className="mt-2 text-sm" style={{ color: "var(--sd-muted)" }}>
              New services are being prepared. Check back shortly.
            </p>
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {services.map((service, i) => {
              const Icon = SERVICE_ICONS[service.icon] ?? Palette;
              return (
                <Reveal key={`${service.title}-${i}`} delay={(i % 3) * 120}>
                  <article className="service-card glass group h-full cursor-pointer rounded-3xl p-7" data-sound="ui_card">
                    {/* inner particles that brighten on hover */}
                    <span
                      className="pointer-events-none absolute right-8 top-8 h-1.5 w-1.5 rounded-full opacity-40 transition-all duration-500 group-hover:opacity-100 group-hover:shadow-[0_0_12px_var(--sd-glow-medium)]"
                      style={{ background: "var(--sd-secondary)" }}
                    />
                    <span
                      className="pointer-events-none absolute bottom-10 left-9 h-1 w-1 rounded-full opacity-30 transition-all duration-500 group-hover:opacity-90 group-hover:shadow-[0_0_10px_var(--sd-glow-medium)]"
                      style={{ background: "var(--sd-primary)" }}
                    />
                    <span
                      className="pointer-events-none absolute right-1/3 top-1/2 h-1 w-1 rounded-full opacity-20 transition-all duration-500 group-hover:opacity-80"
                      style={{ background: "var(--sd-accent)" }}
                    />

                    {/* icon */}
                    <div className="relative">
                      <span
                        className="absolute inset-0 rounded-2xl opacity-0 blur-lg transition-opacity duration-500 group-hover:opacity-70"
                        style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" }}
                      />
                      <span
                        className="relative flex h-14 w-14 items-center justify-center rounded-2xl text-white transition-transform duration-500 group-hover:scale-110"
                        style={{
                          background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))",
                          boxShadow: "0 10px 26px -8px var(--sd-glow-medium)",
                        }}
                      >
                        <Icon size={24} />
                      </span>
                    </div>

                    <h3 className="heading-text mt-6 text-xl font-bold">{service.title}</h3>
                    <p className="mt-3 text-sm leading-relaxed" style={{ color: "var(--sd-body)" }}>
                      {service.description}
                    </p>

                    <div className="mt-5 flex flex-wrap gap-2">
                      {service.tags.map((tag) => (
                        <span
                          key={tag}
                          className="rounded-full px-3 py-1 text-[11px] font-semibold"
                          style={{
                            color: "var(--sd-primary)",
                            background: "rgba(37,99,235,0.07)",
                            border: "1px solid rgba(147,197,253,0.4)",
                          }}
                        >
                          {tag}
                        </span>
                      ))}
                    </div>

                    <a
                      href="#contact"
                      className="mt-6 inline-flex items-center gap-1.5 text-sm font-semibold transition-all duration-300 group-hover:gap-3"
                      style={{ color: "var(--sd-primary)" }}
                    >
                      Explore service
                      <ArrowUpRight size={16} />
                    </a>
                  </article>
                </Reveal>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
