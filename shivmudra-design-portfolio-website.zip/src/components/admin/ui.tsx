import { useEffect, useRef, useState } from "react";
import { Check, Loader2, AlertTriangle, Save, X, Copy, Trash2 } from "lucide-react";
import { subscribeToasts, type ToastItem } from "../../lib/toast";

/* ================================================================== */
/*  Toast host — global success / error feedback                       */
/* ================================================================== */

export function ToastHost() {
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  useEffect(
    () =>
      subscribeToasts((t) => {
        setToasts((prev) => [...prev.slice(-3), t]);
        window.setTimeout(() => {
          setToasts((prev) => prev.filter((x) => x.id !== t.id));
        }, 3600);
      }),
    []
  );

  return (
    <div className="pointer-events-none fixed right-4 top-20 z-[120] flex w-[calc(100%-2rem)] max-w-sm flex-col gap-2.5 sm:right-6">
      {toasts.map((t) => (
        <div
          key={t.id}
          className="glass-strong pointer-events-auto flex items-center gap-3 rounded-2xl px-4 py-3.5"
          style={{
            boxShadow: "0 18px 45px -12px var(--sd-glow-medium)",
            borderLeft: `4px solid ${t.kind === "success" ? "var(--sd-primary)" : "#ef4444"}`,
            animation: "letter-in 0.45s cubic-bezier(0.22,1,0.36,1) both",
          }}
          role="status"
        >
          <span
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white"
            style={{
              background:
                t.kind === "success"
                  ? "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))"
                  : "linear-gradient(135deg, #ef4444, #f97316)",
            }}
          >
            {t.kind === "success" ? <Check size={16} /> : <AlertTriangle size={16} />}
          </span>
          <p className="text-sm font-semibold" style={{ color: "var(--sd-heading)" }}>
            {t.message}
          </p>
        </div>
      ))}
    </div>
  );
}

/* ================================================================== */
/*  Save state machine — Loading / Success / Error / duplicate guard   */
/* ================================================================== */

export type SaveStatus = "idle" | "saving" | "saved" | "error";

export function useSaveState() {
  const [status, setStatus] = useState<SaveStatus>("idle");
  const busyRef = useRef(false);

  const run = async (fn: () => Promise<boolean>) => {
    if (busyRef.current) return false; // block duplicate save clicks
    busyRef.current = true;
    setStatus("saving");
    const ok = await fn();
    busyRef.current = false;
    setStatus(ok ? "saved" : "error");
    window.setTimeout(() => setStatus("idle"), ok ? 2200 : 3000);
    return ok;
  };

  return { status, run };
}

export function SaveButton({
  status,
  dirty,
  onClick,
  label = "Save Changes",
}: {
  status: SaveStatus;
  dirty: boolean;
  onClick: () => void;
  label?: string;
}) {
  if (status === "saving") {
    return (
      <button
        type="button"
        disabled
        className="flex items-center gap-2 rounded-full px-6 py-2.5 text-xs font-bold text-white"
        style={{ background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))", opacity: 0.75 }}
      >
        <Loader2 size={14} className="animate-spin" />
        Saving...
      </button>
    );
  }
  if (status === "saved") {
    return (
      <button
        type="button"
        disabled
        className="flex items-center gap-2 rounded-full px-6 py-2.5 text-xs font-bold text-white"
        style={{ background: "linear-gradient(120deg, #10b981, #06b6d4)" }}
      >
        <Check size={14} />
        Saved ✓
      </button>
    );
  }
  if (status === "error") {
    return (
      <button
        type="button"
        onClick={onClick}
        className="flex items-center gap-2 rounded-full px-6 py-2.5 text-xs font-bold text-white transition-transform hover:-translate-y-0.5"
        style={{ background: "linear-gradient(120deg, #ef4444, #f97316)" }}
      >
        <AlertTriangle size={14} />
        Retry Save
      </button>
    );
  }
  if (!dirty) {
    return (
      <button
        type="button"
        disabled
        className="flex items-center gap-2 rounded-full px-6 py-2.5 text-xs font-bold"
        style={{ background: "rgba(148,163,184,0.2)", color: "var(--sd-muted)", cursor: "not-allowed" }}
      >
        <Save size={14} />
        No changes
      </button>
    );
  }
  return (
    <button
      type="button"
      onClick={onClick}
      className="flex items-center gap-2 rounded-full px-6 py-2.5 text-xs font-bold text-white transition-transform hover:-translate-y-0.5"
      style={{
        background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))",
        boxShadow: "0 8px 20px -6px var(--sd-glow-medium)",
      }}
    >
      <Save size={14} />
      {label}
    </button>
  );
}

/** Standard Cancel | Save bar used by every edit form. */
export function SaveBar({
  status,
  dirty,
  onSave,
  onCancel,
  label,
  extra,
}: {
  status: SaveStatus;
  dirty: boolean;
  onSave: () => void;
  onCancel: () => void;
  label?: string;
  extra?: React.ReactNode;
}) {
  return (
    <div
      className="sticky bottom-4 z-10 mt-5 flex flex-wrap items-center justify-between gap-3 rounded-2xl px-4 py-3"
      style={{ background: "rgba(255,255,255,0.9)", backdropFilter: "blur(14px)", border: "1px solid rgba(191,219,254,0.7)", boxShadow: "0 12px 35px -12px var(--sd-glow-medium)" }}
    >
      <div className="flex items-center gap-2.5">
        {dirty && status === "idle" ? (
          <span className="flex items-center gap-1.5 text-xs font-bold" style={{ color: "#b45309" }}>
            <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#f59e0b", boxShadow: "0 0 8px rgba(245,158,11,0.8)" }} />
            Unsaved changes
          </span>
        ) : (
          <span className="text-xs font-semibold" style={{ color: "var(--sd-muted)" }}>
            {status === "saved" ? "All changes saved" : "All changes saved"}
          </span>
        )}
        {extra}
      </div>
      <div className="flex items-center gap-2.5">
        <button
          type="button"
          onClick={onCancel}
          data-sound="none"
          className="glass rounded-full px-5 py-2.5 text-xs font-bold transition-transform hover:-translate-y-0.5"
          style={{ color: "var(--sd-heading)" }}
        >
          Cancel
        </button>
        <SaveButton status={status} dirty={dirty} onClick={onSave} label={label} />
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Draft state + global unsaved-changes tracking                      */
/* ================================================================== */

let dirtyCount = 0;
const dirtyListeners = new Set<() => void>();
const reverters = new Set<() => void>();

function notifyDirty() {
  dirtyListeners.forEach((l) => l());
}

/** Register/unregister a dirty draft. */
function setDirty(dirty: boolean, revert: () => void) {
  const before = dirtyCount;
  if (dirty) {
    dirtyCount += 1;
    reverters.add(revert);
  } else {
    dirtyCount = Math.max(0, dirtyCount - 1);
    reverters.delete(revert);
  }
  if (before !== dirtyCount) notifyDirty();
}

export function hasUnsavedChanges(): boolean {
  return dirtyCount > 0;
}

export function discardAllUnsaved() {
  reverters.forEach((r) => r());
  dirtyCount = 0;
  reverters.clear();
  notifyDirty();
}

export function useDirtyListener(cb: () => void) {
  useEffect(() => {
    dirtyListeners.add(cb);
    return () => {
      dirtyListeners.delete(cb);
    };
  }, [cb]);
}

/**
 * Draft copy of a saved value. Tracks dirty state, registers with the
 * global unsaved-changes tracker (leave warnings) and can revert.
 */
export function useDraft<T>(saved: T) {
  const [draft, setDraftState] = useState<T>(saved);
  const [dirty, setDirtyState] = useState(false);
  const revertRef = useRefRevert();

  // keep draft in sync with external resets (e.g. "Reset All")
  useEffect(() => {
    if (!dirty) setDraftState(saved);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [saved]);

  const revert = () => {
    setDraftState(saved);
    setDirtyState(false);
  };
  revertRef.current = revert;

  useEffect(() => {
    setDirty(dirty, revertRef.current);
    return () => setDirty(false, revertRef.current);
  }, [dirty]);

  const setDraft = (updater: T | ((prev: T) => T)) => {
    setDraftState((prev) => (typeof updater === "function" ? (updater as (p: T) => T)(prev) : updater));
    setDirtyState(true);
  };

  const markClean = () => setDirtyState(false);

  return { draft, setDraft, revert, markClean, dirty };
}

// small helper so useDraft can register a stable revert fn
function useRefRevert() {
  return useRef(() => undefined) as React.MutableRefObject<() => void>;
}

/* ================================================================== */
/*  Unsaved-changes dialog (tab navigation guard)                      */
/* ================================================================== */

export function UnsavedDialog({ targetTab, onStay, onDiscard }: {
  targetTab: string;
  onStay: () => void;
  onDiscard: () => void;
}) {
  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center px-5" style={{ background: "rgba(15,23,42,0.35)", backdropFilter: "blur(6px)" }}>
      <div
        className="glass-strong w-full max-w-md rounded-3xl p-7"
        style={{ boxShadow: "0 30px 70px -18px var(--sd-glow-medium)" }}
        role="alertdialog"
        aria-modal
      >
        <span
          className="flex h-12 w-12 items-center justify-center rounded-2xl text-white"
          style={{ background: "linear-gradient(135deg, #f59e0b, #f97316)" }}
        >
          <AlertTriangle size={22} />
        </span>
        <h3 className="heading-text mt-4 text-lg font-bold">You have unsaved changes.</h3>
        <p className="mt-2 text-sm leading-relaxed" style={{ color: "var(--sd-body)" }}>
          You are about to leave the <strong>{targetTab}</strong> section with changes that have not
          been saved yet.
        </p>
        <div className="mt-6 flex flex-col gap-2.5 sm:flex-row sm:justify-end">
          <button
            type="button"
            onClick={onStay}
            data-sound="none"
            className="glass rounded-full px-5 py-2.5 text-xs font-bold"
            style={{ color: "var(--sd-heading)" }}
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={onStay}
            data-sound="none"
            className="rounded-full px-5 py-2.5 text-xs font-bold text-white"
            style={{ background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))" }}
          >
            Stay &amp; Save
          </button>
          <button
            type="button"
            onClick={onDiscard}
            data-sound="none"
            className="rounded-full px-5 py-2.5 text-xs font-bold text-white"
            style={{ background: "linear-gradient(120deg, #ef4444, #f97316)" }}
          >
            Discard Changes
          </button>
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Two-click delete confirmation                                      */
/* ================================================================== */

export function ConfirmDeleteButton({ onConfirm, label = "Delete" }: { onConfirm: () => void; label?: string }) {
  const [arming, setArming] = useState(false);

  useEffect(() => {
    if (!arming) return;
    const id = window.setTimeout(() => setArming(false), 3000);
    return () => window.clearTimeout(id);
  }, [arming]);

  if (!arming) {
    return (
      <button
        type="button"
        onClick={() => setArming(true)}
        data-sound="none"
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-transform hover:scale-110"
        style={{ background: "rgba(239,68,68,0.1)", color: "#ef4444" }}
        aria-label={label}
        title={label}
      >
        <Trash2 size={14} />
      </button>
    );
  }
  return (
    <button
      type="button"
      onClick={() => {
        setArming(false);
        onConfirm();
      }}
      data-sound="none"
      className="flex h-9 shrink-0 items-center gap-1.5 rounded-xl px-3 text-[10px] font-bold text-white"
      style={{ background: "#ef4444" }}
    >
      <Trash2 size={12} />
      SURE?
    </button>
  );
}

/** Duplicate action button for CRUD lists. */
export function DuplicateButton({ onDuplicate }: { onDuplicate: () => void }) {
  return (
    <button
      type="button"
      onClick={onDuplicate}
      data-sound="none"
      className="glass flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-transform hover:scale-110"
      style={{ color: "var(--sd-primary)" }}
      aria-label="Duplicate"
      title="Duplicate"
    >
      <Copy size={14} />
    </button>
  );
}

export { X };
