import { useState } from "react";
import {
  Plus,
  Pencil,
  Inbox,
  Image as ImageIcon,
  Mail,
  CalendarDays,
  Quote,
  Upload,
  Link2,
  Star,
  Trash2,
  type LucideIcon,
} from "lucide-react";
import { useSettings } from "../../lib/settings";
import { playUISound } from "../../lib/uiSound";
import { toast } from "../../lib/toast";
import { readImageMeta } from "../../lib/imageUtils";
import {
  SERVICE_ICONS,
  type ServiceItem,
  type ExperienceItem,
  type SkillItem,
  type TestimonialItem,
  type MediaItem,
} from "../../data/content";
import { SaveBar, useSaveState, ConfirmDeleteButton, DuplicateButton } from "./ui";

export { PortfolioTab, CategoriesTab } from "./AdminPortfolio";

/* ------------------------------------------------------------------ */
/*  Shared CRUD form primitives                                       */
/* ------------------------------------------------------------------ */

const labelCls = "mb-1.5 text-[11px] font-bold uppercase tracking-widest";
const inputCls =
  "glass w-full rounded-xl px-4 py-2.5 text-sm font-medium outline-none transition-shadow focus:shadow-[0_0_0_3px_var(--sd-glow-soft)]";

function CrudField({ label, value, onChange, placeholder, type = "text" }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <p className={labelCls} style={{ color: "var(--sd-muted)" }}>{label}</p>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={inputCls}
        style={{ color: "var(--sd-heading)" }}
      />
    </div>
  );
}

function CrudTextarea({ label, value, onChange, rows = 3, placeholder }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  rows?: number;
  placeholder?: string;
}) {
  return (
    <div>
      <p className={labelCls} style={{ color: "var(--sd-muted)" }}>{label}</p>
      <textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        rows={rows}
        className={`${inputCls} resize-none`}
        style={{ color: "var(--sd-heading)" }}
      />
    </div>
  );
}

function CrudSelect({ label, value, onChange, options }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: string[];
}) {
  return (
    <div>
      <p className={labelCls} style={{ color: "var(--sd-muted)" }}>{label}</p>
      <select value={value} onChange={(e) => onChange(e.target.value)} className={inputCls} style={{ color: "var(--sd-heading)" }}>
        {options.map((opt) => (
          <option key={opt} value={opt} className="bg-white text-slate-900">{opt}</option>
        ))}
      </select>
    </div>
  );
}

function CrudCheckbox({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <label
      className="glass flex cursor-pointer items-center justify-between gap-3 rounded-xl px-4 py-3"
      style={{ color: "var(--sd-heading)" }}
    >
      <span className="text-sm font-semibold">{label}</span>
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onChange(e.target.checked)}
        className="h-4.5 w-4.5 cursor-pointer"
        style={{ accentColor: "var(--sd-primary)", width: 18, height: 18 }}
      />
    </label>
  );
}

function EditPanel({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div
      className="rounded-3xl p-5 sm:p-6"
      style={{ background: "rgba(255,255,255,0.75)", border: "1.5px dashed rgba(37,99,235,0.45)" }}
    >
      <p className="mb-4 text-sm font-bold" style={{ color: "var(--sd-heading)" }}>{title}</p>
      <div className="grid gap-4 sm:grid-cols-2">{children}</div>
    </div>
  );
}

function AddButton({ label, onClick }: { label: string; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      data-sound="none"
      className="flex items-center gap-2 rounded-full px-5 py-2.5 text-xs font-bold text-white transition-transform hover:-translate-y-0.5"
      style={{
        background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))",
        boxShadow: "0 8px 20px -6px var(--sd-glow-medium)",
      }}
    >
      <Plus size={15} />
      {label}
    </button>
  );
}

function EmptyState({ icon: Icon, title, text }: { icon: LucideIcon; title: string; text: string }) {
  return (
    <div className="glass flex flex-col items-center rounded-2xl px-6 py-10 text-center">
      <span
        className="flex h-12 w-12 items-center justify-center rounded-2xl"
        style={{ background: "rgba(37,99,235,0.08)", color: "var(--sd-primary)" }}
      >
        <Icon size={20} />
      </span>
      <p className="mt-3 text-sm font-bold" style={{ color: "var(--sd-heading)" }}>{title}</p>
      <p className="mt-1 text-xs" style={{ color: "var(--sd-muted)" }}>{text}</p>
    </div>
  );
}

function TabHeader({ title, subtitle, action }: { title: string; subtitle: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div>
        <h2 className="heading-text text-xl font-bold">{title}</h2>
        <p className="mt-0.5 text-xs" style={{ color: "var(--sd-muted)" }}>{subtitle}</p>
      </div>
      {action}
    </div>
  );
}

/* ================================================================== */
/*  Services CRUD                                                      */
/* ================================================================== */

interface ServiceDraft {
  icon: string; title: string; description: string; tags: string; order: string; active: boolean;
}

export function ServicesTab() {
  const { settings, saveSection } = useSettings();
  const items = settings.content.services;
  const [editing, setEditing] = useState<number | "new" | null>(null);
  const [draft, setDraft] = useState<ServiceDraft>({ icon: "palette", title: "", description: "", tags: "", order: "0", active: true });
  const [error, setError] = useState<string | null>(null);
  const { status, run } = useSaveState();

  const startNew = () => {
    setDraft({ icon: "palette", title: "", description: "", tags: "", order: String(items.length), active: true });
    setError(null);
    setEditing("new");
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const startEdit = (i: number) => {
    const it = items[i];
    setDraft({ icon: it.icon, title: it.title, description: it.description, tags: it.tags.join(", "), order: String(it.order), active: it.active });
    setError(null);
    setEditing(i);
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const cancel = () => { setEditing(null); setError(null); };
  const fail = (msg: string) => { setError(msg); playUISound("ui_error", { category: "admin", soft: true }); return false; };

  const save = () => run(async () => {
    if (!draft.title.trim()) return fail("Service name is required.");
    if (!draft.description.trim()) return fail("Service description is required.");
    const item: ServiceItem = {
      icon: draft.icon,
      title: draft.title.trim(),
      description: draft.description.trim(),
      tags: draft.tags.split(",").map((t) => t.trim()).filter(Boolean),
      order: Number(draft.order) || 0,
      active: draft.active,
    };
    const next = editing === "new" ? [...items, item] : items.map((it, i) => (i === editing ? item : it));
    const ok = await saveSection("content", { ...settings.content, services: next });
    if (ok) { toast.success(`Service ${editing === "new" ? "created" : "updated"} successfully`); cancel(); }
    return ok;
  });
  const remove = async (i: number) => {
    const ok = await saveSection("content", { ...settings.content, services: items.filter((_, idx) => idx !== i) });
    if (ok) { toast.success("Service deleted"); playUISound("ui_delete", { category: "admin", soft: true }); }
  };
  const duplicate = (i: number) => {
    const copy: ServiceItem = { ...items[i], title: `${items[i].title} (Copy)`, order: items.length };
    saveSection("content", { ...settings.content, services: [...items, copy] }).then((ok) => {
      if (ok) toast.success("Service duplicated — edit and save it");
    });
  };

  return (
    <div className="space-y-4">
      <TabHeader
        title="Services"
        subtitle={`${items.length} service${items.length === 1 ? "" : "s"} · add, edit, duplicate or remove`}
        action={editing === null ? <AddButton label="Add Service" onClick={startNew} /> : undefined}
      />

      {editing !== null && (
        <EditPanel title={editing === "new" ? "New Service" : "Edit Service"}>
          <div className="sm:col-span-2">
            <p className={labelCls} style={{ color: "var(--sd-muted)" }}>Icon</p>
            <div className="flex flex-wrap gap-2">
              {Object.entries(SERVICE_ICONS).map(([key, Icon]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setDraft({ ...draft, icon: key })}
                  className="flex h-10 w-10 items-center justify-center rounded-xl transition-all duration-300 hover:-translate-y-0.5"
                  style={
                    draft.icon === key
                      ? { background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))", color: "#fff", boxShadow: "0 6px 16px -4px var(--sd-glow-medium)" }
                      : { background: "rgba(255,255,255,0.7)", color: "var(--sd-muted)", border: "1px solid rgba(191,219,254,0.6)" }
                  }
                  aria-label={`Icon ${key}`}
                >
                  <Icon size={16} />
                </button>
              ))}
            </div>
          </div>
          <CrudField label="Service Name" value={draft.title} onChange={(v) => setDraft({ ...draft, title: v })} placeholder="Graphic Design" />
          <CrudField label="Tags (comma separated)" value={draft.tags} onChange={(v) => setDraft({ ...draft, tags: v })} placeholder="Branding, Logo" />
          <div className="sm:col-span-2">
            <CrudTextarea label="Description" value={draft.description} onChange={(v) => setDraft({ ...draft, description: v })} placeholder="What does this service include?" />
          </div>
          <CrudField label="Sort Order" type="number" value={draft.order} onChange={(v) => setDraft({ ...draft, order: v })} placeholder="0" />
          <CrudCheckbox label="Active (visible on website)" checked={draft.active} onChange={(v) => setDraft({ ...draft, active: v })} />
          <div className="sm:col-span-2">
            <SaveBar status={status} dirty onSave={save} onCancel={cancel}
              label={editing === "new" ? "Save & Publish" : "Save Changes"}
              extra={error ? <span className="text-xs font-bold" style={{ color: "#ef4444" }}>{error}</span> : undefined} />
          </div>
        </EditPanel>
      )}

      {items.length === 0 && editing === null ? (
        <EmptyState icon={Pencil} title="No services yet" text="Add your first service card." />
      ) : (
        <div className="space-y-2.5">
          {items.map((item, i) => {
            const Icon = SERVICE_ICONS[item.icon] ?? Pencil;
            return (
              <div key={`${item.title}-${i}`} className="glass flex items-center gap-4 rounded-2xl p-3">
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-white" style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))", opacity: item.active ? 1 : 0.45 }}>
                  <Icon size={17} />
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-bold" style={{ color: "var(--sd-heading)" }}>
                    {item.title}
                    {!item.active && <span className="ml-2 rounded-full px-2 py-0.5 text-[9px] font-bold" style={{ background: "rgba(148,163,184,0.2)", color: "var(--sd-muted)" }}>INACTIVE</span>}
                  </p>
                  <p className="truncate text-xs" style={{ color: "var(--sd-muted)" }}>{item.description}</p>
                </div>
                <DuplicateButton onDuplicate={() => duplicate(i)} />
                <button onClick={() => startEdit(i)} data-sound="none" className="glass flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-transform hover:scale-110" style={{ color: "var(--sd-primary)" }} aria-label="Edit service">
                  <Pencil size={14} />
                </button>
                <ConfirmDeleteButton onConfirm={() => remove(i)} />
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  Experience CRUD                                                    */
/* ================================================================== */

interface ExperienceDraft {
  period: string; role: string; company: string; location: string;
  description: string; highlights: string; current: boolean; order: string; active: boolean;
}

export function ExperienceTab() {
  const { settings, saveSection } = useSettings();
  const items = settings.content.experience;
  const [editing, setEditing] = useState<number | "new" | null>(null);
  const [draft, setDraft] = useState<ExperienceDraft>({ period: "", role: "", company: "", location: "", description: "", highlights: "", current: false, order: "0", active: true });
  const [error, setError] = useState<string | null>(null);
  const { status, run } = useSaveState();

  const startNew = () => {
    setDraft({ period: "", role: "", company: "", location: "", description: "", highlights: "", current: false, order: String(items.length), active: true });
    setError(null);
    setEditing("new");
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const startEdit = (i: number) => {
    const it = items[i];
    setDraft({ period: it.period, role: it.role, company: it.company, location: it.location, description: it.description, highlights: it.highlights.join(", "), current: it.current, order: String(it.order), active: it.active });
    setError(null);
    setEditing(i);
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const cancel = () => { setEditing(null); setError(null); };
  const fail = (msg: string) => { setError(msg); playUISound("ui_error", { category: "admin", soft: true }); return false; };

  const save = () => run(async () => {
    if (!draft.role.trim()) return fail("Position is required.");
    if (!draft.company.trim()) return fail("Company is required.");
    const item: ExperienceItem = {
      period: draft.period.trim() || "—",
      role: draft.role.trim(),
      company: draft.company.trim(),
      location: draft.location.trim(),
      description: draft.description.trim(),
      highlights: draft.highlights.split(",").map((t) => t.trim()).filter(Boolean),
      current: draft.current,
      order: Number(draft.order) || 0,
      active: draft.active,
    };
    const next = editing === "new" ? [...items, item] : items.map((it, i) => (i === editing ? item : it));
    const ok = await saveSection("content", { ...settings.content, experience: next });
    if (ok) { toast.success(`Experience entry ${editing === "new" ? "created" : "updated"} successfully`); cancel(); }
    return ok;
  });
  const remove = async (i: number) => {
    const ok = await saveSection("content", { ...settings.content, experience: items.filter((_, idx) => idx !== i) });
    if (ok) { toast.success("Experience entry deleted"); playUISound("ui_delete", { category: "admin", soft: true }); }
  };
  const duplicate = (i: number) => {
    const copy: ExperienceItem = { ...items[i], order: items.length };
    saveSection("content", { ...settings.content, experience: [...items, copy] }).then((ok) => {
      if (ok) toast.success("Entry duplicated — edit and save it");
    });
  };

  return (
    <div className="space-y-4">
      <TabHeader
        title="Experience Timeline"
        subtitle={`${items.length} entr${items.length === 1 ? "y" : "ies"} · add, edit, duplicate or remove`}
        action={editing === null ? <AddButton label="Add Experience" onClick={startNew} /> : undefined}
      />

      {editing !== null && (
        <EditPanel title={editing === "new" ? "New Experience" : "Edit Experience"}>
          <CrudField label="Period / Year" value={draft.period} onChange={(v) => setDraft({ ...draft, period: v })} placeholder="2023 — Present" />
          <CrudField label="Company" value={draft.company} onChange={(v) => setDraft({ ...draft, company: v })} placeholder="Company name" />
          <CrudField label="Position" value={draft.role} onChange={(v) => setDraft({ ...draft, role: v })} placeholder="Job title" />
          <CrudField label="Location" value={draft.location} onChange={(v) => setDraft({ ...draft, location: v })} placeholder="Mumbai, India" />
          <div className="sm:col-span-2">
            <CrudTextarea label="Description" value={draft.description} onChange={(v) => setDraft({ ...draft, description: v })} placeholder="What did you do in this role?" />
          </div>
          <div className="sm:col-span-2">
            <CrudField label="Responsibilities / Highlights (comma separated)" value={draft.highlights} onChange={(v) => setDraft({ ...draft, highlights: v })} placeholder="150+ projects, 98% retention" />
          </div>
          <CrudField label="Sort Order" type="number" value={draft.order} onChange={(v) => setDraft({ ...draft, order: v })} placeholder="0" />
          <div className="grid grid-cols-2 gap-3">
            <CrudCheckbox label="Current" checked={draft.current} onChange={(v) => setDraft({ ...draft, current: v })} />
            <CrudCheckbox label="Active" checked={draft.active} onChange={(v) => setDraft({ ...draft, active: v })} />
          </div>
          <div className="sm:col-span-2">
            <SaveBar status={status} dirty onSave={save} onCancel={cancel}
              label={editing === "new" ? "Save & Publish" : "Save Changes"}
              extra={error ? <span className="text-xs font-bold" style={{ color: "#ef4444" }}>{error}</span> : undefined} />
          </div>
        </EditPanel>
      )}

      {items.length === 0 && editing === null ? (
        <EmptyState icon={CalendarDays} title="No experience entries" text="Add your first timeline entry." />
      ) : (
        <div className="space-y-2.5">
          {items.map((item, i) => (
            <div key={`${item.role}-${i}`} className="glass flex items-center gap-4 rounded-2xl p-3">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-white" style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))", opacity: item.active ? 1 : 0.45 }}>
                <CalendarDays size={16} />
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold" style={{ color: "var(--sd-heading)" }}>
                  {item.role} <span style={{ color: "var(--sd-muted)" }}>· {item.company}</span>
                  {item.current && <span className="ml-2 rounded-full px-2 py-0.5 text-[9px] font-bold" style={{ background: "rgba(6,182,212,0.12)", color: "var(--sd-secondary)" }}>CURRENT</span>}
                </p>
                <p className="truncate text-xs" style={{ color: "var(--sd-muted)" }}>{item.period}{item.location && ` · ${item.location}`}</p>
              </div>
              <DuplicateButton onDuplicate={() => duplicate(i)} />
              <button onClick={() => startEdit(i)} data-sound="none" className="glass flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-transform hover:scale-110" style={{ color: "var(--sd-primary)" }} aria-label="Edit entry">
                <Pencil size={14} />
              </button>
              <ConfirmDeleteButton onConfirm={() => remove(i)} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  Skills CRUD                                                        */
/* ================================================================== */

interface SkillDraft { name: string; note: string; level: number; order: string; active: boolean; }

export function SkillsTab() {
  const { settings, saveSection } = useSettings();
  const items = settings.content.skills;
  const [editing, setEditing] = useState<number | "new" | null>(null);
  const [draft, setDraft] = useState<SkillDraft>({ name: "", note: "", level: 80, order: "0", active: true });
  const [error, setError] = useState<string | null>(null);
  const { status, run } = useSaveState();

  const startNew = () => {
    setDraft({ name: "", note: "", level: 80, order: String(items.length), active: true });
    setError(null);
    setEditing("new");
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const startEdit = (i: number) => {
    const it = items[i];
    setDraft({ name: it.name, note: it.note, level: it.level, order: String(it.order), active: it.active });
    setError(null);
    setEditing(i);
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const cancel = () => { setEditing(null); setError(null); };
  const fail = (msg: string) => { setError(msg); playUISound("ui_error", { category: "admin", soft: true }); return false; };

  const save = () => run(async () => {
    if (!draft.name.trim()) return fail("Tool name is required.");
    const item: SkillItem = {
      name: draft.name.trim(),
      level: Math.min(100, Math.max(0, Math.round(draft.level))),
      note: draft.note.trim(),
      order: Number(draft.order) || 0,
      active: draft.active,
    };
    const next = editing === "new" ? [...items, item] : items.map((it, i) => (i === editing ? item : it));
    const ok = await saveSection("content", { ...settings.content, skills: next });
    if (ok) { toast.success(`Skill ${editing === "new" ? "created" : "updated"} successfully`); cancel(); }
    return ok;
  });
  const remove = async (i: number) => {
    const ok = await saveSection("content", { ...settings.content, skills: items.filter((_, idx) => idx !== i) });
    if (ok) { toast.success("Skill deleted"); playUISound("ui_delete", { category: "admin", soft: true }); }
  };
  const duplicate = (i: number) => {
    const copy: SkillItem = { ...items[i], order: items.length };
    saveSection("content", { ...settings.content, skills: [...items, copy] }).then((ok) => {
      if (ok) toast.success("Skill duplicated — edit and save it");
    });
  };

  return (
    <div className="space-y-4">
      <TabHeader
        title="Skills & Tools"
        subtitle={`${items.length} skill${items.length === 1 ? "" : "s"} · add, edit, duplicate or remove`}
        action={editing === null ? <AddButton label="Add Skill" onClick={startNew} /> : undefined}
      />

      {editing !== null && (
        <EditPanel title={editing === "new" ? "New Skill" : "Edit Skill"}>
          <CrudField label="Tool Name" value={draft.name} onChange={(v) => setDraft({ ...draft, name: v })} placeholder="Photoshop" />
          <CrudField label="Description" value={draft.note} onChange={(v) => setDraft({ ...draft, note: v })} placeholder="Retouching & composites" />
          <div className="sm:col-span-2">
            <div className="flex items-center justify-between">
              <p className={labelCls} style={{ color: "var(--sd-muted)" }}>Skill Percentage</p>
              <span className="font-mono text-xs font-bold" style={{ color: "var(--sd-primary)" }}>{draft.level}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={draft.level}
              onChange={(e) => setDraft({ ...draft, level: Number(e.target.value) })}
              className="mt-2 w-full cursor-pointer appearance-none rounded-full"
              style={{ height: 6, background: `linear-gradient(90deg, var(--sd-primary) ${draft.level}%, rgba(148,163,184,0.3) ${draft.level}%)` }}
            />
          </div>
          <CrudField label="Sort Order" type="number" value={draft.order} onChange={(v) => setDraft({ ...draft, order: v })} placeholder="0" />
          <CrudCheckbox label="Active" checked={draft.active} onChange={(v) => setDraft({ ...draft, active: v })} />
          <div className="sm:col-span-2">
            <SaveBar status={status} dirty onSave={save} onCancel={cancel}
              label={editing === "new" ? "Save & Publish" : "Save Changes"}
              extra={error ? <span className="text-xs font-bold" style={{ color: "#ef4444" }}>{error}</span> : undefined} />
          </div>
        </EditPanel>
      )}

      {items.length === 0 && editing === null ? (
        <EmptyState icon={Pencil} title="No skills yet" text="Add your first skill or tool." />
      ) : (
        <div className="space-y-2.5">
          {items.map((item, i) => (
            <div key={`${item.name}-${i}`} className="glass flex items-center gap-4 rounded-2xl p-3">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-xs font-bold text-white" style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))", opacity: item.active ? 1 : 0.45 }}>
                {item.level}%
              </span>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold" style={{ color: "var(--sd-heading)" }}>{item.name}</p>
                <p className="truncate text-xs" style={{ color: "var(--sd-muted)" }}>{item.note}</p>
              </div>
              <DuplicateButton onDuplicate={() => duplicate(i)} />
              <button onClick={() => startEdit(i)} data-sound="none" className="glass flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-transform hover:scale-110" style={{ color: "var(--sd-primary)" }} aria-label="Edit skill">
                <Pencil size={14} />
              </button>
              <ConfirmDeleteButton onConfirm={() => remove(i)} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  Testimonials CRUD                                                  */
/* ================================================================== */

interface TestimonialDraft { name: string; company: string; photo: string; quote: string; rating: number; order: string; active: boolean; }

export function TestimonialsTab() {
  const { settings, saveSection } = useSettings();
  const items = settings.content.testimonials;
  const [editing, setEditing] = useState<number | "new" | null>(null);
  const [draft, setDraft] = useState<TestimonialDraft>({ name: "", company: "", photo: "", quote: "", rating: 5, order: "0", active: true });
  const [error, setError] = useState<string | null>(null);
  const { status, run } = useSaveState();

  const startNew = () => {
    setDraft({ name: "", company: "", photo: "", quote: "", rating: 5, order: String(items.length), active: true });
    setError(null);
    setEditing("new");
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const startEdit = (i: number) => {
    const it = items[i];
    setDraft({ name: it.name, company: it.company, photo: it.photo, quote: it.quote, rating: it.rating, order: String(it.order), active: it.active });
    setError(null);
    setEditing(i);
    playUISound("ui_open", { category: "admin", soft: true });
  };
  const cancel = () => { setEditing(null); setError(null); };
  const fail = (msg: string) => { setError(msg); playUISound("ui_error", { category: "admin", soft: true }); return false; };

  const save = () => run(async () => {
    if (!draft.name.trim()) return fail("Client name is required.");
    if (!draft.quote.trim()) return fail("Testimonial text is required.");
    const item: TestimonialItem = {
      name: draft.name.trim(),
      company: draft.company.trim(),
      photo: draft.photo.trim(),
      quote: draft.quote.trim(),
      rating: Math.min(5, Math.max(1, Math.round(draft.rating))),
      order: Number(draft.order) || 0,
      active: draft.active,
    };
    const next = editing === "new" ? [...items, item] : items.map((it, i) => (i === editing ? item : it));
    const ok = await saveSection("content", { ...settings.content, testimonials: next });
    if (ok) { toast.success(`Testimonial ${editing === "new" ? "created" : "updated"} successfully`); cancel(); }
    return ok;
  });
  const remove = async (i: number) => {
    const ok = await saveSection("content", { ...settings.content, testimonials: items.filter((_, idx) => idx !== i) });
    if (ok) { toast.success("Testimonial deleted"); playUISound("ui_delete", { category: "admin", soft: true }); }
  };

  return (
    <div className="space-y-4">
      <TabHeader
        title="Testimonials"
        subtitle={`${items.length} testimonial${items.length === 1 ? "" : "s"} · real client feedback only`}
        action={editing === null ? <AddButton label="Add Testimonial" onClick={startNew} /> : undefined}
      />

      {editing !== null && (
        <EditPanel title={editing === "new" ? "New Testimonial" : "Edit Testimonial"}>
          <CrudField label="Client Name" value={draft.name} onChange={(v) => setDraft({ ...draft, name: v })} placeholder="Jane Doe" />
          <CrudField label="Company" value={draft.company} onChange={(v) => setDraft({ ...draft, company: v })} placeholder="Acme Studio" />
          <div className="sm:col-span-2">
            <CrudTextarea label="Testimonial" value={draft.quote} onChange={(v) => setDraft({ ...draft, quote: v })} placeholder="What did the client say?" rows={4} />
          </div>
          <CrudField label="Photo URL (optional)" value={draft.photo} onChange={(v) => setDraft({ ...draft, photo: v })} placeholder="https://... or media library URL" />
          <div>
            <p className={labelCls} style={{ color: "var(--sd-muted)" }}>Photo Upload</p>
            <div className="glass flex items-center gap-3 rounded-xl px-3 py-2.5">
              {draft.photo ? (
                <img src={draft.photo} alt={draft.name} className="h-10 w-10 shrink-0 rounded-full object-cover" />
              ) : (
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-[9px] font-bold" style={{ background: "rgba(37,99,235,0.08)", color: "var(--sd-primary)" }}>
                  IMG
                </span>
              )}
              <label
                className="glass flex cursor-pointer items-center gap-1.5 rounded-full px-4 py-2 text-[11px] font-bold transition-transform hover:-translate-y-0.5"
                style={{ color: "var(--sd-heading)" }}
              >
                {draft.photo ? "Replace Photo" : "Upload Photo"}
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  className="hidden"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    e.target.value = "";
                    if (!file) return;
                    const result = await readImageMeta(file, draft.name || "Client photo");
                    if (!result.ok) {
                      toast.error(result.error);
                      return;
                    }
                    setDraft({ ...draft, photo: result.meta.url });
                    playUISound("ui_upload", { category: "admin", soft: true });
                  }}
                />
              </label>
              {draft.photo && (
                <button
                  type="button"
                  data-sound="none"
                  onClick={() => setDraft({ ...draft, photo: "" })}
                  className="ml-auto flex h-8 w-8 shrink-0 items-center justify-center rounded-lg transition-transform hover:scale-110"
                  style={{ background: "rgba(239,68,68,0.1)", color: "#ef4444" }}
                  aria-label="Remove photo"
                >
                  <Trash2 size={13} />
                </button>
              )}
            </div>
          </div>
          <CrudSelect label="Rating" value={String(draft.rating)} onChange={(v) => setDraft({ ...draft, rating: Number(v) })} options={["5", "4", "3", "2", "1"]} />
          <CrudField label="Sort Order" type="number" value={draft.order} onChange={(v) => setDraft({ ...draft, order: v })} placeholder="0" />
          <CrudCheckbox label="Active" checked={draft.active} onChange={(v) => setDraft({ ...draft, active: v })} />
          <div className="sm:col-span-2">
            <SaveBar status={status} dirty onSave={save} onCancel={cancel}
              label={editing === "new" ? "Save & Publish" : "Save Changes"}
              extra={error ? <span className="text-xs font-bold" style={{ color: "#ef4444" }}>{error}</span> : undefined} />
          </div>
        </EditPanel>
      )}

      {items.length === 0 ? (
        <EmptyState icon={Quote} title="No testimonials yet" text="Add real client feedback — no fake testimonials." />
      ) : (
        <div className="space-y-2.5">
          {items.map((item, i) => (
            <div key={`${item.name}-${i}`} className="glass flex items-center gap-4 rounded-2xl p-3">
              {item.photo ? (
                <img src={item.photo} alt="" className="h-11 w-11 shrink-0 rounded-full object-cover" />
              ) : (
                <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold text-white" style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))", opacity: item.active ? 1 : 0.45 }}>
                  {item.name.charAt(0)}
                </span>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold" style={{ color: "var(--sd-heading)" }}>
                  {item.name} <span style={{ color: "var(--sd-muted)" }}>· {item.company}</span>
                </p>
                <p className="flex items-center gap-1 truncate text-xs" style={{ color: "var(--sd-muted)" }}>
                  {Array.from({ length: item.rating }).map((_, s) => (
                    <Star key={s} size={10} fill="var(--sd-primary)" style={{ color: "var(--sd-primary)" }} />
                  ))}
                  <span className="ml-1 truncate">“{item.quote}”</span>
                </p>
              </div>
              <button onClick={() => startEdit(i)} data-sound="none" className="glass flex h-9 w-9 shrink-0 items-center justify-center rounded-xl transition-transform hover:scale-110" style={{ color: "var(--sd-primary)" }} aria-label="Edit testimonial">
                <Pencil size={14} />
              </button>
              <ConfirmDeleteButton onConfirm={() => remove(i)} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  Enquiries inbox                                                    */
/* ================================================================== */

export function EnquiriesTab() {
  const { settings, saveSection } = useSettings();
  const items = settings.content.enquiries;

  const remove = async (id: string) => {
    const ok = await saveSection("content", { ...settings.content, enquiries: items.filter((e) => e.id !== id) });
    if (ok) { toast.success("Enquiry deleted"); playUISound("ui_delete", { category: "admin", soft: true }); }
  };

  return (
    <div className="space-y-4">
      <TabHeader
        title="Enquiries"
        subtitle={`${items.length} message${items.length === 1 ? "" : "s"} received from the contact form`}
      />
      {items.length === 0 ? (
        <EmptyState icon={Inbox} title="No enquiries yet" text="Messages sent from the website contact form will appear here." />
      ) : (
        <div className="space-y-2.5">
          {items.map((e) => (
            <div key={e.id} className="glass rounded-2xl p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex min-w-0 items-center gap-3">
                  <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-sm font-bold text-white" style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" }}>
                    {e.name.charAt(0).toUpperCase()}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold" style={{ color: "var(--sd-heading)" }}>{e.name}</p>
                    <p className="flex items-center gap-1.5 truncate text-xs" style={{ color: "var(--sd-muted)" }}>
                      <Mail size={11} /> {e.email}
                    </p>
                  </div>
                </div>
                <ConfirmDeleteButton onConfirm={() => remove(e.id)} />
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <span className="rounded-full px-3 py-1 text-[10px] font-bold" style={{ color: "var(--sd-primary)", background: "rgba(37,99,235,0.08)", border: "1px solid rgba(147,197,253,0.5)" }}>
                  {e.projectType}
                </span>
                <span className="flex items-center gap-1 text-[10px] font-semibold" style={{ color: "var(--sd-muted)" }}>
                  <CalendarDays size={11} /> {new Date(e.date).toLocaleString()}
                </span>
              </div>
              <p className="mt-3 rounded-xl px-4 py-3 text-sm leading-relaxed" style={{ color: "var(--sd-body)", background: "rgba(255,255,255,0.7)" }}>
                {e.message}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ================================================================== */
/*  Media Library                                                      */
/* ================================================================== */

const MAX_MEDIA_SIZE = 512 * 1024;

export function MediaTab() {
  const { settings, saveSection } = useSettings();
  const items = settings.content.media;

  const onUpload = (file: File) => {
    if (!file.type.startsWith("image/")) {
      toast.error("Only image files are supported.");
      return;
    }
    if (file.size > MAX_MEDIA_SIZE) {
      toast.error("Image too large — maximum 512 KB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const media: MediaItem = {
        id: `${Date.now()}`,
        name: file.name,
        url: reader.result as string,
        date: new Date().toISOString(),
      };
      saveSection("content", { ...settings.content, media: [media, ...items] }).then((ok) => {
        if (ok) toast.success("Image uploaded to media library");
        else toast.error("Unable to save changes. Please try again.");
      });
    };
    reader.readAsDataURL(file);
  };

  const remove = async (id: string) => {
    const ok = await saveSection("content", { ...settings.content, media: items.filter((m) => m.id !== id) });
    if (ok) { toast.success("Image deleted"); playUISound("ui_delete", { category: "admin", soft: true }); }
  };

  return (
    <div className="space-y-4">
      <TabHeader title="Media Library" subtitle={`${items.length} image${items.length === 1 ? "" : "s"} · upload and copy URLs for your content`} />

      <label
        className="flex cursor-pointer flex-col items-center justify-center rounded-3xl border-2 border-dashed px-6 py-10 transition-colors"
        style={{ borderColor: "rgba(37,99,235,0.4)", background: "rgba(255,255,255,0.6)" }}
      >
        <Upload size={24} style={{ color: "var(--sd-primary)" }} />
        <p className="mt-3 text-sm font-bold" style={{ color: "var(--sd-heading)" }}>Upload Image</p>
        <p className="mt-1 text-xs" style={{ color: "var(--sd-muted)" }}>PNG, JPG, WEBP or SVG — max 512 KB</p>
        <input
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) onUpload(file);
            e.target.value = "";
          }}
        />
      </label>

      {items.length === 0 ? (
        <EmptyState icon={ImageIcon} title="Media library is empty" text="Uploaded images appear here — copy their URLs into portfolio or testimonial forms." />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {items.map((m) => (
            <div key={m.id} className="glass overflow-hidden rounded-2xl">
              <img src={m.url} alt={m.name} className="h-28 w-full object-cover" />
              <div className="p-3">
                <p className="truncate text-xs font-bold" style={{ color: "var(--sd-heading)" }}>{m.name}</p>
                <div className="mt-2 flex items-center gap-1.5">
                  <button
                    type="button"
                    data-sound="none"
                    onClick={() => {
                      navigator.clipboard?.writeText(m.url).then(
                        () => toast.success("Image URL copied to clipboard"),
                        () => toast.error("Unable to copy URL")
                      );
                    }}
                    className="glass flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-[10px] font-bold"
                    style={{ color: "var(--sd-primary)" }}
                  >
                    <Link2 size={12} /> Copy URL
                  </button>
                  <ConfirmDeleteButton onConfirm={() => remove(m.id)} />
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
