import Reveal from "./Reveal";
import SectionHead from "./SectionHead";
import { useInView } from "../lib/hooks";
import { useSettings } from "../lib/settings";
import { Gauge } from "lucide-react";

const R = 52;
const CIRCUMFERENCE = 2 * Math.PI * R;

function SkillRing({ name, level, note, active, delay }: { name: string; level: number; note: string; active: boolean; delay: number }) {
  const offset = CIRCUMFERENCE * (1 - (active ? level : 0) / 100);
  const gradientId = `skill-grad-${name.replace(/\s/g, "")}`;

  return (
    <div className="glass group relative flex flex-col items-center rounded-3xl p-7 text-center transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_24px_55px_-16px_var(--sd-glow-medium)]">
      <span
        className="pointer-events-none absolute inset-x-10 top-0 h-24 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-50"
        style={{ background: "var(--sd-glow-soft)" }}
      />
      <div className="relative h-[132px] w-[132px]">
        <svg width="132" height="132" viewBox="0 0 132 132" className="-rotate-90">
          <defs>
            <linearGradient id={gradientId} x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="var(--sd-primary)" />
              <stop offset="100%" stopColor="var(--sd-secondary)" />
            </linearGradient>
          </defs>
          {/* track */}
          <circle cx="66" cy="66" r={R} fill="none" stroke="rgba(37,99,235,0.10)" strokeWidth="9" />
          {/* progress */}
          <circle
            cx="66"
            cy="66"
            r={R}
            fill="none"
            stroke={`url(#${gradientId})`}
            strokeWidth="9"
            strokeLinecap="round"
            strokeDasharray={CIRCUMFERENCE}
            strokeDashoffset={offset}
            className="skill-ring-circle"
            style={{ transitionDelay: `${delay}ms` }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="stat-number text-3xl font-bold">{active ? level : 0}%</span>
        </div>
        {/* soft glow behind ring */}
        <span
          className="absolute inset-6 -z-10 rounded-full opacity-0 blur-xl transition-opacity duration-700 group-hover:opacity-60"
          style={{ background: "var(--sd-glow-soft)" }}
        />
      </div>
      <h3 className="heading-text mt-5 text-lg font-bold">{name}</h3>
      <p className="mt-1 text-xs font-medium" style={{ color: "var(--sd-muted)" }}>
        {note}
      </p>
    </div>
  );
}

export default function Skills() {
  const { settings } = useSettings();
  const skills = settings.content.skills
    .filter((s) => s.active)
    .sort((a, b) => a.order - b.order);
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.15 });

  return (
    <section id="skills" className="relative scroll-mt-24 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHead
          badge="Creative Arsenal"
          title={
            <>
              Tools I <span className="text-gradient">Command</span>
            </>
          }
          description="Industry-standard design tools and AI copilots — each mastered to near-perfection."
        />

        <div ref={ref} className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {skills.length === 0 ? (
            <div className="glass col-span-full mx-auto max-w-md rounded-3xl px-8 py-12 text-center">
              <Gauge size={28} className="mx-auto" style={{ color: "var(--sd-primary)" }} />
              <p className="heading-text mt-3 text-lg font-bold">Skills coming soon</p>
              <p className="mt-2 text-sm" style={{ color: "var(--sd-muted)" }}>
                The creative toolkit is being updated.
              </p>
            </div>
          ) : (
            skills.map((skill, i) => (
              <Reveal key={`${skill.name}-${i}`} delay={(i % 3) * 110}>
                <SkillRing {...skill} active={inView} delay={i * 140} />
              </Reveal>
            ))
          )}
        </div>
      </div>
    </section>
  );
}
