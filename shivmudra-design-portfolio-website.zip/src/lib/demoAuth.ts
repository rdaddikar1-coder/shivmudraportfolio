/**
 * TEMPORARY DEMO ADMIN — isolated authentication module.
 *
 * Everything demo-related lives in this single file so it can be removed in
 * one step later. To kill the demo login instantly, flip DEMO_ADMIN_ENABLED
 * to false (or delete this file and its two call sites: lib/auth.tsx and
 * components/admin/AdminLoginPage.tsx).
 */

/** Master switch for the temporary demo admin login. */
export const DEMO_ADMIN_ENABLED = true;

export const DEMO_CREDENTIALS = {
  username: "demo@shivmudra.design",
  password: "Demo@12345",
} as const;

/** Demo sessions are deliberately short — 2 hours. */
export const DEMO_SESSION_TTL = 2 * 60 * 60 * 1000;

export function validateDemoLogin(username: string, password: string): boolean {
  if (!DEMO_ADMIN_ENABLED) return false;
  return username === DEMO_CREDENTIALS.username && password === DEMO_CREDENTIALS.password;
}
