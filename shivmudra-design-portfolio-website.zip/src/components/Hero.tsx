import { useRef } from "react";
import { ArrowRight, FolderKanban, Sparkles, Star, ChevronDown } from "lucide-react";
import { useSettings } from "../lib/settings";

const FLOATING_DOTS = [
  { left: "6%", top: "18%", size: 6, delay: "0s", color: "var(--sd-primary)" },
  { left: "12%", top: "62%", size: 4, delay: "-2s", color: "var(--sd-secondary)" },
  { left: "88%", top: "12%", size: 5, delay: "-1s", color: "var(--sd-accent)" },
  { left: "94%", top: "58%", size: 7, delay: "-3s", color: "var(--sd-primary)" },
  { left: "50%", top: "4%", size: 4, delay: "-1.5s", color: "var(--sd-secondary)" },
  { left: "80%", top: "88%", size: 5, delay: "-2.5s", color: "#f472b6" },
];

export default function Hero({ active }: { active: boolean }) {
  const { settings } = useSettings();
  const imgWrapRef = useRef<HTMLDivElement>(null);
  const orbRef = useRef<HTMLDivElement>(null);

  const onMove = (e: React.MouseEvent<HTMLElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = ((e.clientY - rect.top) / rect.height) * 2 - 1;
    imgWrapRef.current?.style.setProperty("--px", x.toFixed(3));
    imgWrapRef.current?.style.setProperty("--py", y.toFixed(3));
    if (orbRef.current) {
      orbRef.current.style.setProperty("--ox", (x * 0.6).toFixed(3));
      orbRef.current.style.setProperty("--oy", (y * 0.5).toFixed(3));
    }
  };

  const onLeave = () => {
    imgWrapRef.current?.style.setProperty("--px", "0");
    imgWrapRef.current?.style.setProperty("--py", "0");
    orbRef.current?.style.setProperty("--ox", "0");
    orbRef.current?.style.setProperty("--oy", "0");
  };

  const fade = (delay: number): React.CSSProperties => ({
    opacity: active ? 1 : 0,
    transform: active ? "translateY(0)" : "translateY(30px)",
    transition: `opacity 0.9s cubic-bezier(0.22,1,0.36,1) ${delay}ms, transform 0.9s cubic-bezier(0.22,1,0.36,1) ${delay}ms`,
  });

  return (
    <section
      id="home"
      className="relative flex min-h-screen items-center overflow-hidden pb-16 pt-28 sm:pt-32"
      onMouseMove={onMove}
      onMouseLeave={onLeave}
    >
      <div className="mx-auto grid w-full max-w-7xl items-center gap-14 px-5 sm:px-8 lg:grid-cols-2 lg:gap-8">
        {/* ---------- LEFT ---------- */}
        <div className="relative z-10 text-center lg:text-left">
          <div style={fade(100)}>
            <span className="section-badge">
              <span
                className="relative flex h-2 w-2"
                style={{ color: "var(--sd-primary)" }}
              >
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full opacity-60"
                  style={{ background: "var(--sd-primary)" }} />
                <span className="relative inline-flex h-2 w-2 rounded-full"
                  style={{ background: "var(--sd-primary)" }} />
              </span>
              Premium Creative Studio
            </span>
          </div>

          <h1
            className="heading-text mt-6 font-bold tracking-tight"
            style={{
              ...fade(220),
              fontSize: "clamp(2.25rem, 2.6vw + 1.6rem, 3.6rem)",
              lineHeight: 1.1,
            }}
          >
            {settings.content.heroTitle}
            <br />
            <span className="text-gradient">{settings.content.heroHighlight}</span>
          </h1>

          <p className="mx-auto mt-6 max-w-xl text-base leading-relaxed sm:text-lg lg:mx-0" style={{ color: "var(--sd-body)", ...fade(340) }}>
            {settings.content.heroSubtitle}
          </p>

          <div className="mt-9 flex flex-wrap items-center justify-center gap-4 lg:justify-start" style={fade(460)}>
            <a href="#contact" className="btn-primary">
              <Sparkles size={17} />
              {settings.content.heroCtaText}
              <ArrowRight size={17} />
            </a>
            <a href="#portfolio" className="btn-glass">
              <FolderKanban size={17} style={{ color: "var(--sd-primary)" }} />
              {settings.content.heroCta2Text}
            </a>
          </div>

          {/* Social proof */}
          <div className="mt-10 flex flex-wrap items-center justify-center gap-x-8 gap-y-4 lg:justify-start" style={fade(580)}>
            <div className="flex items-center gap-2.5">
              <div className="flex -space-x-2.5">
                {["S", "A", "R", "K"].map((ch, i) => (
                  <span
                    key={i}
                    className="flex h-9 w-9 items-center justify-center rounded-full border-2 border-white text-xs font-bold text-white"
                    style={{
                      background: `linear-gradient(135deg, hsl(${217 + i * 18} 80% 55%), hsl(${190 + i * 14} 80% 50%))`,
                      boxShadow: "0 4px 12px rgba(59,130,246,0.25)",
                    }}
                  >
                    {ch}
                  </span>
                ))}
              </div>
              <div className="text-left">
                <div className="flex items-center gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={12} fill="var(--sd-primary)" style={{ color: "var(--sd-primary)" }} />
                  ))}
                </div>
                <p className="text-xs font-medium" style={{ color: "var(--sd-muted)" }}>
                  Trusted by {settings.content.stats.clients}+ clients
                </p>
              </div>
            </div>
            <div className="hidden h-10 w-px sm:block" style={{ background: "rgba(148,163,184,0.3)" }} />
            <div className="text-left">
              <p className="heading-text text-xl font-bold">{settings.content.stats.projects}+</p>
              <p className="text-xs font-medium" style={{ color: "var(--sd-muted)" }}>Projects Delivered</p>
            </div>
          </div>
        </div>

        {/* ---------- RIGHT : Hero image inside galaxy energy field ---------- */}
        <div className="relative z-10 mx-auto w-full max-w-[520px]" style={fade(350)}>
          {/* Galaxy orb behind */}
          <div
            ref={orbRef}
            className="pointer-events-none absolute inset-[-14%]"
            style={{
              transform: "translate3d(calc(var(--ox, 0) * 18px), calc(var(--oy, 0) * 14px), 0)",
              transition: "transform 0.7s cubic-bezier(0.22,1,0.36,1)",
            }}
          >
            <div
              className="anim-glow-pulse absolute inset-[8%] rounded-full"
              style={{
                background:
                  "radial-gradient(circle at 55% 40%, var(--sd-glow-soft) 0%, rgba(6,182,212,0.10) 35%, rgba(139,92,246,0.08) 55%, rgba(255,255,255,0) 72%)",
                filter: "blur(14px)",
              }}
            />
            {/* orbital rings */}
            <div className="ring-dashed anim-spin-slow absolute inset-[2%]" />
            <div className="ring-dashed anim-spin-rev absolute inset-[12%]" style={{ borderColor: "rgba(6,182,212,0.3)" }} />
            <div className="ring-dashed anim-spin-slower absolute inset-[20%]" style={{ borderColor: "rgba(139,92,246,0.28)" }} />
            {/* orbiting dots */}
            <span
              className="absolute left-1/2 top-1/2 h-2.5 w-2.5 rounded-full"
              style={{
                background: "var(--sd-primary)",
                boxShadow: "0 0 12px var(--sd-glow-medium)",
                "--orbit-r": "calc(50% - 6px)",
                animation: "orbit 22s linear infinite",
              } as React.CSSProperties}
            />
            <span
              className="absolute left-1/2 top-1/2 h-2 w-2 rounded-full"
              style={{
                background: "var(--sd-secondary)",
                boxShadow: "0 0 10px rgba(6,182,212,0.6)",
                "--orbit-r": "calc(38% - 5px)",
                animation: "orbit 16s linear infinite reverse",
              } as React.CSSProperties}
            />
            <span
              className="absolute left-1/2 top-1/2 h-1.5 w-1.5 rounded-full"
              style={{
                background: "#f472b6",
                boxShadow: "0 0 8px rgba(244,114,182,0.6)",
                "--orbit-r": "calc(27% - 4px)",
                animation: "orbit 12s linear infinite",
              } as React.CSSProperties}
            />
          </div>

          {/* floating particles */}
          {FLOATING_DOTS.map((d, i) => (
            <span
              key={i}
              className="anim-floaty-soft pointer-events-none absolute z-20 rounded-full"
              style={{
                left: d.left,
                top: d.top,
                width: d.size,
                height: d.size,
                background: d.color,
                boxShadow: `0 0 ${d.size * 3}px ${d.color}`,
                animationDelay: d.delay,
              }}
            />
          ))}

          {/* Hero image card */}
          <div
            ref={imgWrapRef}
            className="relative"
            style={{
              transform: "translate3d(calc(var(--px, 0) * 14px), calc(var(--py, 0) * 10px), 0)",
              transition: "transform 0.6s cubic-bezier(0.22,1,0.36,1)",
            }}
          >
            <div
              className="glass-strong anim-floaty relative overflow-hidden rounded-[2rem] p-2"
              style={{ boxShadow: "0 30px 80px -20px var(--sd-glow-medium), 0 0 0 1px rgba(255,255,255,0.7) inset" }}
            >
              <div className="relative overflow-hidden rounded-[1.6rem]">
                {/* desktop hero image — original ratio preserved */}
                <img
                  src={settings.content.heroImage?.url ?? "/images/hero.jpg"}
                  alt={settings.content.heroImageAlt || settings.content.heroImage?.alt || "Shivmudra Design — creative studio"}
                  className="hidden w-full object-contain sm:block"
                  style={{ height: "auto", maxHeight: 600 }}
                  loading="eager"
                />
                {/* mobile hero image — original ratio preserved */}
                <img
                  src={(settings.content.heroImageMobile ?? settings.content.heroImage)?.url ?? "/images/hero.jpg"}
                  alt={settings.content.heroImageAlt || settings.content.heroImageMobile?.alt || "Shivmudra Design — creative studio"}
                  className="w-full object-contain sm:hidden"
                  style={{ height: "auto", maxHeight: 480 }}
                  loading="eager"
                />
                {/* soft top-light veil for cohesion */}
                <div className="pointer-events-none absolute inset-0"
                  style={{ background: "linear-gradient(200deg, rgba(255,255,255,0.12) 0%, rgba(255,255,255,0) 35%)" }} />
              </div>
            </div>

            {/* floating glass chips */}
            <div
              className="glass anim-floaty absolute -right-3 top-8 z-20 flex items-center gap-2.5 rounded-2xl px-4 py-3 sm:-right-8"
              style={{ animationDelay: "-2s" }}
            >
              <span className="flex h-9 w-9 items-center justify-center rounded-xl text-white"
                style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" }}>
                <Sparkles size={16} />
              </span>
              <div>
                <p className="heading-text text-sm font-bold">Brand · Web · Ads</p>
                <p className="text-[11px]" style={{ color: "var(--sd-muted)" }}>End-to-end creative</p>
              </div>
            </div>

            <div
              className="glass anim-floaty absolute -left-3 bottom-10 z-20 flex items-center gap-2.5 rounded-2xl px-4 py-3 sm:-left-8"
              style={{ animationDelay: "-4.5s" }}
            >
              <span className="flex h-9 w-9 items-center justify-center rounded-xl text-white"
                style={{ background: "linear-gradient(135deg, var(--sd-secondary), var(--sd-accent))" }}>
                <Star size={16} />
              </span>
              <div>
                <p className="heading-text text-sm font-bold">5.0 Rating</p>
                <p className="text-[11px]" style={{ color: "var(--sd-muted)" }}>Client satisfaction</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* scroll indicator */}
      <a
        href="#about"
        className="absolute bottom-6 left-1/2 z-10 hidden -translate-x-1/2 flex-col items-center gap-1.5 sm:flex"
        style={fade(800)}
      >
        <span className="text-[10px] font-semibold uppercase tracking-[0.25em]" style={{ color: "var(--sd-muted)" }}>
          Scroll
        </span>
        <ChevronDown size={18} style={{ color: "var(--sd-primary)", animation: "floaty 2.2s ease-in-out infinite" }} />
      </a>
    </section>
  );
}
