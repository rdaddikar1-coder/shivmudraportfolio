/** Flowing galaxy particles that visually connect sections. */
export default function SectionFlow() {
  return (
    <div className="relative h-16 overflow-hidden sm:h-20" aria-hidden>
      {/* center line */}
      <span
        className="absolute left-1/2 top-0 h-full w-px -translate-x-1/2"
        style={{ background: "linear-gradient(180deg, transparent, rgba(37,99,235,0.28), rgba(6,182,212,0.28), transparent)" }}
      />
      {/* soft nebula glow at the line */}
      <span
        className="absolute left-1/2 top-1/2 h-10 w-10 -translate-x-1/2 -translate-y-1/2 rounded-full blur-xl"
        style={{ background: "var(--sd-glow-soft)", opacity: 0.5 }}
      />
      {/* flowing particles */}
      {[0, 1.2, 2.6, 3.8].map((delay, i) => (
        <span
          key={i}
          className="flow-dot"
          style={{ animationDelay: `${delay}s`, marginTop: `${i * 12}px` }}
        />
      ))}
      {[0.6, 2].map((delay, i) => (
        <span
          key={`s${i}`}
          className="flow-dot"
          style={{
            animationDelay: `${delay}s`,
            animationDuration: "6.5s",
            background: "var(--sd-secondary)",
            marginTop: `${8 + i * 14}px`,
            width: 4,
            height: 4,
          }}
        />
      ))}
    </div>
  );
}
