import type { ReactNode } from "react";
import Reveal from "./Reveal";

interface SectionHeadProps {
  badge: string;
  title: ReactNode;
  description?: string;
  center?: boolean;
}

export default function SectionHead({ badge, title, description, center = true }: SectionHeadProps) {
  return (
    <div className={`mb-14 max-w-2xl ${center ? "mx-auto text-center" : ""}`}>
      <Reveal>
        <span className="section-badge">{badge}</span>
      </Reveal>
      <Reveal delay={120}>
        <h2 className="heading-text mt-5 text-3xl font-bold tracking-tight sm:text-4xl lg:text-[2.6rem] lg:leading-[1.15]">
          {title}
        </h2>
      </Reveal>
      {description && (
        <Reveal delay={220}>
          <p className="mt-4 text-base leading-relaxed sm:text-lg" style={{ color: "var(--sd-body)" }}>
            {description}
          </p>
        </Reveal>
      )}
    </div>
  );
}
