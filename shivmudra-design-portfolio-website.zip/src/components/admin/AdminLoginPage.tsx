import { useState } from "react";
import {
  User,
  Lock,
  Eye,
  EyeOff,
  ShieldCheck,
  Loader2,
  AlertTriangle,
  ArrowLeft,
  KeyRound,
} from "lucide-react";
import { useAuth, takeExpiredUser } from "../../lib/auth";
import { useUISound } from "../../lib/uiSound";
import { DEMO_ADMIN_ENABLED, DEMO_CREDENTIALS } from "../../lib/demoAuth";
import { Zap } from "lucide-react";

export default function AdminLoginPage() {
  const { login } = useAuth();
  const sound = useUISound();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [forgot, setForgot] = useState(false);
  const [expiredUser] = useState(() => takeExpiredUser());

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!username.trim() || !password) {
      setError("Please enter your username and password.");
      sound.error();
      return;
    }
    setLoading(true);
    window.setTimeout(() => {
      const ok = login(username.trim(), password);
      setLoading(false);
      if (!ok) {
        setError("Invalid credentials. Access denied.");
        sound.error();
        return;
      }
      sound.success();
      window.location.replace("#/admin");
    }, 700);
  };

  const inputWrap =
    "glass flex items-center gap-3 rounded-2xl px-4 py-3.5 transition-all duration-300 focus-within:shadow-[0_0_0_3px_var(--sd-glow-soft)]";

  return (
    <div
      data-admin-root
      className="relative flex min-h-screen items-center justify-center overflow-hidden px-5 py-16"
    >
      {/* ambient galaxy orb + rings behind the card */}
      <div
        className="anim-glow-pulse pointer-events-none absolute left-1/2 top-1/2 h-[560px] w-[560px] -translate-x-1/2 -translate-y-1/2 rounded-full"
        style={{
          background:
            "radial-gradient(circle at 50% 45%, var(--sd-glow-soft) 0%, rgba(6,182,212,0.10) 40%, rgba(139,92,246,0.08) 58%, rgba(255,255,255,0) 75%)",
          filter: "blur(10px)",
        }}
      />
      <div
        className="ring-dashed anim-spin-slow pointer-events-none absolute left-1/2 top-1/2 h-[480px] w-[480px] -translate-x-1/2 -translate-y-1/2"
        aria-hidden
      />
      <div
        className="ring-dashed anim-spin-rev pointer-events-none absolute left-1/2 top-1/2 h-[380px] w-[380px] -translate-x-1/2 -translate-y-1/2"
        style={{ borderColor: "rgba(6,182,212,0.3)" }}
        aria-hidden
      />

      {/* login card */}
      <div
        className="glass-strong relative w-full max-w-md overflow-hidden rounded-[2rem] p-8 sm:p-10"
        style={{ boxShadow: "0 30px 80px -20px var(--sd-glow-medium)" }}
      >
        <span
          className="pointer-events-none absolute -right-16 -top-16 h-44 w-44 rounded-full opacity-60 blur-3xl"
          style={{ background: "var(--sd-glow-soft)" }}
        />

        {/* heading */}
        <div className="relative flex flex-col items-center text-center">
          <span
            className="flex h-12 w-12 items-center justify-center rounded-2xl text-white"
            style={{
              background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))",
              boxShadow: "0 12px 30px -8px var(--sd-glow-medium)",
            }}
          >
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M12 2 21 7v10l-9 5-9-5V7l9-5Z" stroke="white" strokeWidth="1.8" strokeLinejoin="round" />
              <path d="M9.5 15.5c-1.5-1-1.5-2.7 0-3.4l5-2.2c1.5-.7 1.5-2.4 0-3.4" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </span>
          <h1 className="heading-text mt-4 text-xl font-bold">Shivmudra Design</h1>
          <p
            className="mt-1.5 flex items-center gap-1.5 text-[11px] font-bold tracking-[0.35em]"
            style={{ color: "var(--sd-primary)" }}
          >
            <ShieldCheck size={12} />
            ADMIN LOGIN
          </p>
        </div>

        {/* session expired notice */}
        {expiredUser && (
          <div
            className="relative mt-6 flex items-center gap-2 rounded-2xl px-4 py-3 text-xs font-semibold"
            style={{
              background: "rgba(245,158,11,0.1)",
              color: "#b45309",
              border: "1px solid rgba(245,158,11,0.35)",
            }}
            role="status"
          >
            <AlertTriangle size={14} className="shrink-0" />
            {expiredUser === "demo"
              ? "Demo session expired. Please login again."
              : "Session expired. Please login again."}
          </div>
        )}

        {/* form */}
        <form onSubmit={onSubmit} noValidate className="relative mt-8 space-y-4">
          <div className={inputWrap}>
            <User size={17} style={{ color: "var(--sd-muted)" }} />
            <input
              type="text"
              placeholder="Email / Username"
              value={username}
              onChange={(e) => {
                setUsername(e.target.value);
                setError(null);
              }}
              autoComplete="username"
              className="w-full bg-transparent text-sm font-medium outline-none placeholder:text-slate-400"
              style={{ color: "var(--sd-heading)" }}
            />
          </div>

          <div className={inputWrap}>
            <Lock size={17} style={{ color: "var(--sd-muted)" }} />
            <input
              type={showPassword ? "text" : "password"}
              placeholder="Password"
              value={password}
              onChange={(e) => {
                setPassword(e.target.value);
                setError(null);
              }}
              autoComplete="current-password"
              className="w-full bg-transparent text-sm font-medium outline-none placeholder:text-slate-400"
              style={{ color: "var(--sd-heading)" }}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="shrink-0 transition-transform hover:scale-110"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? (
                <EyeOff size={16} style={{ color: "var(--sd-muted)" }} />
              ) : (
                <Eye size={16} style={{ color: "var(--sd-muted)" }} />
              )}
            </button>
          </div>

          {error && (
            <div
              className="flex items-center gap-2 rounded-2xl px-4 py-3 text-xs font-semibold"
              style={{
                background: "rgba(239,68,68,0.08)",
                color: "#ef4444",
                border: "1px solid rgba(239,68,68,0.25)",
              }}
              role="alert"
            >
              <AlertTriangle size={14} className="shrink-0" />
              {error}
            </div>
          )}

          <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-70">
            {loading ? (
              <>
                <Loader2 size={17} className="animate-spin" />
                Verifying Access...
              </>
            ) : (
              <>
                <ShieldCheck size={17} />
                Login
              </>
            )}
          </button>
        </form>

        {/* temporary demo access */}
        {DEMO_ADMIN_ENABLED && (
          <div className="relative mt-5">
            <div className="flex items-center gap-3">
              <span className="h-px flex-1" style={{ background: "rgba(191,219,254,0.7)" }} />
              <span className="text-[10px] font-bold tracking-widest" style={{ color: "var(--sd-muted)" }}>
                OR
              </span>
              <span className="h-px flex-1" style={{ background: "rgba(191,219,254,0.7)" }} />
            </div>
            <button
              type="button"
              data-sound="none"
              onClick={() => {
                setUsername(DEMO_CREDENTIALS.username);
                setPassword(DEMO_CREDENTIALS.password);
                setError(null);
                sound.click();
              }}
              className="glass mt-4 flex w-full items-center justify-center gap-2 rounded-full py-3 text-xs font-bold transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[0_12px_30px_-10px_var(--sd-glow-medium)]"
              style={{ color: "var(--sd-heading)" }}
            >
              <Zap size={14} style={{ color: "#f59e0b" }} />
              Use Demo Login
            </button>
            <p
              className="mt-2.5 flex items-center justify-center gap-1.5 text-center text-[10px] font-bold tracking-[0.18em]"
              style={{ color: "#b45309" }}
            >
              <span
                className="h-1.5 w-1.5 rounded-full"
                style={{ background: "#f59e0b", boxShadow: "0 0 8px rgba(245,158,11,0.8)" }}
              />
              TEMPORARY DEMO ACCESS
            </p>
          </div>
        )}

        {/* forgot password */}
        <div className="relative mt-5 text-center">
          <button
            type="button"
            data-sound="none"
            onClick={() => {
              setForgot(!forgot);
              sound.click();
            }}
            className="inline-flex items-center gap-1.5 text-xs font-semibold transition-colors hover:opacity-80"
            style={{ color: "var(--sd-muted)" }}
          >
            <KeyRound size={12} />
            Forgot Password?
          </button>
          {forgot && (
            <p
              className="glass mt-3 rounded-2xl px-4 py-3 text-left text-xs leading-relaxed"
              style={{ color: "var(--sd-body)" }}
            >
              Password recovery is managed by the studio administrator. Contact{" "}
              <span className="font-semibold" style={{ color: "var(--sd-primary)" }}>
                hello@shivmudra.design
              </span>{" "}
              to restore access to your account.
            </p>
          )}
        </div>

        <div className="relative mt-7 flex flex-col items-center gap-3">
          <a
            href="#/"
            className="inline-flex items-center gap-1.5 text-xs font-semibold transition-colors hover:opacity-80"
            style={{ color: "var(--sd-primary)" }}
          >
            <ArrowLeft size={13} />
            Back to Website
          </a>
          <p
            className="text-center text-[10px] font-bold tracking-[0.25em]"
            style={{ color: "var(--sd-muted)" }}
          >
            PROTECTED AREA · AUTHORIZED PERSONNEL ONLY
          </p>
        </div>
      </div>
    </div>
  );
}
