import { useEffect, useMemo, useRef, useState } from "react";
import { FastForward, Volume2, VolumeX } from "lucide-react";
import { usePrefersReducedMotion } from "../lib/hooks";
import { useSettings } from "../lib/settings";
import { soundEngine } from "../lib/sound";

/** Step durations (ms) — the whole boot sequence. */
const STEP_DURATIONS = [750, 850, 1050, 1000, 650, 750, 850, 1150, 850];
const STEP_SOUNDS: Array<Parameters<typeof soundEngine.play>[0] | null> = [
  null,
  "activate",
  "servo",
  "servoDown",
  "lock",
  "impact",
  "beep",
  "chime",
  "whoosh",
];

const BOOT_TEXT = [
  "BOOT SEQUENCE INITIATED",
  "GALAXY ENERGY CORE · FORMING",
  "MECHANICAL COMPONENTS · DEPLOYED",
  "ASSEMBLY IN PROGRESS",
  "LOCK ENGAGED · ALL SYSTEMS NOMINAL",
  "ENERGY PULSE CALIBRATED",
  "HUD ONLINE",
  "SHIVMUDRA DESIGN · READY",
  "WELCOME",
];

interface MechPart {
  cx: number;
  cy: number;
  size: number;
  kind: "arc" | "hex" | "gear" | "ring" | "plate" | "bracket";
}

const MECH_PARTS: MechPart[] = [
  { cx: -170, cy: -130, size: 96, kind: "arc" },
  { cx: 165, cy: -150, size: 72, kind: "hex" },
  { cx: -180, cy: 125, size: 84, kind: "gear" },
  { cx: 175, cy: 130, size: 104, kind: "ring" },
  { cx: -10, cy: -195, size: 64, kind: "plate" },
  { cx: 5, cy: 190, size: 68, kind: "bracket" },
];

function MechSvg({ kind, size }: { kind: MechPart["kind"]; size: number }) {
  const stroke = "var(--sd-primary)";
  const soft = "var(--sd-secondary)";
  switch (kind) {
    case "arc":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <circle cx="50" cy="50" r="42" stroke={stroke} strokeWidth="2.5" strokeDasharray="52 30 14 30" strokeLinecap="round" />
          <circle cx="50" cy="50" r="28" stroke={soft} strokeWidth="1.2" strokeDasharray="8 10" />
          <circle cx="50" cy="8" r="4" fill={stroke} />
        </svg>
      );
    case "hex":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <path d="M50 6 90 28 90 72 50 94 10 72 10 28Z" stroke={stroke} strokeWidth="2.5" strokeLinejoin="round" />
          <path d="M50 22 76 37 76 63 50 78 24 63 24 37Z" stroke={soft} strokeWidth="1.2" />
          <circle cx="50" cy="50" r="5" fill={stroke} />
        </svg>
      );
    case "gear":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <circle cx="50" cy="50" r="40" stroke={stroke} strokeWidth="2.5" strokeDasharray="4 7" />
          <circle cx="50" cy="50" r="26" stroke={soft} strokeWidth="2" />
          <circle cx="50" cy="50" r="8" fill="none" stroke={stroke} strokeWidth="2.5" />
          <circle cx="50" cy="50" r="2.5" fill={stroke} />
        </svg>
      );
    case "ring":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <circle cx="50" cy="50" r="44" stroke={stroke} strokeWidth="1.6" />
          <circle cx="50" cy="50" r="34" stroke={soft} strokeWidth="1.2" strokeDasharray="20 12" />
          <circle cx="50" cy="50" r="16" stroke={stroke} strokeWidth="2.5" />
          <circle cx="50" cy="6" r="3" fill={stroke} />
          <circle cx="94" cy="50" r="3" fill={soft} />
        </svg>
      );
    case "plate":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <rect x="14" y="24" width="72" height="52" rx="8" stroke={stroke} strokeWidth="2.5" />
          <line x1="14" y1="42" x2="86" y2="42" stroke={soft} strokeWidth="1.4" />
          <circle cx="28" cy="33" r="3" fill={soft} />
          <line x1="30" y1="54" x2="70" y2="54" stroke={stroke} strokeWidth="1.6" strokeLinecap="round" />
          <line x1="30" y1="64" x2="58" y2="64" stroke={soft} strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      );
    case "bracket":
      return (
        <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
          <path d="M18 82V34L50 12l32 22v48" stroke={stroke} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
          <path d="M34 82V46l16-11 16 11v36" stroke={soft} strokeWidth="1.4" strokeLinejoin="round" />
          <circle cx="50" cy="60" r="4" fill={stroke} />
        </svg>
      );
  }
}

export default function Intro({ onDone }: { onDone: () => void }) {
  const reduced = usePrefersReducedMotion();
  const { settings, updateSound } = useSettings();
  const [step, setStep] = useState(0);
  const [leaving, setLeaving] = useState(false);
  const doneRef = useRef(false);
  const timers = useRef<number[]>([]);

  /* Random particle positions for the intro galaxy */
  const dots = useMemo(
    () =>
      Array.from({ length: 30 }, () => ({
        left: Math.random() * 100,
        top: Math.random() * 100,
        size: 2 + Math.random() * 4,
        delay: Math.random() * 3,
        dur: 3 + Math.random() * 4,
        color: ["var(--sd-primary)", "var(--sd-secondary)", "var(--sd-accent)", "#f472b6"][
          Math.floor(Math.random() * 4)
        ],
      })),
    []
  );

  const finish = () => {
    if (doneRef.current) return;
    doneRef.current = true;
    setStep(STEP_DURATIONS.length);
    setLeaving(true);
    timers.current.push(window.setTimeout(onDone, 780));
  };

  const skip = () => {
    soundEngine.unlock();
    soundEngine.play("ui_click", { category: null, force: true });
    timers.current.forEach(clearTimeout);
    timers.current = [];
    finish();
  };

  useEffect(() => {
    const scale = reduced ? 0.1 : 1;
    let elapsed = 0;
    STEP_DURATIONS.forEach((dur, i) => {
      elapsed += dur * scale;
      timers.current.push(
        window.setTimeout(() => {
          setStep(i + 1);
          const s = STEP_SOUNDS[i + 1];
          if (s) soundEngine.play(s);
          if (i + 1 === STEP_DURATIONS.length) finish();
        }, elapsed)
      );
    });
    return () => {
      timers.current.forEach(clearTimeout);
      timers.current = [];
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [reduced]);

  /* Unlock audio on first interaction */
  useEffect(() => {
    const unlock = () => soundEngine.unlock();
    window.addEventListener("pointerdown", unlock, { once: true });
    window.addEventListener("keydown", unlock, { once: true });
    return () => {
      window.removeEventListener("pointerdown", unlock);
      window.removeEventListener("keydown", unlock);
    };
  }, []);

  const total = STEP_DURATIONS.length;
  const progress = Math.min(100, Math.round(((step + (leaving ? 1 : 0)) / total) * 100));

  const partStyle = (i: number): React.CSSProperties => {
    const p = MECH_PARTS[i];
    const base: React.CSSProperties = {
      transitionDuration: "0.85s",
      transitionTimingFunction: "cubic-bezier(0.22, 1, 0.36, 1)",
      transitionProperty: "transform, opacity",
    };
    if (step < 2) {
      return { ...base, opacity: 0, transform: `translate(${p.cx}px, ${p.cy * 1.8}px) scale(0.25) rotate(-50deg)` };
    }
    if (step === 2) {
      return {
        ...base,
        opacity: 1,
        transform: `translate(${p.cx}px, ${p.cy}px) scale(1) rotate(0deg)`,
        transitionDelay: `${i * 75}ms`,
      };
    }
    if (step === 3) {
      return {
        ...base,
        opacity: 0.85,
        transform: `translate(0px, 0px) scale(0.42) rotate(${i * 60}deg)`,
        transitionDelay: `${i * 55}ms`,
      };
    }
    return {
      ...base,
      opacity: 0.85,
      transform: `translate(0px, 0px) scale(0.42) rotate(${i * 60 + 120}deg)`,
    };
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden transition-all duration-700 ease-[cubic-bezier(0.22,1,0.36,1)]"
      style={{
        opacity: leaving ? 0 : 1,
        transform: leaving ? "translateY(-5%) scale(1.04)" : "none",
        pointerEvents: leaving ? "none" : "auto",
        background:
          "radial-gradient(900px 600px at 50% 40%, #f4f8ff 0%, #ffffff 55%), linear-gradient(180deg, #ffffff, #f8fbff)",
      }}
    >
      {/* Galaxy particles */}
      {dots.map((d, i) => (
        <span
          key={i}
          className="absolute rounded-full anim-twinkle"
          style={{
            left: `${d.left}%`,
            top: `${d.top}%`,
            width: d.size,
            height: d.size,
            background: d.color,
            boxShadow: `0 0 ${d.size * 3}px ${d.color}`,
            animationDelay: `${d.delay}s`,
            animationDuration: `${d.dur}s`,
            opacity: step >= 1 ? 1 : 0,
            transition: "opacity 1.2s ease",
          }}
        />
      ))}

      {/* Central stage */}
      <div className="relative flex h-[340px] w-[340px] items-center justify-center sm:h-[420px] sm:w-[420px]">
        {/* Galaxy energy core forming (step 1) */}
        <div
          className="absolute inset-0 rounded-full transition-all duration-1000"
          style={{
            opacity: step >= 1 ? 1 : 0,
            transform: step >= 1 ? "scale(1)" : "scale(0.3)",
            background:
              "radial-gradient(circle at 50% 45%, var(--sd-glow-soft) 0%, rgba(255,255,255,0) 60%)",
            filter: "blur(6px)",
          }}
        />

        {/* Energy pulse rings (step 5) */}
        {step >= 5 && (
          <>
            {[0, 1, 2].map((i) => (
              <span
                key={i}
                className="absolute rounded-full border-2"
                style={{
                  inset: "18%",
                  borderColor: "var(--sd-primary)",
                  animation: `ring-expand 1.4s ease-out ${i * 0.35}s both`,
                }}
              />
            ))}
          </>
        )}

        {/* Mechanical components */}
        {MECH_PARTS.map((p, i) => (
          <div
            key={i}
            className="absolute"
            style={partStyle(i)}
          >
            <div className={step >= 3 ? "anim-spin-slow" : ""} style={{ animationDuration: step >= 3 ? "24s" : "46s" }}>
              <div
                style={
                  step >= 4
                    ? { animation: `lock-snap 0.55s cubic-bezier(0.34, 1.56, 0.64, 1) ${i * 60}ms both` }
                    : undefined
                }
              >
                <MechSvg kind={p.kind} size={p.size} />
              </div>
            </div>
          </div>
        ))}

        {/* Core assembly */}
        <div
          className="absolute flex items-center justify-center transition-all duration-700"
          style={{
            opacity: step >= 1 ? 1 : 0,
            transform: step >= 4 ? "scale(1.12)" : step >= 1 ? "scale(1)" : "scale(0.4)",
          }}
        >
          <div className="anim-spin-slow absolute h-[150px] w-[150px] rounded-full border border-dashed sm:h-[190px] sm:w-[190px]"
            style={{ borderColor: "rgba(37,99,235,0.4)" }} />
          <div className="anim-spin-rev absolute h-[110px] w-[110px] rounded-full border-2 sm:h-[140px] sm:w-[140px]"
            style={{ borderColor: "rgba(6,182,212,0.35)", borderStyle: "dotted" }} />
          <div
            className="anim-glow-pulse absolute h-[70px] w-[70px] rounded-full sm:h-[90px] sm:w-[90px]"
            style={{
              background: "radial-gradient(circle at 40% 35%, #ffffff 0%, var(--sd-glow-soft) 60%, rgba(255,255,255,0) 75%)",
              boxShadow: "0 0 60px var(--sd-glow-soft)",
            }}
          />
        </div>

        {/* HUD activation (step 6) */}
        {step >= 6 && (
          <div className="absolute inset-[-12%]">
            {/* corner brackets */}
            {[
              "left-0 top-0 border-l-2 border-t-2 rounded-tl-xl",
              "right-0 top-0 border-r-2 border-t-2 rounded-tr-xl",
              "bottom-0 left-0 border-b-2 border-l-2 rounded-bl-xl",
              "bottom-0 right-0 border-b-2 border-r-2 rounded-br-xl",
            ].map((cls, i) => (
              <span
                key={i}
                className={`absolute h-12 w-12 sm:h-16 sm:w-16 ${cls}`}
                style={{ borderColor: "var(--sd-primary)", animation: `hud-corner 1.6s ease-in-out ${i * 0.2}s infinite` }}
              />
            ))}
            {/* scanline */}
            <span
              className="absolute inset-x-4 h-[2px]"
              style={{
                background: "linear-gradient(90deg, transparent, var(--sd-primary), var(--sd-secondary), transparent)",
                boxShadow: "0 0 12px var(--sd-glow-medium)",
                animation: "scanline 2.2s ease-in-out infinite",
              }}
            />
            {/* data readouts */}
            <span className="absolute left-2 top-16 font-mono text-[10px] tracking-widest sm:text-xs"
              style={{ color: "var(--sd-muted)", animation: "blink-hud 2s ease-in-out infinite" }}>
              SYS.CHECK ···· OK
            </span>
            <span className="absolute right-2 top-16 font-mono text-[10px] tracking-widest sm:text-xs"
              style={{ color: "var(--sd-muted)", animation: "blink-hud 2s ease-in-out 0.4s infinite" }}>
              PWR ···· 98%
            </span>
            <span className="absolute bottom-16 left-2 font-mono text-[10px] tracking-widest sm:text-xs"
              style={{ color: "var(--sd-muted)", animation: "blink-hud 2s ease-in-out 0.8s infinite" }}>
              HUD ···· ACTIVE
            </span>
            <span className="absolute bottom-16 right-2 font-mono text-[10px] tracking-widest sm:text-xs"
              style={{ color: "var(--sd-muted)", animation: "blink-hud 2s ease-in-out 1.2s infinite" }}>
              LINK ···· STABLE
            </span>
          </div>
        )}

        {/* Logo (step 7) */}
        {step >= 7 && (
          <div className="absolute inset-x-0 -bottom-16 flex flex-col items-center sm:-bottom-20">
            <div className="flex items-baseline justify-center gap-1 overflow-hidden">
              <span className="heading-text text-4xl font-bold tracking-tight sm:text-6xl">
                {"Shivmudra".split("").map((ch, i) => (
                  <span key={i} style={{ animation: `letter-in 0.7s cubic-bezier(0.22,1,0.36,1) ${i * 55}ms both`, display: "inline-block" }}>
                    {ch}
                  </span>
                ))}
              </span>
            </div>
            <div
              className="mt-1 flex items-center gap-3 sm:mt-2"
              style={{ animation: "letter-in 0.8s ease 0.7s both" }}
            >
              <span className="h-px w-8 sm:w-14" style={{ background: "linear-gradient(90deg, transparent, var(--sd-primary))" }} />
              <span className="text-sm font-semibold tracking-[0.55em] sm:text-lg" style={{ color: "var(--sd-primary)" }}>
                DESIGN
              </span>
              <span className="h-px w-8 sm:w-14" style={{ background: "linear-gradient(90deg, var(--sd-primary), transparent)" }} />
            </div>
            <span
              className="mt-3 font-mono text-[10px] tracking-[0.3em] sm:text-xs"
              style={{ color: "var(--sd-muted)", animation: "letter-in 0.8s ease 0.95s both" }}
            >
              CREATIVE · TECHNOLOGY · DESIGN
            </span>
          </div>
        )}
      </div>

      {/* Boot readout */}
      <div className="absolute bottom-20 left-6 sm:bottom-24 sm:left-10">
        <p className="font-mono text-[10px] tracking-widest sm:text-xs" style={{ color: "var(--sd-muted)" }}>
          {BOOT_TEXT[Math.min(step, BOOT_TEXT.length - 1)]}
        </p>
        <div className="mt-2 h-[3px] w-40 overflow-hidden rounded-full sm:w-56" style={{ background: "rgba(37,99,235,0.12)" }}>
          <div
            className="h-full rounded-full transition-all duration-500"
            style={{
              width: `${progress}%`,
              background: "linear-gradient(90deg, var(--sd-primary), var(--sd-secondary))",
              boxShadow: "0 0 10px var(--sd-glow-medium)",
            }}
          />
        </div>
      </div>

      {/* Controls */}
      <div className="absolute right-5 top-5 flex items-center gap-2 sm:right-8 sm:top-8">
        <button
          onClick={() => {
            soundEngine.unlock();
            const next = !settings.sound.enabled;
            updateSound("enabled", next);
            soundEngine.setEnabled(next);
            if (next) soundEngine.play("ui_toggle_on", { category: null });
          }}
          data-sound="none"
          className="glass flex h-10 w-10 items-center justify-center rounded-full transition-transform hover:scale-110"
          aria-label="Toggle sound"
        >
          {settings.sound.enabled ? (
            <Volume2 size={17} style={{ color: "var(--sd-primary)" }} />
          ) : (
            <VolumeX size={17} style={{ color: "var(--sd-muted)" }} />
          )}
        </button>
        <button
          onClick={skip}
          data-sound="none"
          className="glass flex items-center gap-2 rounded-full px-4 py-2 text-xs font-semibold tracking-wide transition-transform hover:scale-105"
          style={{ color: "var(--sd-heading)" }}
        >
          <FastForward size={14} style={{ color: "var(--sd-primary)" }} />
          SKIP INTRO
        </button>
      </div>
    </div>
  );
}
