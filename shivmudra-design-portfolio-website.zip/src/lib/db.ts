/**
 * Persistence layer for the Shivmudra Design CMS.
 *
 * In this static deployment the "database" is the browser's localStorage —
 * writes are REAL and VERIFIED (data survives refresh and is shared live by
 * the public website). All admin saves flow through this async API so a
 * production backend can be connected later by replacing only this module
 * with real REST calls (POST /api/settings etc.).
 */

export const SETTINGS_KEY = "shivmudra-settings-v1";

export interface SaveResult {
  ok: boolean;
  error?: string;
}

const delay = (ms: number) => new Promise((resolve) => window.setTimeout(resolve, ms));

/**
 * Verified async write of the full settings document.
 * This is the single source of truth for "did the data actually persist?" —
 * if the write fails (e.g. storage quota), the admin sees an error and the
 * live state is NOT committed.
 */
export async function persistSettings(next: unknown): Promise<SaveResult> {
  // Simulated network round-trip — swap for a real fetch() in production.
  await delay(300 + Math.random() * 220);
  try {
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(next));
    return { ok: true };
  } catch {
    return { ok: false, error: "Unable to save changes. Please try again." };
  }
}
