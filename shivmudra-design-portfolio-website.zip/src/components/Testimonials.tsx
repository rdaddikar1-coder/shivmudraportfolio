import { Quote, Star } from "lucide-react";
import Reveal from "./Reveal";
import SectionHead from "./SectionHead";
import { useSettings } from "../lib/settings";

export default function Testimonials() {
  const { settings } = useSettings();
  const items = settings.content.testimonials
    .filter((t) => t.active)
    .sort((a, b) => a.order - b.order);

  if (items.length === 0) return null;

  return (
    <section id="testimonials" className="relative scroll-mt-24 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHead
          badge="Testimonials"
          title={
            <>
              What Clients Say Across the <span className="text-gradient">Galaxy</span>
            </>
          }
          description="Real feedback from real projects — no fake testimonials."
        />

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {items.map((t, i) => (
            <Reveal key={`${t.name}-${i}`} delay={(i % 3) * 120}>
              <article
                className="glass group relative h-full cursor-pointer overflow-hidden rounded-3xl p-7 transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_26px_60px_-16px_var(--sd-glow-medium)]"
                data-sound="ui_card"
              >
                <span
                  className="pointer-events-none absolute -right-8 -top-8 opacity-10 transition-opacity duration-500 group-hover:opacity-25"
                  style={{ color: "var(--sd-primary)" }}
                >
                  <Quote size={90} />
                </span>

                <div className="flex items-center gap-1">
                  {Array.from({ length: t.rating }).map((_, s) => (
                    <Star key={s} size={14} fill="var(--sd-primary)" style={{ color: "var(--sd-primary)" }} />
                  ))}
                </div>

                <p className="mt-4 text-sm leading-relaxed" style={{ color: "var(--sd-body)" }}>
                  “{t.quote}”
                </p>

                <div className="mt-6 flex items-center gap-3">
                  {t.photo ? (
                    <img
                      src={t.photo}
                      alt={t.name}
                      className="h-11 w-11 rounded-full object-cover"
                      style={{ boxShadow: "0 6px 18px -4px var(--sd-glow-medium)" }}
                    />
                  ) : (
                    <span
                      className="flex h-11 w-11 items-center justify-center rounded-full text-sm font-bold text-white"
                      style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" }}
                    >
                      {t.name.charAt(0).toUpperCase()}
                    </span>
                  )}
                  <div>
                    <p className="text-sm font-bold" style={{ color: "var(--sd-heading)" }}>{t.name}</p>
                    {t.company && (
                      <p className="text-xs font-semibold" style={{ color: "var(--sd-muted)" }}>{t.company}</p>
                    )}
                  </div>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
