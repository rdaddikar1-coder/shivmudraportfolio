import { useMemo } from "react";
import { soundEngine, type SoundCategory, type UISoundName } from "./sound";

/**
 * Global UI interaction sound system.
 * `playUISound` is safe to call from anywhere — it reads the live
 * admin configuration (enable, volume, category gates, throttling).
 */
export function playUISound(
  name: UISoundName,
  opts?: { category?: SoundCategory | null; soft?: boolean; force?: boolean; gainMul?: number }
): boolean {
  return soundEngine.play(name, opts);
}

/** Reusable hook — the single entry point all interactive components share. */
export function useUISound() {
  return useMemo(
    () => ({
      play: playUISound,
      nav: () => playUISound("ui_click", { category: "navigation" }),
      click: () => playUISound("ui_click", { category: "button" }),
      open: () => playUISound("ui_open", { category: "button" }),
      close: () => playUISound("ui_close", { category: "button" }),
      success: () => playUISound("ui_success", { category: "success" }),
      error: () => playUISound("ui_error", { category: "error" }),
      toggle: () => playUISound("ui_toggle", { category: "button" }),
      upload: () => playUISound("ui_upload", { category: "success" }),
      power: () => playUISound("ui_power", { category: "button" }),
      preview: (name: UISoundName) => soundEngine.preview(name),
    }),
    []
  );
}
