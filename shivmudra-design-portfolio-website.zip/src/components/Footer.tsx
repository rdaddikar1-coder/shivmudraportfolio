import { Heart, Mail } from "lucide-react";
import { InstagramIcon, WhatsAppIcon } from "./icons";
import { NAV_LINKS } from "../data/content";
import { useSettings } from "../lib/settings";

export default function Footer() {
  const { settings } = useSettings();
  const year = new Date().getFullYear();
  const social = settings.content.social;

  const socialEntries: { label: string; href: string; icon?: React.ReactNode }[] = [];
  if (social.instagram) socialEntries.push({ label: "Instagram", href: social.instagram, icon: <InstagramIcon size={14} /> });
  if (social.whatsapp) socialEntries.push({ label: "WhatsApp", href: social.whatsapp, icon: <WhatsAppIcon size={14} /> });
  if (social.facebook) socialEntries.push({ label: "Facebook", href: social.facebook });
  if (social.youtube) socialEntries.push({ label: "YouTube", href: social.youtube });
  if (social.linkedin) socialEntries.push({ label: "LinkedIn", href: social.linkedin });
  if (social.behance) socialEntries.push({ label: "Behance", href: social.behance });
  if (social.dribbble) socialEntries.push({ label: "Dribbble", href: social.dribbble });

  return (
    <footer
      className="relative border-t py-12"
      style={{ borderColor: "rgba(191,219,254,0.55)", background: "rgba(255,255,255,0.55)", backdropFilter: "blur(12px)" }}
    >
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-8 px-5 sm:px-8">
        {/* logo */}
        <a href="#home" className="flex items-center gap-3">
          <span
            className="flex h-9 w-9 items-center justify-center rounded-xl text-white"
            style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" }}
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
              <path d="M12 2 21 7v10l-9 5-9-5V7l9-5Z" stroke="white" strokeWidth="1.8" strokeLinejoin="round" />
              <path d="M9.5 15.5c-1.5-1-1.5-2.7 0-3.4l5-2.2c1.5-.7 1.5-2.4 0-3.4" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
            </svg>
          </span>
          <span className="heading-text text-lg font-bold">
            {settings.content.website.name.split(" ")[0]}{" "}
            <span className="text-gradient">{settings.content.website.name.split(" ").slice(1).join(" ")}</span>
          </span>
        </a>

        {/* links */}
        <nav className="flex flex-wrap items-center justify-center gap-x-7 gap-y-3">
          {NAV_LINKS.map((link) => (
            <a key={link.href} href={link.href} className="nav-link">
              {link.label}
            </a>
          ))}
        </nav>

        {/* socials */}
        <div className="flex flex-wrap items-center justify-center gap-2.5">
          {socialEntries.map((s) => (
            <a
              key={s.label}
              href={s.href}
              target="_blank"
              rel="noopener noreferrer"
              aria-label={s.label}
              className="glass flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold transition-all duration-300 hover:-translate-y-1"
              style={{ color: s.icon ? "var(--sd-primary)" : "var(--sd-heading)" }}
            >
              {s.icon}
              {s.label}
            </a>
          ))}
          <a
            href={`mailto:${settings.content.email}`}
            aria-label="Email"
            className="glass flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold transition-all duration-300 hover:-translate-y-1"
            style={{ color: "var(--sd-primary)" }}
          >
            <Mail size={14} />
            Email
          </a>
        </div>

        <div className="h-px w-full max-w-md" style={{ background: "linear-gradient(90deg, transparent, rgba(37,99,235,0.35), transparent)" }} />

        <p className="flex flex-wrap items-center justify-center gap-1.5 text-center text-xs font-medium" style={{ color: "var(--sd-muted)" }}>
          © {year} {settings.content.website.copyright}. Crafted with
          <Heart size={12} fill="var(--sd-primary)" style={{ color: "var(--sd-primary)" }} />
          inside a white galaxy.
        </p>
      </div>
    </footer>
  );
}
