/**
 * Tiny pub-sub connecting sound events to visual effects:
 *  - click ripples (blue energy pulse at the pointer)
 *  - galaxy background reaction (brief glow boost)
 * Kept dependency-free so both canvas and React layers can use it.
 */

export interface Ripple {
  id: number;
  x: number;
  y: number;
  big: boolean;
}

type RippleListener = (r: Ripple) => void;
type VoidListener = () => void;

const rippleListeners = new Set<RippleListener>();
const galaxyListeners = new Set<VoidListener>();
let rippleId = 0;

export function spawnRipple(x: number, y: number, big = false): void {
  const ripple: Ripple = { id: ++rippleId, x, y, big };
  rippleListeners.forEach((l) => l(ripple));
}

export function subscribeRipples(cb: RippleListener): () => void {
  rippleListeners.add(cb);
  return () => {
    rippleListeners.delete(cb);
  };
}

/** Notify the galaxy background that an important interaction just happened. */
export function pulseGalaxy(): void {
  galaxyListeners.forEach((l) => l());
}

export function subscribeGalaxy(cb: VoidListener): () => void {
  galaxyListeners.add(cb);
  return () => {
    galaxyListeners.delete(cb);
  };
}
