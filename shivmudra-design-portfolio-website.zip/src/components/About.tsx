import { useRef } from "react";
import { Check, ArrowRight, Award, Zap, HeartHandshake } from "lucide-react";
import Reveal from "./Reveal";
import { useSettings } from "../lib/settings";

const BRAND = "Shivmudra Design";

const HIGHLIGHTS = [
  { icon: Award, text: "Award-level craft across every deliverable" },
  { icon: Zap, text: "Fast turnarounds without compromising quality" },
  { icon: HeartHandshake, text: "Long-term creative partnerships, not one-off gigs" },
];

const ABOUT_DOTS = [
  { left: "10%", top: "12%", size: 5, delay: "0s", color: "var(--sd-primary)" },
  { left: "85%", top: "8%", size: 4, delay: "-1.8s", color: "var(--sd-secondary)" },
  { left: "92%", top: "70%", size: 6, delay: "-0.9s", color: "var(--sd-accent)" },
  { left: "6%", top: "78%", size: 4, delay: "-2.6s", color: "#f472b6" },
  { left: "50%", top: "95%", size: 5, delay: "-3.4s", color: "var(--sd-primary)" },
];

export default function About() {
  const { settings } = useSettings();
  const wrapRef = useRef<HTMLDivElement>(null);

  const onMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = ((e.clientY - rect.top) / rect.height) * 2 - 1;
    wrapRef.current?.style.setProperty("--ax", (x * 0.5).toFixed(3));
    wrapRef.current?.style.setProperty("--ay", (y * 0.4).toFixed(3));
  };

  return (
    <section id="about" className="relative scroll-mt-24 py-24 sm:py-32">
      <div className="mx-auto grid max-w-7xl items-center gap-16 px-5 sm:px-8 lg:grid-cols-[1fr_1.15fr]">
        {/* -------- LEFT : portrait with galaxy orb -------- */}
        <Reveal variant="left" className="relative mx-auto w-full max-w-[440px]">
          <div className="relative" onMouseMove={onMove} onMouseLeave={() => wrapRef.current?.style.setProperty("--ax", "0")}>
            <div
              ref={wrapRef}
              className="relative"
              style={{
                transform: "translate3d(calc(var(--ax, 0) * 12px), calc(var(--ay, 0) * 9px), 0)",
                transition: "transform 0.6s cubic-bezier(0.22,1,0.36,1)",
              }}
            >
              {/* galaxy orb */}
              <div
                className="anim-glow-pulse pointer-events-none absolute inset-[-16%] rounded-full"
                style={{
                  background:
                    "radial-gradient(circle at 50% 45%, var(--sd-glow-soft) 0%, rgba(6,182,212,0.10) 40%, rgba(139,92,246,0.08) 58%, rgba(255,255,255,0) 75%)",
                  filter: "blur(12px)",
                }}
              />
              {/* light rings */}
              <div className="ring-dashed anim-spin-slow pointer-events-none absolute inset-[-4%]" />
              <div className="ring-dashed anim-spin-rev pointer-events-none absolute inset-[6%]" style={{ borderColor: "rgba(6,182,212,0.3)" }} />

              {/* floating particles */}
              {ABOUT_DOTS.map((d, i) => (
                <span
                  key={i}
                  className="anim-floaty-soft pointer-events-none absolute z-20 rounded-full"
                  style={{
                    left: d.left,
                    top: d.top,
                    width: d.size,
                    height: d.size,
                    background: d.color,
                    boxShadow: `0 0 ${d.size * 3}px ${d.color}`,
                    animationDelay: d.delay,
                  }}
                />
              ))}

              {/* portrait */}
              <div
                className="glass-strong anim-floaty relative mx-auto max-w-[360px] overflow-hidden rounded-[2rem] p-2"
                style={{ boxShadow: "0 26px 70px -18px var(--sd-glow-medium)" }}
              >
                <img
                  src={settings.content.aboutImage?.url ?? "/images/about.jpg"}
                  alt={settings.content.aboutImage?.alt || "Founder of Shivmudra Design"}
                  className="w-full rounded-[1.6rem] object-contain"
                  style={{ height: "auto", maxHeight: 460 }}
                  loading="lazy"
                />
              </div>

              {/* experience chip */}
              <div className="glass anim-floaty absolute -bottom-5 left-1/2 z-20 flex -translate-x-1/2 items-center gap-3 rounded-2xl px-5 py-3.5" style={{ animationDelay: "-3s" }}>
                <span className="stat-number text-3xl font-bold">{settings.content.stats.years}+</span>
                <span className="text-left text-xs font-semibold leading-tight" style={{ color: "var(--sd-muted)" }}>
                  Years of
                  <br />
                  Creative Work
                </span>
              </div>
            </div>
          </div>
        </Reveal>

        {/* -------- RIGHT : copy -------- */}
        <div>
          <Reveal>
            <span className="section-badge">About Me</span>
          </Reveal>
          <Reveal delay={120}>
            <h2 className="heading-text mt-5 text-3xl font-bold tracking-tight sm:text-4xl lg:text-[2.6rem] lg:leading-[1.15]">
              {settings.content.aboutTitle.includes(BRAND) ? (
                <>
                  {settings.content.aboutTitle.split(BRAND)[0]}
                  <span className="text-gradient">{BRAND}</span>
                  {settings.content.aboutTitle.split(BRAND)[1]}
                </>
              ) : (
                settings.content.aboutTitle
              )}
            </h2>
          </Reveal>
          <Reveal delay={220}>
            <p className="mt-5 leading-relaxed sm:text-lg" style={{ color: "var(--sd-body)" }}>
              {settings.content.aboutText1}
            </p>
          </Reveal>
          <Reveal delay={300}>
            <p className="mt-4 leading-relaxed" style={{ color: "var(--sd-body)" }}>
              {settings.content.aboutText2}
            </p>
          </Reveal>

          <div className="mt-8 space-y-4">
            {HIGHLIGHTS.map((h, i) => (
              <Reveal key={i} delay={380 + i * 110}>
                <div className="glass flex items-center gap-4 rounded-2xl px-5 py-4 transition-transform duration-500 hover:-translate-y-1">
                  <span
                    className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-white"
                    style={{
                      background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))",
                      boxShadow: "0 8px 20px -6px var(--sd-glow-medium)",
                    }}
                  >
                    <h.icon size={19} />
                  </span>
                  <p className="text-sm font-semibold sm:text-base" style={{ color: "var(--sd-heading)" }}>
                    {h.text}
                  </p>
                </div>
              </Reveal>
            ))}
          </div>

          <Reveal delay={720}>
            <div className="mt-9 flex flex-wrap items-center gap-6">
              <a href="#contact" className="btn-primary">
                Work With Me
                <ArrowRight size={17} />
              </a>
              <div>
                <p className="heading-text text-lg font-bold" style={{ fontFamily: "var(--font-display)" }}>
                  Shivmudra
                </p>
                <p className="flex items-center gap-1.5 text-xs font-medium" style={{ color: "var(--sd-muted)" }}>
                  <Check size={12} style={{ color: "var(--sd-primary)" }} />
                  Founder & Creative Director
                </p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
