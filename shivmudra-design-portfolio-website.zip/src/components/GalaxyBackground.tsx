import { useEffect, useRef } from "react";
import { useSettings } from "../lib/settings";
import { useMouseParallax, usePrefersReducedMotion } from "../lib/hooks";
import { subscribeGalaxy } from "../lib/clickFx";

/* ------------------------------------------------------------------ */
/*  Pre-rendered glow sprites (fast drawImage instead of gradients)   */
/* ------------------------------------------------------------------ */

const spriteCache = new Map<string, HTMLCanvasElement>();

function makeGlowSprite(color: string): HTMLCanvasElement {
  const cached = spriteCache.get("glow-" + color);
  if (cached) return cached;
  const size = 64;
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  const ctx = c.getContext("2d")!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, color);
  g.addColorStop(0.25, color);
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.globalAlpha = 0.85;
  ctx.fillStyle = g;
  ctx.beginPath();
  ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
  ctx.fill();
  spriteCache.set("glow-" + color, c);
  return c;
}

function makeNebulaSprite(color: string): HTMLCanvasElement {
  const key = "neb-" + color;
  const cached = spriteCache.get(key);
  if (cached) return cached;
  const size = 512;
  const c = document.createElement("canvas");
  c.width = size;
  c.height = size;
  const ctx = c.getContext("2d")!;
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  g.addColorStop(0, color);
  g.addColorStop(0.4, color);
  g.addColorStop(1, "rgba(255,255,255,0)");
  ctx.fillStyle = g;
  ctx.fillRect(0, 0, size, size);
  spriteCache.set(key, c);
  return c;
}

/* ------------------------------------------------------------------ */
/*  Types                                                             */
/* ------------------------------------------------------------------ */

interface Particle {
  x: number; // normalized 0..1
  y: number;
  depth: number; // 0.25..1 — parallax & scroll depth
  size: number;
  colorIndex: number;
  twinklePhase: number;
  twinkleSpeed: number;
  driftX: number; // px / second
  driftY: number;
  isStar: boolean;
  rotation: number;
}

interface TrailPoint {
  x: number;
  y: number;
}

interface Trail {
  anchorX: number;
  anchorY: number;
  ax: number;
  ay: number;
  fx: number;
  fy: number;
  phase: number;
  color: string;
  width: number;
  history: TrailPoint[];
}

interface Nebula {
  x: number;
  y: number;
  radius: number;
  color: string;
  driftAmp: number;
  driftSpeed: number;
  phase: number;
}

const DENSITY_MUL: Record<string, number> = { low: 0.55, medium: 1, high: 1.45 };
const SPEED_MUL: Record<string, number> = { slow: 0.55, medium: 1, fast: 1.7 };
const GLOW_MUL: Record<string, number> = { low: 0.55, medium: 1, high: 1.5 };

function hexToRgba(hex: string, alpha: number): string {
  const h = hex.replace("#", "");
  const full = h.length === 3 ? h.split("").map((ch) => ch + ch).join("") : h;
  const r = parseInt(full.slice(0, 2), 16);
  const g = parseInt(full.slice(2, 4), 16);
  const b = parseInt(full.slice(4, 6), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

/* ------------------------------------------------------------------ */
/*  Galaxy background                                                 */
/* ------------------------------------------------------------------ */

export default function GalaxyBackground() {
  const { settings } = useSettings();
  const reduced = usePrefersReducedMotion();
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mouseRef = useMouseParallax(settings.galaxy.parallax && !reduced);

  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  /* Galaxy reacts subtly to important UI interactions (sound-synced pulse) */
  const boostRef = useRef(1);
  useEffect(() => subscribeGalaxy(() => { boostRef.current = 1.8; }), []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const dpr = Math.min(2, window.devicePixelRatio || 1);
    let w = 0;
    let h = 0;
    let particles: Particle[] = [];
    let trails: Trail[] = [];
    let nebulas: Nebula[] = [];
    let raf = 0;
    let running = true;

    const isMobile = () => window.innerWidth < 640;
    const isTablet = () => window.innerWidth >= 640 && window.innerWidth < 1024;

    const desiredCount = () => {
      const s = settingsRef.current;
      if (!s.galaxy.particles) return 0;
      const base = isMobile() ? 22 : isTablet() ? 44 : 70;
      let count = base * (DENSITY_MUL[s.galaxy.density] ?? 1);
      if (s.themeStyle === "minimal") count *= 0.4;
      return Math.round(Math.min(110, Math.max(10, count)));
    };

    const makeParticle = (): Particle => ({
      x: Math.random(),
      y: Math.random(),
      depth: 0.25 + Math.random() * 0.75,
      size: 0.6 + Math.random() * 1.8,
      colorIndex: Math.floor(Math.random() * 4),
      twinklePhase: Math.random() * Math.PI * 2,
      twinkleSpeed: 0.4 + Math.random() * 1.1,
      driftX: (Math.random() - 0.5) * 7,
      driftY: (Math.random() - 0.5) * 7,
      isStar: Math.random() < 0.16,
      rotation: Math.random() * Math.PI,
    });

    const syncParticles = () => {
      const want = desiredCount();
      if (particles.length < want) {
        while (particles.length < want) particles.push(makeParticle());
      } else if (particles.length > want) {
        particles = particles.slice(0, want);
      }
    };

    const buildScene = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      canvas.style.width = w + "px";
      canvas.style.height = h + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      const s = settingsRef.current;
      const { primary, secondary, accent } = s.colors;

      // Nebula clouds
      const nebColors = [primary, secondary, accent, "#f472b6"];
      const nebCount = isMobile() ? 3 : 4;
      nebulas = Array.from({ length: nebCount }, (_, i) => ({
        x: [0.18, 0.82, 0.5, 0.32][i % 4] + (Math.random() - 0.5) * 0.12,
        y: [0.25, 0.4, 0.75, 0.68][i % 4] + (Math.random() - 0.5) * 0.12,
        radius: (isMobile() ? 0.3 : 0.42) * Math.min(w, h) + Math.random() * 120,
        color: nebColors[i % nebColors.length],
        driftAmp: 30 + Math.random() * 50,
        driftSpeed: 0.045 + Math.random() * 0.05,
        phase: Math.random() * Math.PI * 2,
      }));

      // Light trails (flowing energy streams)
      const trailCount = isMobile() ? 3 : 6;
      trails = Array.from({ length: trailCount }, (_, i) => ({
        anchorX: 0.15 + (i / trailCount) * 0.75,
        anchorY: 0.2 + Math.random() * 0.65,
        ax: 60 + Math.random() * 110,
        ay: 30 + Math.random() * 60,
        fx: 0.1 + Math.random() * 0.12,
        fy: 0.12 + Math.random() * 0.15,
        phase: Math.random() * Math.PI * 2,
        color: i % 2 === 0 ? primary : secondary,
        width: 0.9 + Math.random() * 0.9,
        history: [],
      }));

      syncParticles();
    };

    buildScene();

    const onResize = () => buildScene();
    window.addEventListener("resize", onResize);

    const onVisibility = () => {
      if (document.hidden) {
        running = false;
        cancelAnimationFrame(raf);
      } else if (!reduced) {
        running = true;
        raf = requestAnimationFrame(frame);
      }
    };
    document.addEventListener("visibilitychange", onVisibility);

    const drawFrame = (t: number) => {
      const s = settingsRef.current;
      const { particles: particlesOn, movement, glow } = s.galaxy;
      const speedMul = SPEED_MUL[movement] ?? 1;
      // Interaction boost (decays back to 1 each frame)
      const boost = boostRef.current;
      boostRef.current += (1 - boost) * 0.035;
      const glowMul = (GLOW_MUL[glow] ?? 1) * boost;
      const minimal = s.themeStyle === "minimal";
      const mouse = mouseRef.current;
      const scrollY = window.scrollY;
      const time = t / 1000;

      ctx.clearRect(0, 0, w, h);

      /* ---- Nebula clouds ---- */
      if (!minimal) {
        for (const n of nebulas) {
          const nx =
            n.x * w +
            Math.sin(time * n.driftSpeed + n.phase) * n.driftAmp +
            mouse.x * 10;
          const ny =
            n.y * h +
            Math.cos(time * n.driftSpeed * 0.8 + n.phase) * n.driftAmp * 0.7 +
            mouse.y * 8 +
            ((scrollY * 0.03) % h);
          const sprite = makeNebulaSprite(n.color);
          ctx.globalAlpha = 0.055 * glowMul * (isMobile() ? 0.8 : 1);
          const r = n.radius * (1 + Math.sin(time * 0.05 + n.phase) * 0.06);
          ctx.drawImage(sprite, nx - r, ny - r, r * 2, r * 2);
        }
        ctx.globalAlpha = 1;
      }

      /* ---- Orbital rings ---- */
      if (!minimal && !isMobile()) {
        const cx = w * 0.5 + mouse.x * 8;
        const cy = h * 0.44 + mouse.y * 6 - ((scrollY * 0.04) % (h * 1.4));
        const ringCount = 3;
        for (let i = 0; i < ringCount; i++) {
          const rx = w * (0.2 + i * 0.09);
          const ry = rx * (0.3 + i * 0.05);
          const rot = time * (0.02 + i * 0.012) * speedMul + i * 0.9;
          ctx.save();
          ctx.translate(cx, cy);
          ctx.rotate(rot);
          ctx.scale(1, ry / rx);
          ctx.beginPath();
          ctx.arc(0, 0, rx, 0, Math.PI * 2);
          ctx.setLineDash([10, 16]);
          ctx.lineWidth = 1;
          ctx.strokeStyle = hexToRgba(i % 2 === 0 ? s.colors.primary : s.colors.secondary, 0.1 * glowMul);
          ctx.stroke();
          ctx.setLineDash([]);
          ctx.restore();

          // orbiting dots on the ring
          for (let d = 0; d < 2; d++) {
            const a = time * (0.09 + i * 0.03) * speedMul + d * Math.PI + i;
            const ox = cx + Math.cos(a) * rx * Math.cos(rot) - Math.sin(a) * rx * (ry / rx) * Math.sin(rot);
            const oy = cy + Math.cos(a) * rx * Math.sin(rot) + Math.sin(a) * rx * (ry / rx) * Math.cos(rot);
            const sprite = makeGlowSprite(d === 0 ? s.colors.primary : s.colors.accent);
            ctx.globalAlpha = 0.5 * glowMul;
            ctx.drawImage(sprite, ox - 7, oy - 7, 14, 14);
            ctx.globalAlpha = 1;
          }
        }
      }

      /* ---- Flowing light trails ---- */
      if (!minimal) {
        for (const tr of trails) {
          const headX =
            tr.anchorX * w + Math.sin(time * tr.fx * Math.PI + tr.phase) * tr.ax + mouse.x * 12;
          const headY =
            tr.anchorY * h +
            Math.cos(time * tr.fy * Math.PI + tr.phase * 1.3) * tr.ay +
            mouse.y * 10 -
            ((scrollY * 0.05) % h);
          tr.history.push({ x: headX, y: headY });
          if (tr.history.length > 22) tr.history.shift();

          const hist = tr.history;
          for (let i = 1; i < hist.length; i++) {
            const f = i / hist.length;
            ctx.beginPath();
            ctx.moveTo(hist[i - 1].x, hist[i - 1].y);
            ctx.lineTo(hist[i].x, hist[i].y);
            ctx.strokeStyle = hexToRgba(tr.color, 0.16 * f * glowMul);
            ctx.lineWidth = tr.width * f;
            ctx.lineCap = "round";
            ctx.stroke();
          }
          // glowing head
          if (hist.length > 0) {
            const sprite = makeGlowSprite(tr.color);
            ctx.globalAlpha = 0.5 * glowMul;
            ctx.drawImage(sprite, headX - 6, headY - 6, 12, 12);
            ctx.globalAlpha = 1;
          }
        }
      }

      /* ---- Particles & stars ---- */
      if (particlesOn) {
        for (const p of particles) {
          const twinkle = 0.55 + 0.45 * Math.sin(time * p.twinkleSpeed + p.twinklePhase);
          const px =
            (p.x * w + time * p.driftX * speedMul + mouse.x * p.depth * 14 + w) % w;
          const py =
            (((p.y * h - scrollY * 0.08 * p.depth + time * p.driftY * speedMul) % h) + h) % h +
            0; // wrapped below
          const wrappedY = ((py % h) + h) % h;

          if (p.isStar) {
            // 4-point sparkle star
            ctx.save();
            ctx.translate(px, wrappedY);
            ctx.rotate(p.rotation + time * 0.05);
            const len = 4 + p.size * 3;
            ctx.strokeStyle = hexToRgba(s.colors.primary, 0.35 * twinkle * glowMul);
            ctx.lineWidth = 0.8;
            ctx.beginPath();
            ctx.moveTo(-len, 0);
            ctx.lineTo(len, 0);
            ctx.moveTo(0, -len);
            ctx.lineTo(0, len);
            ctx.stroke();
            ctx.fillStyle = hexToRgba("#ffffff", 0.9 * twinkle);
            ctx.beginPath();
            ctx.arc(0, 0, 1.1, 0, Math.PI * 2);
            ctx.fill();
            ctx.restore();
          } else {
            const colors = [s.colors.particle, s.colors.primary, s.colors.secondary, s.colors.accent];
            const col = colors[p.colorIndex % colors.length];
            const sprite = makeGlowSprite(col);
            const size = (3 + p.size * 4) * (0.7 + p.depth * 0.5);
            ctx.globalAlpha = Math.min(1, (0.25 + p.depth * 0.5) * twinkle * glowMul);
            ctx.drawImage(sprite, px - size / 2, wrappedY - size / 2, size, size);
            ctx.globalAlpha = 1;
          }
        }
      }
    };

    function frame(t: number) {
      if (!running) return;
      // live-apply admin settings
      if (settingsRef.current.galaxy.particles) syncParticles();
      drawFrame(t);
      raf = requestAnimationFrame(frame);
    }

    if (reduced) {
      drawFrame(4000);
    } else {
      raf = requestAnimationFrame(frame);
    }

    return () => {
      running = false;
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", onResize);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [reduced, mouseRef, settings.themeStyle, settings.galaxy.background]);

  if (!settings.galaxy.background) return null;

  // White Gradient theme: pure CSS animated aurora, no canvas
  if (settings.themeStyle === "gradient") {
    return (
      <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden" aria-hidden>
        <div
          className="anim-floaty-soft absolute -top-32 left-[8%] h-[34rem] w-[34rem] rounded-full opacity-60 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(37,99,235,0.16), transparent 65%)" }}
        />
        <div
          className="anim-floaty absolute right-[4%] top-[30%] h-[30rem] w-[30rem] rounded-full opacity-60 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(6,182,212,0.14), transparent 65%)", animationDelay: "-3s" }}
        />
        <div
          className="anim-floaty-soft absolute bottom-[6%] left-[30%] h-[26rem] w-[26rem] rounded-full opacity-50 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(139,92,246,0.12), transparent 65%)", animationDelay: "-6s" }}
        />
      </div>
    );
  }

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none fixed inset-0 z-0"
      aria-hidden
    />
  );
}
