import { Briefcase } from "lucide-react";
import Reveal from "./Reveal";
import SectionHead from "./SectionHead";
import { useScrollProgress } from "../lib/hooks";
import { useSettings } from "../lib/settings";
import { cn } from "../utils/cn";

export default function Experience() {
  const { settings } = useSettings();
  const experience = settings.content.experience
    .filter((e) => e.active)
    .sort((a, b) => a.order - b.order);
  const { ref, progress } = useScrollProgress<HTMLDivElement>();

  return (
    <section id="experience" className="relative scroll-mt-24 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-5 sm:px-8">
        <SectionHead
          badge="Career Path"
          title={
            <>
              The Journey <span className="text-gradient">So Far</span>
            </>
          }
          description="A timeline of growth — every role adding a new star to the constellation of skills."
        />

        <div ref={ref} className="relative mx-auto max-w-4xl">
          {/* track */}
          <div className="timeline-track absolute bottom-2 left-[19px] top-2 w-[2px] rounded-full sm:left-1/2 sm:-translate-x-1/2" />
          {/* progress fill */}
          <div
            className="timeline-progress absolute left-[19px] top-2 w-[2px] rounded-full sm:left-1/2 sm:-translate-x-1/2"
            style={{ height: `${Math.round(progress * 100)}%` }}
          />

          <div className="space-y-10 sm:space-y-14">
            {experience.map((exp, i) => {
              const leftSide = i % 2 === 0;
              return (
                <div key={exp.role} className="relative grid gap-4 pl-14 sm:grid-cols-2 sm:gap-0 sm:pl-0">
                  {/* glowing node */}
                  <span
                    className={cn(
                      "timeline-dot absolute left-[13px] top-7 z-10 h-3.5 w-3.5 rounded-full sm:left-1/2 sm:-translate-x-1/2",
                      "after:absolute after:inset-0 after:rounded-full after:content-['']"
                    )}
                    style={{
                      boxShadow: `0 0 0 5px rgba(37,99,235,0.12), 0 0 0 12px rgba(37,99,235,0.05), 0 0 18px var(--sd-glow-medium)`,
                    }}
                  />
                  {/* pulse ring on node */}
                  <span
                    className="absolute left-[13px] top-7 z-10 h-3.5 w-3.5 rounded-full sm:left-1/2 sm:-translate-x-1/2"
                    style={{
                      background: "var(--sd-primary)",
                      opacity: 0.5,
                      animation: `pulse-ring 2.6s ease-out ${i * 0.4}s infinite`,
                    }}
                  />

                  {/* spacer for alternating layout */}
                  <div className={cn("hidden sm:block", leftSide ? "sm:order-1" : "sm:order-2")} />

                  {/* card */}
                  <Reveal
                    variant={leftSide ? "left" : "right"}
                    delay={i * 80}
                    className={cn(leftSide ? "sm:order-2 sm:pl-12" : "sm:order-1 sm:pr-12")}
                  >
                    <article className="glass group relative overflow-hidden rounded-3xl p-6 transition-all duration-500 hover:-translate-y-1.5 hover:shadow-[0_24px_55px_-16px_var(--sd-glow-medium)] sm:p-7">
                      {/* glow corner */}
                      <span
                        className="pointer-events-none absolute -right-10 -top-10 h-28 w-28 rounded-full opacity-0 blur-2xl transition-opacity duration-500 group-hover:opacity-60"
                        style={{ background: "var(--sd-glow-soft)" }}
                      />
                      <div className="flex items-center gap-3">
                        <span
                          className="flex h-10 w-10 items-center justify-center rounded-xl text-white"
                          style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" }}
                        >
                          <Briefcase size={17} />
                        </span>
                        <span
                          className="rounded-full px-3.5 py-1.5 text-[11px] font-bold tracking-wide"
                          style={{
                            color: "var(--sd-primary)",
                            background: "rgba(37,99,235,0.08)",
                            border: "1px solid rgba(147,197,253,0.5)",
                          }}
                        >
                          {exp.period}
                        </span>
                      </div>

                      <h3 className="heading-text mt-4 text-xl font-bold">{exp.role}</h3>
                      <p className="mt-1 text-sm font-semibold" style={{ color: "var(--sd-primary)" }}>
                        {exp.company}
                      </p>
                      <p className="mt-3 text-sm leading-relaxed" style={{ color: "var(--sd-body)" }}>
                        {exp.description}
                      </p>

                      <div className="mt-4 flex flex-wrap gap-2">
                        {exp.highlights.map((h) => (
                          <span
                            key={h}
                            className="rounded-full px-3 py-1 text-[11px] font-semibold"
                            style={{
                              color: "var(--sd-heading)",
                              background: "rgba(255,255,255,0.75)",
                              border: "1px solid rgba(191,219,254,0.7)",
                            }}
                          >
                            {h}
                          </span>
                        ))}
                      </div>
                    </article>
                  </Reveal>
                </div>
              );
            })}
          </div>

          {/* end star */}
          <div className="relative mt-10 flex justify-start pl-14 sm:justify-center sm:pl-0">
            <span
              className="flex h-12 w-12 items-center justify-center rounded-full text-white"
              style={{
                background: "linear-gradient(135deg, var(--sd-primary), var(--sd-accent))",
                boxShadow: "0 0 30px var(--sd-glow-medium)",
              }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path
                  d="M12 2l2.4 6.2L21 10l-5.4 3.4L17 20l-5-3.4L7 20l1.4-6.6L3 10l6.6-1.8L12 2z"
                  fill="white"
                />
              </svg>
            </span>
          </div>
        </div>
      </div>
    </section>
  );
}
