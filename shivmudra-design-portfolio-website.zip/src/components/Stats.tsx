import { Rocket, CalendarRange, Wand2, Users, type LucideIcon } from "lucide-react";
import Reveal from "./Reveal";
import { useCountUp, useInView } from "../lib/hooks";
import { useSettings } from "../lib/settings";
import { STATS_META } from "../data/content";

const STAT_ICONS: Record<string, LucideIcon> = {
  projects: Rocket,
  years: CalendarRange,
  creative: Wand2,
  clients: Users,
};

function StatCard({ icon: Icon, value, label, suffix, active, delay }: {
  icon: LucideIcon;
  value: number;
  label: string;
  suffix: string;
  active: boolean;
  delay: number;
}) {
  const display = useCountUp(value, active, 2200);
  return (
    <div className="glass group relative overflow-hidden rounded-3xl p-7 text-center transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_26px_60px_-16px_var(--sd-glow-medium)]">
      {/* corner glow */}
      <span
        className="pointer-events-none absolute -right-12 -top-12 h-32 w-32 rounded-full opacity-40 blur-2xl transition-opacity duration-500 group-hover:opacity-90"
        style={{ background: "var(--sd-glow-soft)" }}
      />
      <span
        className="pointer-events-none absolute inset-x-8 bottom-0 h-px opacity-60"
        style={{ background: "linear-gradient(90deg, transparent, var(--sd-primary), transparent)" }}
      />
      <span
        className="relative mx-auto flex h-12 w-12 items-center justify-center rounded-2xl text-white transition-transform duration-500 group-hover:scale-110 group-hover:rotate-6"
        style={{
          background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))",
          boxShadow: "0 10px 24px -8px var(--sd-glow-medium)",
        }}
      >
        <Icon size={20} />
      </span>
      <p className="stat-number relative mt-4 text-4xl font-bold sm:text-[2.6rem]" style={{ transitionDelay: `${delay}ms` }}>
        {display}
        {suffix}
      </p>
      <p className="relative mt-1.5 text-sm font-semibold" style={{ color: "var(--sd-muted)" }}>
        {label}
      </p>
    </div>
  );
}

export default function Stats() {
  const { settings } = useSettings();
  const { ref, inView } = useInView<HTMLDivElement>({ threshold: 0.25 });

  return (
    <section id="stats" className="relative py-16 sm:py-20">
      <div ref={ref} className="mx-auto max-w-7xl px-5 sm:px-8">
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {STATS_META.map((meta, i) => (
            <Reveal key={meta.key} delay={i * 110}>
              <StatCard
                icon={STAT_ICONS[meta.key]}
                value={settings.content.stats[meta.key]}
                label={meta.label}
                suffix={meta.suffix}
                active={inView}
                delay={i * 100}
              />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
