import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { DEMO_SESSION_TTL, validateDemoLogin } from "./demoAuth";

/**
 * Admin authentication for Shivmudra Design.
 *
 * Two account types:
 *  - "admin" : the studio administrator (24h session)
 *  - "demo"  : temporary demo account (2h session, see lib/demoAuth.ts)
 *
 * NOTE: This is a front-end demo of a proper auth flow (session validation,
 * protected routes, redirect guards, per-type expiry). In a real deployment
 * the credential check MUST happen on a server — client-side code can never
 * hold secrets. No sensitive data, API keys or environment variables are
 * exposed here; the admin area only manages local theme preferences and
 * demo content.
 */

const SESSION_KEY = "shivmudra-admin-session";
const SESSION_TTL = 24 * 60 * 60 * 1000; // 24 hours (production admin)
const EXPIRED_KEY = "shivmudra-admin-expired"; // sessionStorage flag for the login page
const CREDS_KEY = "shivmudra-admin-credentials"; // stored admin credentials

const DEFAULT_ADMIN = { username: "admin", password: "shivmudra" };

interface AdminCredentials {
  username: string;
  password: string;
}

/** Read the (mutable) admin credentials — defaults on first run. */
export function getAdminCredentials(): AdminCredentials {
  try {
    const raw = localStorage.getItem(CREDS_KEY);
    if (!raw) return { ...DEFAULT_ADMIN };
    const parsed = JSON.parse(raw) as Partial<AdminCredentials>;
    return {
      username: typeof parsed.username === "string" && parsed.username ? parsed.username : DEFAULT_ADMIN.username,
      password: typeof parsed.password === "string" && parsed.password ? parsed.password : DEFAULT_ADMIN.password,
    };
  } catch {
    return { ...DEFAULT_ADMIN };
  }
}

/** Persist new admin credentials (Admin Profile tab). */
export function updateAdminCredentials(username: string, password: string): boolean {
  if (username.trim().length < 3 || password.length < 6) return false;
  try {
    localStorage.setItem(CREDS_KEY, JSON.stringify({ username: username.trim(), password }));
    return true;
  } catch {
    return false;
  }
}

export type AdminUserType = "admin" | "demo";

interface AdminSession {
  token: string;
  user: AdminUserType;
  expiresAt: number;
}

interface AuthContextValue {
  isAdmin: boolean;
  isDemo: boolean;
  login: (username: string, password: string) => boolean;
  logout: () => void;
}

const AuthContext = createContext<AuthContextValue | null>(null);

function readSession(): AdminSession | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const session = JSON.parse(raw) as AdminSession;
    if (!session?.token || typeof session.expiresAt !== "number") return null;
    if (Date.now() > session.expiresAt) {
      localStorage.removeItem(SESSION_KEY);
      // Tell the login page *who* expired so it can show the right message.
      try {
        sessionStorage.setItem(EXPIRED_KEY, session.user);
      } catch {
        /* ignore */
      }
      return null;
    }
    return session;
  } catch {
    return null;
  }
}

/** One-shot read of the expiry flag (used by the login page). */
export function takeExpiredUser(): AdminUserType | null {
  try {
    const v = sessionStorage.getItem(EXPIRED_KEY);
    sessionStorage.removeItem(EXPIRED_KEY);
    return v === "demo" || v === "admin" ? v : null;
  } catch {
    return null;
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<AdminSession | null>(() => readSession());

  /* Re-validate every minute so sessions expire gracefully mid-visit */
  useEffect(() => {
    const id = window.setInterval(() => setSession(readSession()), 60_000);
    return () => window.clearInterval(id);
  }, []);

  const login = useCallback((username: string, password: string) => {
    // Demo validation — replace with a server-side auth endpoint in production.
    let user: AdminUserType | null = null;
    const creds = getAdminCredentials();
    if (username === creds.username && password === creds.password) {
      user = "admin";
    } else if (validateDemoLogin(username, password)) {
      user = "demo";
    }
    if (!user) return false;

    const ttl = user === "demo" ? DEMO_SESSION_TTL : SESSION_TTL;
    const next: AdminSession = {
      token:
        typeof crypto !== "undefined" && "randomUUID" in crypto
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      user,
      expiresAt: Date.now() + ttl,
    };
    try {
      localStorage.setItem(SESSION_KEY, JSON.stringify(next));
    } catch {
      /* ignore */
    }
    setSession(next);
    return true;
  }, []);

  const logout = useCallback(() => {
    try {
      localStorage.removeItem(SESSION_KEY);
    } catch {
      /* ignore */
    }
    setSession(null);
  }, []);

  const value = useMemo(
    () => ({
      isAdmin: session !== null,
      isDemo: session?.user === "demo",
      login,
      logout,
    }),
    [session, login, logout]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside AuthProvider");
  return ctx;
}
