import type { ImageMeta } from "../data/content";

/**
 * Image upload pipeline with AUTOMATIC dimension + aspect-ratio detection.
 * The original ratio is detected once at upload time and stored as metadata,
 * so the public website can always render the image without cropping.
 */

const MAX_IMAGE_SIZE = 2 * 1024 * 1024; // 2 MB
const ACCEPTED_TYPES = ["image/jpeg", "image/png", "image/webp"];

export type ImageMetaResult =
  | { ok: true; meta: ImageMeta }
  | { ok: false; error: string };

export function readImageMeta(file: File, altFallback: string): Promise<ImageMetaResult> {
  if (!ACCEPTED_TYPES.includes(file.type)) {
    return Promise.resolve({
      ok: false,
      error: "Unsupported format. Use JPG, JPEG, PNG or WEBP.",
    });
  }
  if (file.size > MAX_IMAGE_SIZE) {
    return Promise.resolve({ ok: false, error: "Image too large — maximum 2 MB." });
  }

  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => {
      const url = reader.result as string;
      const probe = new window.Image();
      probe.onload = () => {
        const width = probe.naturalWidth;
        const height = probe.naturalHeight;
        resolve({
          ok: true,
          meta: {
            url,
            width,
            height,
            aspectRatio: height > 0 ? width / height : 0,
            fileType: file.type,
            fileSize: file.size,
            alt: altFallback,
            createdAt: new Date().toISOString(),
          },
        });
      };
      probe.onerror = () => resolve({ ok: false, error: "Could not read image dimensions." });
      probe.src = url;
    };
    reader.onerror = () => resolve({ ok: false, error: "Could not read the file." });
    reader.readAsDataURL(file);
  });
}

/** Human label for an aspect ratio ("4:5", "16:9", or "1080 × 1350"). */
export function ratioLabel(width: number, height: number): string {
  if (!width || !height) return "Original ratio";
  const r = width / height;
  const known: Array<[number, string]> = [
    [1, "1:1"],
    [4 / 5, "4:5"],
    [5 / 4, "5:4"],
    [16 / 9, "16:9"],
    [9 / 16, "9:16"],
    [3 / 4, "3:4"],
    [4 / 3, "4:3"],
    [2 / 3, "2:3"],
    [3 / 2, "3:2"],
    [21 / 9, "21:9"],
  ];
  for (const [value, label] of known) {
    if (Math.abs(r - value) < 0.02) return label;
  }
  return `${width} × ${height}`;
}

export function formatFileSize(bytes: number): string {
  if (!bytes) return "—";
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${Math.round(bytes / 1024)} KB`;
}
