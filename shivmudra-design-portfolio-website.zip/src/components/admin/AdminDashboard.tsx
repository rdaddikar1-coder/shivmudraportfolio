import { useEffect, useState } from "react";
import {
  Palette,
  Sparkles,
  FileText,
  Volume2,
  RotateCcw,
  Check,
  Play,
  Upload,
  Trash2,
  Music,
  AlertTriangle,
  Globe,
  LogOut,
  ChevronDown,
  LayoutDashboard,
  FolderKanban,
  FolderTree,
  Wrench,
  Briefcase,
  Gauge,
  Inbox,
  Images,
  Quote,
  Search,
  Share2,
  UserCircle,
  type LucideIcon,
} from "lucide-react";
import {
  useSettings,
  type Density,
  type GlowLevel,
  type Speed,
  type ThemeStyle,
  type SiteSettings,
} from "../../lib/settings";
import { soundEngine, type CustomSound, type UISoundName } from "../../lib/sound";
import { playUISound } from "../../lib/uiSound";
import { useAuth, getAdminCredentials, updateAdminCredentials } from "../../lib/auth";
import { toast } from "../../lib/toast";
import { cn } from "../../utils/cn";
import { PortfolioTab, CategoriesTab, ServicesTab, ExperienceTab, SkillsTab, TestimonialsTab, EnquiriesTab } from "./AdminCrud";
import { ImageUploader } from "./AdminPortfolio";
import { ImageManagementTab } from "./AdminImages";
import {
  ToastHost,
  SaveBar,
  useSaveState,
  useDraft,
  UnsavedDialog,
  hasUnsavedChanges,
  discardAllUnsaved,
} from "./ui";

/* ================================================================== */
/*  Draft-bound form controls                                          */
/* ================================================================== */

const labelCls = "mb-1.5 text-[11px] font-bold uppercase tracking-widest";
const inputCls =
  "glass w-full rounded-xl px-4 py-2.5 text-sm font-medium outline-none transition-shadow focus:shadow-[0_0_0_3px_var(--sd-glow-soft)]";

function DField({ label, value, onChange, placeholder, type = "text" }: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <p className={labelCls} style={{ color: "var(--sd-muted)" }}>{label}</p>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder} className={inputCls} style={{ color: "var(--sd-heading)" }} />
    </div>
  );
}

function DTextarea({ label, value, onChange, rows = 3 }: { label: string; value: string; onChange: (v: string) => void; rows?: number }) {
  return (
    <div className="sm:col-span-2">
      <p className={labelCls} style={{ color: "var(--sd-muted)" }}>{label}</p>
      <textarea value={value} onChange={(e) => onChange(e.target.value)} rows={rows} className={`${inputCls} resize-none`} style={{ color: "var(--sd-heading)" }} />
    </div>
  );
}

function DToggle({ label, hint, checked, onChange }: { label: string; hint?: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      data-sound="none"
      onClick={() => {
        playUISound(!checked ? "ui_toggle_on" : "ui_toggle_off", { category: "admin", soft: true });
        onChange(!checked);
      }}
      className="glass flex w-full items-center justify-between gap-3 rounded-2xl px-4 py-3 text-left"
    >
      <span>
        <span className="block text-sm font-semibold" style={{ color: "var(--sd-heading)" }}>{label}</span>
        {hint && <span className="block text-[11px]" style={{ color: "var(--sd-muted)" }}>{hint}</span>}
      </span>
      <span
        className="relative h-6 w-11 shrink-0 rounded-full transition-colors duration-300"
        style={{
          background: checked ? "linear-gradient(90deg, var(--sd-primary), var(--sd-secondary))" : "rgba(148,163,184,0.3)",
          boxShadow: checked ? "0 0 12px var(--sd-glow-soft)" : "none",
        }}
      >
        <span className="absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-all duration-300" style={{ left: checked ? "22px" : "2px" }} />
      </span>
    </button>
  );
}

function DSegmented<T extends string>({ label, value, onChange, options }: {
  label: string;
  value: T;
  onChange: (v: T) => void;
  options: { value: T; label: string }[];
}) {
  return (
    <div>
      <p className={labelCls} style={{ color: "var(--sd-muted)" }}>{label}</p>
      <div className="glass flex gap-1 rounded-2xl p-1">
        {options.map((opt) => (
          <button
            key={opt.value}
            type="button"
            onClick={() => onChange(opt.value)}
            className={cn("flex-1 rounded-xl px-2 py-2 text-xs font-semibold transition-all duration-300", value === opt.value ? "" : "hover:bg-white/60")}
            style={value === opt.value
              ? { background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))", color: "#fff", boxShadow: "0 6px 16px -4px var(--sd-glow-medium)" }
              : { color: "var(--sd-body)" }}
          >
            {opt.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function DColor({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="glass flex items-center justify-between gap-3 rounded-2xl px-4 py-3">
      <span className="text-sm font-semibold" style={{ color: "var(--sd-heading)" }}>{label}</span>
      <label className="relative flex cursor-pointer items-center gap-2.5">
        <span className="font-mono text-[11px]" style={{ color: "var(--sd-muted)" }}>{value}</span>
        <span className="h-8 w-8 rounded-xl border-2 border-white shadow" style={{ background: value, boxShadow: "0 4px 12px rgba(59,130,246,0.25)" }} />
        <input type="color" value={value} onChange={(e) => onChange(e.target.value)} className="absolute inset-0 cursor-pointer opacity-0" />
      </label>
    </div>
  );
}

function TabHeader({ title, subtitle }: { title: string; subtitle: string }) {
  return (
    <div>
      <h2 className="heading-text text-xl font-bold">{title}</h2>
      <p className="mt-0.5 text-xs" style={{ color: "var(--sd-muted)" }}>{subtitle}</p>
    </div>
  );
}

/* ================================================================== */
/*  Settings tabs (draft → Save Changes → verified persist)            */
/* ================================================================== */

function HomepageTab() {
  const { settings, saveSection } = useSettings();
  const { draft, setDraft, revert, markClean, dirty } = useDraft(settings.content);
  const { status, run } = useSaveState();

  const save = () => run(async () => {
    if (!draft.heroTitle.trim() || !draft.heroHighlight.trim()) {
      toast.error("Hero title and highlight are required.");
      return false;
    }
    const ok = await saveSection("content", draft);
    if (ok) { markClean(); toast.success("Homepage saved successfully"); }
    return ok;
  });

  const c = draft;
  const set = (patch: Partial<SiteSettings["content"]>) => setDraft({ ...c, ...patch });
  const setSection = (key: keyof SiteSettings["content"]["sections"], v: boolean) =>
    set({ sections: { ...c.sections, [key]: v } });

  return (
    <div className="space-y-4">
      <TabHeader title="Homepage Builder" subtitle="Hero, about content and section visibility" />
      <p className="text-[11px] font-bold uppercase tracking-widest" style={{ color: "var(--sd-muted)" }}>Hero</p>
      <div className="grid gap-4 sm:grid-cols-2">
        <DField label="Hero Title" value={c.heroTitle} onChange={(v) => set({ heroTitle: v })} />
        <DField label="Hero Highlight" value={c.heroHighlight} onChange={(v) => set({ heroHighlight: v })} />
        <DTextarea label="Hero Description" value={c.heroSubtitle} onChange={(v) => set({ heroSubtitle: v })} rows={3} />
        <DField label="Primary Button Text" value={c.heroCtaText} onChange={(v) => set({ heroCtaText: v })} />
        <DField label="Secondary Button Text" value={c.heroCta2Text} onChange={(v) => set({ heroCta2Text: v })} />
        <ImageUploader
          label="Desktop Hero Image"
          image={c.heroImage}
          altFallback={c.heroTitle || "Hero"}
          onChange={(img) => set({ heroImage: img })}
        />
        <ImageUploader
          label="Mobile Hero Image"
          image={c.heroImageMobile}
          altFallback={c.heroTitle || "Hero"}
          onChange={(img) => set({ heroImageMobile: img })}
        />
        <DField label="Hero Image Alt Text" value={c.heroImageAlt} onChange={(v) => set({ heroImageAlt: v })} placeholder="Shivmudra Design — creative studio" />
      </div>

      <p className="pt-2 text-[11px] font-bold uppercase tracking-widest" style={{ color: "var(--sd-muted)" }}>About Section</p>
      <div className="grid gap-4 sm:grid-cols-2">
        <DField label="About Heading" value={c.aboutTitle} onChange={(v) => set({ aboutTitle: v })} />
        <DTextarea label="About Paragraph 1" value={c.aboutText1} onChange={(v) => set({ aboutText1: v })} rows={4} />
        <DTextarea label="About Paragraph 2" value={c.aboutText2} onChange={(v) => set({ aboutText2: v })} rows={4} />
      </div>

      <p className="pt-2 text-[11px] font-bold uppercase tracking-widest" style={{ color: "var(--sd-muted)" }}>Statistics</p>
      <div className="grid gap-4 sm:grid-cols-2">
        <DField label="Projects Completed" type="number" value={String(c.stats.projects)} onChange={(v) => set({ stats: { ...c.stats, projects: Number(v) || 0 } })} />
        <DField label="Years Experience" type="number" value={String(c.stats.years)} onChange={(v) => set({ stats: { ...c.stats, years: Number(v) || 0 } })} />
        <DField label="Creative Projects" type="number" value={String(c.stats.creative)} onChange={(v) => set({ stats: { ...c.stats, creative: Number(v) || 0 } })} />
        <DField label="Happy Clients" type="number" value={String(c.stats.clients)} onChange={(v) => set({ stats: { ...c.stats, clients: Number(v) || 0 } })} />
      </div>

      <p className="pt-2 text-[11px] font-bold uppercase tracking-widest" style={{ color: "var(--sd-muted)" }}>Sections — Enable / Disable</p>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        <DToggle label="Hero" checked={c.sections.hero} onChange={(v) => setSection("hero", v)} />
        <DToggle label="About" checked={c.sections.about} onChange={(v) => setSection("about", v)} />
        <DToggle label="Services" checked={c.sections.services} onChange={(v) => setSection("services", v)} />
        <DToggle label="Portfolio" checked={c.sections.portfolio} onChange={(v) => setSection("portfolio", v)} />
        <DToggle label="Experience" checked={c.sections.experience} onChange={(v) => setSection("experience", v)} />
        <DToggle label="Skills" checked={c.sections.skills} onChange={(v) => setSection("skills", v)} />
        <DToggle label="Testimonials" checked={c.sections.testimonials} onChange={(v) => setSection("testimonials", v)} />
        <DToggle label="Statistics" checked={c.sections.stats} onChange={(v) => setSection("stats", v)} />
        <DToggle label="Contact" checked={c.sections.contact} onChange={(v) => setSection("contact", v)} />
      </div>

      <SaveBar status={status} dirty={dirty} onSave={save} onCancel={revert} label="Save Homepage" />
    </div>
  );
}

function WebsiteTab() {
  const { settings, saveSection } = useSettings();
  const { draft, setDraft, revert, markClean, dirty } = useDraft(settings.content);
  const { status, run } = useSaveState();

  const c = draft;
  const set = (patch: Partial<SiteSettings["content"]>) => setDraft({ ...c, ...patch });

  const save = () => run(async () => {
    if (!c.website.name.trim()) { toast.error("Website name is required."); return false; }
    if (!/^\S+@\S+\.\S+$/.test(c.email.trim())) { toast.error("Please enter a valid email address."); return false; }
    if (!c.phone.trim()) { toast.error("Phone number is required."); return false; }
    const ok = await saveSection("content", draft);
    if (ok) { markClean(); toast.success("Website settings saved successfully"); }
    return ok;
  });

  return (
    <div className="space-y-4">
      <TabHeader title="Website Settings" subtitle="Identity and contact details used across the public website" />
      <div className="grid gap-4 sm:grid-cols-2">
        <DField label="Website Name" value={c.website.name} onChange={(v) => set({ website: { ...c.website, name: v } })} />
        <DField label="Owner" value={c.website.owner} onChange={(v) => set({ website: { ...c.website, owner: v } })} />
        <DField label="Phone" value={c.phone} onChange={(v) => set({ phone: v })} placeholder="+91 98765 43210" />
        <DField label="WhatsApp Number" value={c.whatsapp} onChange={(v) => set({ whatsapp: v })} placeholder="919876543210" />
        <DField label="Instagram Handle" value={c.instagram} onChange={(v) => set({ instagram: v })} placeholder="shivmudra.design" />
        <DField label="Email" value={c.email} onChange={(v) => set({ email: v })} />
        <DField label="Location" value={c.location} onChange={(v) => set({ location: v })} />
        <DField label="Copyright Text" value={c.website.copyright} onChange={(v) => set({ website: { ...c.website, copyright: v } })} />
      </div>
      <SaveBar status={status} dirty={dirty} onSave={save} onCancel={revert} label="Save Website Settings" />
    </div>
  );
}

function SeoTab() {
  const { settings, saveSection } = useSettings();
  const { draft, setDraft, revert, markClean, dirty } = useDraft(settings.content);
  const { status, run } = useSaveState();

  const c = draft;
  const set = (patch: Partial<SiteSettings["content"]>) => setDraft({ ...c, ...patch });

  const save = () => run(async () => {
    if (!c.seo.title.trim()) { toast.error("SEO title is required."); return false; }
    if (!c.seo.description.trim()) { toast.error("Meta description is required."); return false; }
    const ok = await saveSection("content", draft);
    if (ok) { markClean(); toast.success("SEO settings saved successfully"); }
    return ok;
  });

  return (
    <div className="space-y-4">
      <TabHeader title="SEO Settings" subtitle="Metadata applied live to the document head" />
      <div className="grid gap-4 sm:grid-cols-2">
        <DField label="Website Title" value={c.seo.title} onChange={(v) => set({ seo: { ...c.seo, title: v } })} />
        <DField label="Canonical URL" value={c.seo.canonical} onChange={(v) => set({ seo: { ...c.seo, canonical: v } })} placeholder="https://shivmudra.design/" />
        <DTextarea label="Meta Description" value={c.seo.description} onChange={(v) => set({ seo: { ...c.seo, description: v } })} rows={3} />
        <DTextarea label="Keywords" value={c.seo.keywords} onChange={(v) => set({ seo: { ...c.seo, keywords: v } })} rows={2} />
        <DField label="OG Title" value={c.seo.ogTitle} onChange={(v) => set({ seo: { ...c.seo, ogTitle: v } })} />
        <DField label="OG Image URL" value={c.seo.ogImage} onChange={(v) => set({ seo: { ...c.seo, ogImage: v } })} />
        <DTextarea label="OG Description" value={c.seo.ogDescription} onChange={(v) => set({ seo: { ...c.seo, ogDescription: v } })} rows={2} />
        <DField label="Robots" value={c.seo.robots} onChange={(v) => set({ seo: { ...c.seo, robots: v } })} placeholder="index, follow" />
      </div>
      <SaveBar status={status} dirty={dirty} onSave={save} onCancel={revert} label="Save SEO Settings" />
    </div>
  );
}

function SocialTab() {
  const { settings, saveSection } = useSettings();
  const { draft, setDraft, revert, markClean, dirty } = useDraft(settings.content);
  const { status, run } = useSaveState();

  const c = draft;
  const set = (patch: Partial<SiteSettings["content"]>) => setDraft({ ...c, ...patch });
  const setSocial = (key: keyof SiteSettings["content"]["social"], v: string) =>
    set({ social: { ...c.social, [key]: v } });

  const isValidUrl = (v: string) => v === "" || /^https?:\/\/\S+$/.test(v.trim());

  const save = () => run(async () => {
    for (const [key, value] of Object.entries(c.social)) {
      if (!isValidUrl(value)) {
        toast.error(`${key} must be a valid URL starting with https://`);
        return false;
      }
    }
    const ok = await saveSection("content", draft);
    if (ok) { markClean(); toast.success("Social links saved successfully"); }
    return ok;
  });

  const fields: { key: keyof SiteSettings["content"]["social"]; label: string; placeholder: string }[] = [
    { key: "instagram", label: "Instagram", placeholder: "https://instagram.com/..." },
    { key: "facebook", label: "Facebook", placeholder: "https://facebook.com/..." },
    { key: "youtube", label: "YouTube", placeholder: "https://youtube.com/@..." },
    { key: "linkedin", label: "LinkedIn", placeholder: "https://linkedin.com/in/..." },
    { key: "behance", label: "Behance", placeholder: "https://behance.net/..." },
    { key: "dribbble", label: "Dribbble", placeholder: "https://dribbble.com/..." },
    { key: "whatsapp", label: "WhatsApp", placeholder: "https://wa.me/..." },
  ];

  return (
    <div className="space-y-4">
      <TabHeader title="Social Media" subtitle="Links used by the footer and contact section — empty fields are hidden" />
      <div className="grid gap-4 sm:grid-cols-2">
        {fields.map((f) => (
          <DField key={f.key} label={f.label} value={c.social[f.key]} onChange={(v) => setSocial(f.key, v)} placeholder={f.placeholder} />
        ))}
      </div>
      <SaveBar status={status} dirty={dirty} onSave={save} onCancel={revert} label="Save Social Links" />
    </div>
  );
}

function AppearanceTab() {
  const { settings, saveSection } = useSettings();
  const saved = { themeStyle: settings.themeStyle, colors: settings.colors };
  const { draft, setDraft, revert, markClean, dirty } = useDraft(saved);
  const { status, run } = useSaveState();

  const save = () => run(async () => {
    const okColors = await saveSection("colors", draft.colors);
    if (!okColors) return false;
    const okTheme = await saveSection("themeStyle", draft.themeStyle);
    if (okTheme) { markClean(); toast.success("Appearance saved successfully"); }
    return okTheme;
  });

  return (
    <div className="space-y-4">
      <TabHeader title="Appearance" subtitle="Theme style and the color system" />
      <DSegmented<ThemeStyle>
        label="Theme Style"
        value={draft.themeStyle}
        onChange={(v) => setDraft({ ...draft, themeStyle: v })}
        options={[
          { value: "galaxy", label: "White Galaxy" },
          { value: "minimal", label: "White Minimal" },
          { value: "gradient", label: "White Gradient" },
        ]}
      />
      <div className="space-y-3">
        <DColor label="Primary · Electric Blue" value={draft.colors.primary} onChange={(v) => setDraft({ ...draft, colors: { ...draft.colors, primary: v } })} />
        <DColor label="Secondary · Cyan" value={draft.colors.secondary} onChange={(v) => setDraft({ ...draft, colors: { ...draft.colors, secondary: v } })} />
        <DColor label="Accent · Soft Violet" value={draft.colors.accent} onChange={(v) => setDraft({ ...draft, colors: { ...draft.colors, accent: v } })} />
        <DColor label="Glow Color" value={draft.colors.glow} onChange={(v) => setDraft({ ...draft, colors: { ...draft.colors, glow: v } })} />
        <DColor label="Particle Color" value={draft.colors.particle} onChange={(v) => setDraft({ ...draft, colors: { ...draft.colors, particle: v } })} />
      </div>
      <div className="glass rounded-2xl p-4">
        <p className="flex items-center gap-2 text-sm font-semibold" style={{ color: "var(--sd-heading)" }}>
          <Check size={14} style={{ color: "var(--sd-primary)" }} />
          The website always stays predominantly white
        </p>
        <p className="mt-1.5 text-xs leading-relaxed" style={{ color: "var(--sd-muted)" }}>
          The galaxy renders as an animated light layer above the white canvas — never as a dark background.
        </p>
      </div>
      <SaveBar status={status} dirty={dirty} onSave={save} onCancel={revert} label="Save Appearance" />
    </div>
  );
}

function GalaxyTab() {
  const { settings, saveSection } = useSettings();
  const { draft, setDraft, revert, markClean, dirty } = useDraft(settings.galaxy);
  const { status, run } = useSaveState();

  const save = () => run(async () => {
    const ok = await saveSection("galaxy", draft);
    if (ok) { markClean(); toast.success("Galaxy settings saved successfully"); }
    return ok;
  });

  return (
    <div className="space-y-4">
      <TabHeader title="Galaxy Background" subtitle="Animated particle system behind the white canvas" />
      <DToggle label="Galaxy Background" hint="Master switch for the animated galaxy" checked={draft.background} onChange={(v) => setDraft({ ...draft, background: v })} />
      <DToggle label="Particles" hint="Glowing dust, stars & light dots" checked={draft.particles} onChange={(v) => setDraft({ ...draft, particles: v })} />
      <DToggle label="Mouse Parallax" hint="Subtle depth on pointer move (desktop)" checked={draft.parallax} onChange={(v) => setDraft({ ...draft, parallax: v })} />
      <DSegmented<Density>
        label="Particle Density"
        value={draft.density}
        onChange={(v) => setDraft({ ...draft, density: v })}
        options={[
          { value: "low", label: "Low" },
          { value: "medium", label: "Medium" },
          { value: "high", label: "High" },
        ]}
      />
      <DSegmented<Speed>
        label="Movement Speed"
        value={draft.movement}
        onChange={(v) => setDraft({ ...draft, movement: v })}
        options={[
          { value: "slow", label: "Slow" },
          { value: "medium", label: "Medium" },
          { value: "fast", label: "Fast" },
        ]}
      />
      <DSegmented<GlowLevel>
        label="Glow Intensity"
        value={draft.glow}
        onChange={(v) => setDraft({ ...draft, glow: v })}
        options={[
          { value: "low", label: "Low" },
          { value: "medium", label: "Medium" },
          { value: "high", label: "High" },
        ]}
      />
      <SaveBar status={status} dirty={dirty} onSave={save} onCancel={revert} label="Save Galaxy Settings" />
    </div>
  );
}

function SoundTab() {
  const { settings, saveSection } = useSettings();
  const { draft, setDraft, revert, markClean, dirty } = useDraft(settings.sound);
  const { status, run } = useSaveState();
  const [customSounds, setCustomSounds] = useState<Record<string, CustomSound>>(() => soundEngine.getCustomSounds());
  const [uploadError, setUploadError] = useState<string | null>(null);

  useEffect(() => soundEngine.subscribeCustom(() => setCustomSounds(soundEngine.getCustomSounds())), []);

  const save = () => run(async () => {
    const ok = await saveSection("sound", draft);
    if (ok) { markClean(); toast.success("Sound settings saved successfully"); }
    return ok;
  });

  const handleUpload = async (name: UISoundName, file: File) => {
    setUploadError(null);
    const result = await soundEngine.setCustomSound(name, file);
    if (!result.ok) {
      setUploadError(result.error ?? "Upload failed.");
      playUISound("ui_error", { category: "error", soft: true });
    } else {
      playUISound("ui_upload", { category: "success", soft: true });
    }
  };

  return (
    <div className="space-y-4">
      <TabHeader title="Sound Effects" subtitle="Global UI interaction sound system" />
      <DToggle label="Sound Enabled" checked={draft.enabled} onChange={(v) => setDraft({ ...draft, enabled: v })} />

      <div className="glass rounded-2xl p-4">
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold" style={{ color: "var(--sd-heading)" }}>Master Volume</p>
          <span className="font-mono text-xs" style={{ color: "var(--sd-primary)" }}>{Math.round(draft.volume * 100)}%</span>
        </div>
        <input
          type="range"
          min={0}
          max={100}
          value={Math.round(draft.volume * 100)}
          onChange={(e) => setDraft({ ...draft, volume: Number(e.target.value) / 100 })}
          className="mt-3 w-full cursor-pointer appearance-none rounded-full"
          style={{ height: 6, background: `linear-gradient(90deg, var(--sd-primary) ${draft.volume * 100}%, rgba(148,163,184,0.3) ${draft.volume * 100}%)` }}
        />
        <div className="mt-3 flex gap-1.5">
          {[
            { label: "Low", value: 0.4 },
            { label: "Medium", value: 0.6 },
            { label: "High", value: 0.75 },
            { label: "Maximum", value: 0.9 },
          ].map((preset) => (
            <button
              key={preset.label}
              type="button"
              onClick={() => setDraft({ ...draft, volume: preset.value })}
              data-sound="none"
              className="flex-1 rounded-xl px-1 py-1.5 text-[10px] font-bold transition-all duration-300"
              style={
                Math.abs(draft.volume - preset.value) < 0.005
                  ? { background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))", color: "#fff" }
                  : { background: "rgba(148,163,184,0.12)", color: "var(--sd-muted)" }
              }
            >
              {preset.label} {Math.round(preset.value * 100)}%
            </button>
          ))}
        </div>
      </div>

      <p className="pt-1 text-[11px] font-bold uppercase tracking-widest" style={{ color: "var(--sd-muted)" }}>Sound Categories</p>
      <DToggle label="Navigation Sound" hint="Menu & link clicks" checked={draft.navigation} onChange={(v) => setDraft({ ...draft, navigation: v })} />
      <DToggle label="Button Sound" hint="CTAs, cards & actions" checked={draft.button} onChange={(v) => setDraft({ ...draft, button: v })} />
      <DToggle label="Success Sound" hint="Form submit & uploads" checked={draft.success} onChange={(v) => setDraft({ ...draft, success: v })} />
      <DToggle label="Error Sound" hint="Invalid actions" checked={draft.error} onChange={(v) => setDraft({ ...draft, error: v })} />
      <DToggle label="Admin Sound" hint="Softer variants inside this panel" checked={draft.admin} onChange={(v) => setDraft({ ...draft, admin: v })} />
      <DToggle label="Hover Sound" hint="Ultra-soft desktop ticks (off by default)" checked={draft.hover} onChange={(v) => setDraft({ ...draft, hover: v })} />
      <DToggle label="Scroll Sound" hint="Velocity-aware whoosh" checked={draft.scroll} onChange={(v) => setDraft({ ...draft, scroll: v })} />
      <DToggle label="Section Sound" hint="Ambient tick on section entry" checked={draft.section} onChange={(v) => setDraft({ ...draft, section: v })} />

      <SaveBar status={status} dirty={dirty} onSave={save} onCancel={revert} label="Save Sound Settings" />

      <button onClick={() => soundEngine.preview("ui_power")} data-sound="none" className="btn-glass w-full text-sm!">
        <Play size={15} />
        Preview Sound System
      </button>

      <p className="pt-2 text-[11px] font-bold uppercase tracking-widest" style={{ color: "var(--sd-muted)" }}>Custom Sound Library</p>
      <p className="text-[11px] leading-relaxed" style={{ color: "var(--sd-muted)" }}>
        Replace any sound with your own MP3 / WAV / OGG file (max 512 KB each).
      </p>
      {uploadError && (
        <div className="flex items-start gap-2 rounded-2xl px-4 py-3 text-xs font-semibold" style={{ background: "rgba(239,68,68,0.08)", color: "#ef4444", border: "1px solid rgba(239,68,68,0.25)" }}>
          <AlertTriangle size={14} className="mt-0.5 shrink-0" />
          {uploadError}
        </div>
      )}
      <div className="space-y-2.5">
        {UI_SOUND_LIBRARY.map((item) => (
          <CustomSoundRow key={item.name} name={item.name} label={item.label} custom={customSounds[item.name]} onUpload={handleUpload} />
        ))}
      </div>
      <p className="pb-2 text-[11px] leading-relaxed" style={{ color: "var(--sd-muted)" }}>
        All sounds are procedurally synthesized — no copyrighted samples.
      </p>
    </div>
  );
}

/* custom sound row (kept local to the Sound tab) */
const UI_SOUND_LIBRARY: { name: UISoundName; label: string }[] = [
  { name: "ui_click", label: "UI Click" },
  { name: "ui_hover", label: "UI Hover" },
  { name: "ui_card", label: "UI Card" },
  { name: "ui_filter", label: "UI Filter" },
  { name: "ui_select", label: "UI Select" },
  { name: "ui_open", label: "UI Open" },
  { name: "ui_close", label: "UI Close" },
  { name: "ui_success", label: "UI Success" },
  { name: "ui_error", label: "UI Error" },
  { name: "ui_toggle_on", label: "UI Toggle On" },
  { name: "ui_toggle_off", label: "UI Toggle Off" },
  { name: "ui_scan", label: "UI Scan" },
  { name: "ui_upload", label: "UI Upload" },
  { name: "ui_delete", label: "UI Delete" },
  { name: "ui_power", label: "UI Power" },
  { name: "ui_scroll_down", label: "Scroll Down" },
  { name: "ui_scroll_up", label: "Scroll Up" },
  { name: "ui_section", label: "Section Tick" },
];

function CustomSoundRow({ name, label, custom, onUpload }: {
  name: UISoundName;
  label: string;
  custom?: CustomSound;
  onUpload: (name: UISoundName, file: File) => void;
}) {
  const inputId = `sound-file-${name}`;
  return (
    <div className="glass rounded-2xl p-3.5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex min-w-0 items-center gap-2.5">
          <span
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl text-white"
            style={{ background: custom ? "linear-gradient(135deg, var(--sd-secondary), var(--sd-accent))" : "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" }}
          >
            <Music size={15} />
          </span>
          <div className="min-w-0">
            <p className="truncate text-sm font-semibold" style={{ color: "var(--sd-heading)" }}>{label}</p>
            <p className="font-mono text-[10px] font-bold tracking-widest" style={{ color: custom ? "var(--sd-secondary)" : "var(--sd-muted)" }}>
              {custom ? (custom.enabled ? "CUSTOM · ON" : "CUSTOM · OFF") : "DEFAULT"}
            </p>
          </div>
        </div>
        <div className="flex shrink-0 items-center gap-1.5">
          <button onClick={() => soundEngine.preview(name)} data-sound="none" className="glass flex h-8 w-8 items-center justify-center rounded-xl transition-transform hover:scale-110" aria-label={`Preview ${label}`} title="Preview">
            <Play size={13} style={{ color: "var(--sd-primary)" }} />
          </button>
          <label htmlFor={inputId} className="glass flex h-8 cursor-pointer items-center justify-center rounded-xl px-2.5 text-[10px] font-bold transition-transform hover:scale-105" style={{ color: "var(--sd-heading)" }} title={custom ? "Replace" : "Upload"}>
            <Upload size={13} style={{ color: "var(--sd-primary)" }} />
            <span className="ml-1 hidden sm:inline">{custom ? "Replace" : "Upload"}</span>
          </label>
          <input
            id={inputId}
            type="file"
            accept=".mp3,.wav,.ogg,audio/mpeg,audio/wav,audio/ogg"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onUpload(name, file);
              e.target.value = "";
            }}
          />
          {custom && (
            <>
              <button
                onClick={() => soundEngine.setCustomEnabled(name, !custom.enabled)}
                data-sound="none"
                className="flex h-8 w-8 items-center justify-center rounded-xl text-[10px] font-bold transition-transform hover:scale-110"
                style={{ background: custom.enabled ? "rgba(6,182,212,0.12)" : "rgba(148,163,184,0.15)", color: custom.enabled ? "var(--sd-secondary)" : "var(--sd-muted)" }}
                aria-label="Toggle custom sound"
              >
                {custom.enabled ? "ON" : "OFF"}
              </button>
              <button
                onClick={() => { soundEngine.removeCustomSound(name); playUISound("ui_delete", { category: "admin", soft: true }); }}
                data-sound="none"
                className="flex h-8 w-8 items-center justify-center rounded-xl transition-transform hover:scale-110"
                style={{ background: "rgba(239,68,68,0.1)", color: "#ef4444" }}
                aria-label="Delete custom sound"
              >
                <Trash2 size={13} />
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Admin profile                                                      */
/* ================================================================== */

function ProfileTab({ isDemo }: { isDemo: boolean }) {
  const creds = getAdminCredentials();
  const [username, setUsername] = useState(creds.username);
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const { status, run } = useSaveState();

  const save = () => run(async () => {
    if (username.trim().length < 3) { toast.error("Username must be at least 3 characters."); return false; }
    if (password.length < 6) { toast.error("Password must be at least 6 characters."); return false; }
    if (password !== confirm) { toast.error("Passwords do not match."); return false; }
    // persist credentials, then verify the write
    const ok = updateAdminCredentials(username, password);
    if (!ok) { toast.error("Unable to save changes. Please try again."); return false; }
    const verify = getAdminCredentials();
    if (verify.username !== username.trim() || verify.password !== password) {
      toast.error("Unable to save changes. Please try again.");
      return false;
    }
    toast.success("Admin credentials updated successfully");
    setPassword("");
    setConfirm("");
    return true;
  });

  return (
    <div className="space-y-4">
      <TabHeader title="Admin Profile" subtitle="Account details and login credentials" />
      <div className="glass flex items-center gap-4 rounded-2xl px-5 py-4">
        <span className="flex h-12 w-12 items-center justify-center rounded-2xl text-lg font-bold text-white" style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-accent))" }}>
          {isDemo ? "D" : "A"}
        </span>
        <div>
          <p className="text-sm font-bold" style={{ color: "var(--sd-heading)" }}>
            {isDemo ? "Temporary Demo Account" : "Administrator"}
          </p>
          <p className="text-xs" style={{ color: "var(--sd-muted)" }}>
            {isDemo ? "demo@shivmudra.design" : creds.username}
          </p>
        </div>
      </div>

      {isDemo ? (
        <div className="rounded-3xl p-5" style={{ background: "rgba(255,251,235,0.85)", border: "1px solid rgba(245,158,11,0.45)" }}>
          <p className="flex items-center gap-2 text-sm font-bold" style={{ color: "#b45309" }}>
            <AlertTriangle size={15} />
            Not available in Demo Mode
          </p>
          <p className="mt-1.5 text-xs leading-relaxed" style={{ color: "#92400e" }}>
            Demo accounts cannot change production admin credentials or authentication settings.
          </p>
        </div>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-2">
            <DField label="Username" value={username} onChange={setUsername} />
            <div />
            <DField label="New Password" value={password} onChange={setPassword} type="password" />
            <DField label="Confirm New Password" value={confirm} onChange={setConfirm} type="password" />
          </div>
          <SaveBar
            status={status}
            dirty={password.length > 0 || confirm.length > 0 || username !== creds.username}
            onSave={save}
            onCancel={() => { setUsername(creds.username); setPassword(""); setConfirm(""); }}
            label="Save Credentials"
          />
        </>
      )}
    </div>
  );
}

/* ================================================================== */
/*  Dashboard                                                          */
/* ================================================================== */

const TABS = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard },
  { id: "homepage", label: "Homepage", icon: FileText },
  { id: "website", label: "Website", icon: Globe },
  { id: "images", label: "Images", icon: Images },
  { id: "portfolio", label: "All Projects", icon: FolderKanban },
  { id: "categories", label: "Categories", icon: FolderTree },
  { id: "services", label: "Services", icon: Wrench },
  { id: "experience", label: "Experience", icon: Briefcase },
  { id: "skills", label: "Skills", icon: Gauge },
  { id: "testimonials", label: "Testimonials", icon: Quote },
  { id: "enquiries", label: "Enquiries", icon: Inbox },
  { id: "seo", label: "SEO", icon: Search },
  { id: "social", label: "Social Links", icon: Share2 },
  { id: "appearance", label: "Appearance", icon: Palette },
  { id: "galaxy", label: "Galaxy", icon: Sparkles },
  { id: "sound", label: "Sound", icon: Volume2 },
  { id: "profile", label: "Profile", icon: UserCircle },
] as const;

type TabId = (typeof TABS)[number]["id"];

function SummaryCard({ icon: Icon, label, value }: { icon: LucideIcon; label: string; value: string | number }) {
  return (
    <div className="glass flex items-center gap-3.5 rounded-2xl px-5 py-4">
      <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl text-white" style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" }}>
        <Icon size={18} />
      </span>
      <div>
        <p className="stat-number text-2xl font-bold">{value}</p>
        <p className="text-xs font-semibold" style={{ color: "var(--sd-muted)" }}>{label}</p>
      </div>
    </div>
  );
}

function QuickAction({ icon: Icon, label, onClick }: { icon: LucideIcon; label: string; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="glass flex items-center gap-2.5 rounded-2xl px-4 py-3 text-xs font-bold transition-all duration-300 hover:-translate-y-1"
      style={{ color: "var(--sd-heading)" }}
    >
      <span className="flex h-8 w-8 items-center justify-center rounded-lg text-white" style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))" }}>
        <Icon size={14} />
      </span>
      {label}
    </button>
  );
}

export default function AdminDashboard() {
  const { settings, reset } = useSettings();
  const { logout, isDemo } = useAuth();
  const [tab, setTab] = useState<TabId>("dashboard");
  const [profileOpen, setProfileOpen] = useState(false);
  const [pendingTab, setPendingTab] = useState<TabId | null>(null);

  /* Guard against leaving with unsaved changes (browser close/refresh) */
  useEffect(() => {
    const handler = (e: BeforeUnloadEvent) => {
      if (hasUnsavedChanges()) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, []);

  const switchTab = (id: TabId) => {
    if (id !== tab && hasUnsavedChanges()) {
      setPendingTab(id);
      playUISound("ui_open", { category: "admin", soft: true });
      return;
    }
    setTab(id);
  };

  const handleLogout = () => {
    discardAllUnsaved();
    playUISound("ui_power", { category: null, soft: true });
    logout();
    window.location.replace("#/admin/login");
  };

  const c = settings.content;

  return (
    <div data-admin-root className="relative min-h-screen">
      <ToastHost />

      {/* unsaved-changes dialog */}
      {pendingTab !== null && (
        <UnsavedDialog
          targetTab={TABS.find((t) => t.id === pendingTab)?.label ?? pendingTab}
          onStay={() => setPendingTab(null)}
          onDiscard={() => {
            discardAllUnsaved();
            setTab(pendingTab);
            setPendingTab(null);
          }}
        />
      )}

      {/* ---------- header ---------- */}
      <header
        className="sticky top-0 z-40"
        style={{
          background: "rgba(255,255,255,0.82)",
          backdropFilter: "blur(18px)",
          WebkitBackdropFilter: "blur(18px)",
          borderBottom: "1px solid rgba(191,219,254,0.55)",
        }}
      >
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-5 sm:px-8">
          <div className="flex items-center gap-3">
            <span
              className="flex h-10 w-10 items-center justify-center rounded-xl text-white"
              style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-secondary))", boxShadow: "0 8px 24px -6px var(--sd-glow-medium)" }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M12 2 21 7v10l-9 5-9-5V7l9-5Z" stroke="white" strokeWidth="1.8" strokeLinejoin="round" />
                <path d="M9.5 15.5c-1.5-1-1.5-2.7 0-3.4l5-2.2c1.5-.7 1.5-2.4 0-3.4" stroke="white" strokeWidth="1.8" strokeLinecap="round" />
              </svg>
            </span>
            <div>
              <p className="heading-text text-sm font-bold leading-tight">{c.website.name}</p>
              <p className="text-[10px] font-bold tracking-[0.25em]" style={{ color: "var(--sd-primary)" }}>
                ADMIN DASHBOARD
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {isDemo && (
              <span
                className="hidden items-center gap-1.5 rounded-full px-3 py-1.5 text-[10px] font-bold tracking-[0.18em] sm:flex"
                style={{ background: "rgba(245,158,11,0.12)", color: "#b45309", border: "1px solid rgba(245,158,11,0.4)" }}
                title="Temporary Demo Account"
              >
                <span className="h-1.5 w-1.5 rounded-full" style={{ background: "#f59e0b", boxShadow: "0 0 8px rgba(245,158,11,0.8)" }} />
                DEMO MODE
              </span>
            )}
            <a
              href="#/"
              className="glass flex items-center gap-2 rounded-full px-4 py-2 text-xs font-bold transition-transform hover:-translate-y-0.5"
              style={{ color: "var(--sd-heading)" }}
            >
              <Globe size={13} style={{ color: "var(--sd-primary)" }} />
              <span className="hidden sm:inline">View Website</span>
            </a>

            {/* profile menu */}
            <div className="relative">
              <button
                data-sound="none"
                onClick={() => {
                  setProfileOpen(!profileOpen);
                  playUISound("ui_click", { category: "admin", soft: true });
                }}
                className="glass flex items-center gap-2 rounded-full py-1.5 pl-1.5 pr-2.5 transition-transform hover:-translate-y-0.5"
                aria-label="Profile menu"
                aria-expanded={profileOpen}
              >
                <span className="flex h-8 w-8 items-center justify-center rounded-full text-xs font-bold text-white" style={{ background: "linear-gradient(135deg, var(--sd-primary), var(--sd-accent))" }}>
                  {isDemo ? "D" : "A"}
                </span>
                <span className="hidden text-xs font-bold sm:block" style={{ color: "var(--sd-heading)" }}>
                  {isDemo ? "Demo" : "Admin"}
                </span>
                <ChevronDown size={13} style={{ color: "var(--sd-muted)", transform: profileOpen ? "rotate(180deg)" : "none", transition: "transform 0.3s" }} />
              </button>

              {profileOpen && (
                <>
                  <div className="fixed inset-0 z-40" onClick={() => setProfileOpen(false)} aria-hidden />
                  <div className="glass-strong absolute right-0 top-12 z-50 w-60 rounded-2xl p-4" style={{ boxShadow: "0 20px 50px -12px var(--sd-glow-medium)" }}>
                    {isDemo ? (
                      <>
                        <p className="text-sm font-bold" style={{ color: "#b45309" }}>Temporary Demo Account</p>
                        <p className="text-xs" style={{ color: "var(--sd-muted)" }}>demo@shivmudra.design</p>
                      </>
                    ) : (
                      <>
                        <p className="text-sm font-bold" style={{ color: "var(--sd-heading)" }}>Administrator</p>
                        <p className="text-xs" style={{ color: "var(--sd-muted)" }}>{getAdminCredentials().username}</p>
                      </>
                    )}
                    <div className="my-3 h-px" style={{ background: "rgba(191,219,254,0.7)" }} />
                    <button
                      data-sound="none"
                      onClick={handleLogout}
                      className="flex w-full items-center gap-2 rounded-xl px-3 py-2.5 text-sm font-bold transition-all hover:-translate-y-0.5"
                      style={{ color: "#ef4444", background: "rgba(239,68,68,0.08)" }}
                    >
                      <LogOut size={15} />
                      Logout
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* ---------- body ---------- */}
      <div className="mx-auto grid max-w-6xl gap-6 px-5 py-8 sm:px-8 lg:grid-cols-[230px_1fr]">
        {/* sidebar */}
        <aside>
          <div className="glass sticky top-24 flex gap-1 overflow-x-auto rounded-2xl p-2 lg:max-h-[calc(100vh-7.5rem)] lg:flex-col lg:overflow-y-auto lg:overflow-x-visible">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => switchTab(t.id)}
                className={cn(
                  "flex shrink-0 items-center gap-2.5 rounded-xl px-4 py-3 text-sm font-semibold transition-all duration-300",
                  tab === t.id ? "" : "hover:bg-white/70"
                )}
                style={tab === t.id
                  ? { background: "linear-gradient(120deg, var(--sd-primary), var(--sd-secondary))", color: "#fff", boxShadow: "0 8px 20px -6px var(--sd-glow-medium)" }
                  : { color: "var(--sd-body)" }}
              >
                <t.icon size={16} />
                {t.label}
                {t.id === "enquiries" && c.enquiries.length > 0 && (
                  <span
                    className="ml-auto rounded-full px-2 py-0.5 text-[10px] font-bold"
                    style={{ background: tab === t.id ? "rgba(255,255,255,0.25)" : "rgba(37,99,235,0.12)", color: tab === t.id ? "#fff" : "var(--sd-primary)" }}
                  >
                    {c.enquiries.length}
                  </span>
                )}
              </button>
            ))}
            <div className="hidden lg:mt-2 lg:block lg:h-px" style={{ background: "rgba(191,219,254,0.7)" }} />
            <button
              data-sound="none"
              onClick={() => {
                reset();
                playUISound("ui_power", { category: null, soft: true });
                toast.success("All settings restored to defaults");
              }}
              className="flex shrink-0 items-center gap-2.5 rounded-xl px-4 py-3 text-sm font-semibold transition-colors hover:bg-white/70"
              style={{ color: "#ef4444" }}
            >
              <RotateCcw size={15} />
              Reset All
            </button>
          </div>
        </aside>

        {/* content */}
        <main className="glass-strong min-h-[60vh] rounded-3xl p-6 sm:p-8">
          {tab === "dashboard" && (
            <div className="space-y-6">
              <div>
                <h2 className="heading-text text-2xl font-bold">
                  {isDemo ? "Welcome, Demo Admin" : "Welcome back, Admin"}
                </h2>
                <p className="mt-1 text-sm" style={{ color: "var(--sd-muted)" }}>
                  Every save is verified against persistent storage and updates the live website instantly.
                </p>
              </div>

              {isDemo && (
                <div className="rounded-3xl p-5" style={{ background: "rgba(255,251,235,0.85)", border: "1px solid rgba(245,158,11,0.45)" }}>
                  <p className="flex items-center gap-2 text-sm font-bold" style={{ color: "#b45309" }}>
                    <AlertTriangle size={15} />
                    Temporary Demo Account
                  </p>
                  <p className="mt-1.5 text-xs leading-relaxed" style={{ color: "#92400e" }}>
                    Full preview access to every admin feature including save, publish and delete. This
                    session automatically expires after <strong>2 hours</strong>. Production credentials
                    and security settings are never exposed to demo accounts.
                  </p>
                </div>
              )}

              <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                <SummaryCard icon={FolderKanban} label="Portfolio Projects" value={c.portfolio.length} />
                <SummaryCard icon={Wrench} label="Services" value={c.services.length} />
                <SummaryCard icon={Briefcase} label="Experience Entries" value={c.experience.length} />
                <SummaryCard icon={Gauge} label="Skills & Tools" value={c.skills.length} />
                <SummaryCard icon={Quote} label="Testimonials" value={c.testimonials.length} />
                <SummaryCard icon={Inbox} label="Enquiries" value={c.enquiries.length} />
              </div>

              <div>
                <p className="mb-3 text-[11px] font-bold uppercase tracking-widest" style={{ color: "var(--sd-muted)" }}>Quick Actions</p>
                <div className="flex flex-wrap gap-2.5">
                  <QuickAction icon={FolderKanban} label="Manage Portfolio" onClick={() => switchTab("portfolio")} />
                  <QuickAction icon={Wrench} label="Manage Services" onClick={() => switchTab("services")} />
                  <QuickAction icon={Inbox} label="View Enquiries" onClick={() => switchTab("enquiries")} />
                  <QuickAction icon={FileText} label="Edit Homepage" onClick={() => switchTab("homepage")} />
                  <QuickAction icon={Palette} label="Appearance" onClick={() => switchTab("appearance")} />
                  <QuickAction icon={Volume2} label="Sound Settings" onClick={() => switchTab("sound")} />
                </div>
              </div>
            </div>
          )}

          {tab === "homepage" && <HomepageTab />}
          {tab === "website" && <WebsiteTab />}
          {tab === "images" && <ImageManagementTab />}
          {tab === "portfolio" && <PortfolioTab />}
          {tab === "categories" && <CategoriesTab />}
          {tab === "services" && <ServicesTab />}
          {tab === "experience" && <ExperienceTab />}
          {tab === "skills" && <SkillsTab />}
          {tab === "testimonials" && <TestimonialsTab />}
          {tab === "enquiries" && <EnquiriesTab />}
          {tab === "seo" && <SeoTab />}
          {tab === "social" && <SocialTab />}
          {tab === "appearance" && <AppearanceTab />}
          {tab === "galaxy" && <GalaxyTab />}
          {tab === "sound" && <SoundTab />}
          {tab === "profile" && <ProfileTab isDemo={isDemo} />}
        </main>
      </div>
    </div>
  );
}
