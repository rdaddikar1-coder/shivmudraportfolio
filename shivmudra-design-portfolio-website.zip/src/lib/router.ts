import { useEffect, useState } from "react";

/**
 * Lightweight hash-based router for the admin area.
 *
 * Routes:  "#/admin"  "#/admin/login"
 * Anything else ("" or "#about" anchors) maps to the public site —
 * keeping the existing smooth-scroll anchor navigation untouched.
 */
function parseHash(): string {
  const h = window.location.hash;
  if (h.startsWith("#/")) {
    const route = h.slice(1).replace(/\/+$/, "");
    return route === "" ? "/" : route;
  }
  return "/";
}

export function useHashRoute(): string {
  const [route, setRoute] = useState<string>(() => parseHash());

  useEffect(() => {
    const onHash = () => setRoute(parseHash());
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  return route;
}

export function navigate(to: string) {
  window.location.hash = to;
}
